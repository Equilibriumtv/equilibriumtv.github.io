Para desativar o changelog, acesse Ferramentas/Configurações/Atualizar

## V 0.1.2

- Corrigido o travamento do EPG no PVR - a exportação do EPG será ignorada se o arquivo existir e tiver menos de 4 horas
- Adicionado o atributo de compatibilidade is_refreshing à classe EPG (corrige o erro AttributeError)
- PVR integrado nas Configurações - opção para usar as configurações do cliente PVR ou as configurações do complemento
- Adicionados cabeçalhos de codificação UTF-8 aos arquivos favorites.py, iptv.py, profiles.py e tmdb.py
- Adicionada limpeza automática de cache - remove arquivos de cache obsoletos com mais de 7 dias na inicialização
- Adicionado tratamento de fallback do EPG - tenta um endpoint alternativo quando a URL do EPG detectada automaticamente falha
- Adicionada notificação ao usuário quando os dados do EPG não são carregados
- Adicionada validação de conteúdo M3U - verifica o Content-Type, o tamanho mínimo e valida as URLs de streaming
- Adicionado suporte completo a catch-up/replay em M3U com suporte a variáveis ​​de modelo
- Adicionada mensagem de reinicialização após operações nos favoritos do PVR (novos grupos/canais) - informa aos usuários que o Kodi foi reiniciado É necessário para visualizar as alterações no PVR
- Atualizados todos os 16 arquivos de idioma com novas traduções
- Configurações - PVR, adicionada opção para ativar/desativar o PVR de favoritos; quando desativado, a instância do PVR de favoritos não é carregada em uma nova reinicialização
