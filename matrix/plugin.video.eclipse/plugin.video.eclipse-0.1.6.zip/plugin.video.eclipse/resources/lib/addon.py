# -*- coding: utf-8 -*-
import os, json, hashlib, struct, zlib, base64

def _run():
    import xbmc, xbmcgui, xbmcvfs, xbmcaddon
    def _r(p): return ''.join(x for _, x in sorted(p))
    def _xc(d, k, n):
        o, c = bytearray(), 0
        while len(o) < len(d):
            o.extend(hashlib.sha256(k + n + struct.pack('>Q', c)).digest())
            c += 1
        return bytes(a ^ b for a, b in zip(d, bytes(o[:len(d)])))

    try:
        root = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
        this_dir = os.path.dirname(os.path.abspath(__file__))
        locais = [os.path.join(root, "main.enc"), os.path.join(this_dir, "main.enc")]
        enc_path = next((f for f in locais if os.path.exists(f)), None)

        if not enc_path: raise Exception("Erro: main.enc ausente")

        with open(enc_path, 'r') as f: e = json.load(f)
        mk = base64.b64decode(_r([(2, 'VGVhbSBNY'), (0, 'Z3VzcGxh'), (1, 'eV8yMDI2Xw=='), (3, 'bWFndXNfc2VjcmV0')]))
        rk = hashlib.pbkdf2_hmac('sha256', mk, base64.b64decode(e['salt']), 200000, 32)
        dc = _xc(base64.b64decode(e['data']), rk, base64.b64decode(e['nonce']))
        for _ in range(int(e['layers'])): dc = zlib.decompress(dc)

        namespace = {
            'xbmc': xbmc, 'xbmcgui': xbmcgui, 'xbmcvfs': xbmcvfs,
            'xbmcaddon': xbmcaddon, '__name__': '__main__', '__file__': enc_path
        }
        exec(dc.decode('utf-8'), namespace)

    except Exception as err:
        xbmcgui.Dialog().ok("Erro Gforce Plus", str(err))

if __name__ == '__main__':
    _run()
