import sqlite3
import time
import json
import xbmc  # type: ignore
import os, xbmcaddon, xbmcvfs, xbmcgui # type: ignore
from datetime import datetime, timedelta
from resources.modules import control,tools, variables # type: ignore
import threading

ADDON = xbmcaddon.Addon()
ADDONPATH = ADDON.getAddonInfo("path")
ADDON_NAME = ADDON.getAddonInfo("name")
ADDON_ID = ADDON.getAddonInfo('id')
HOME = xbmcvfs.translatePath('special://home/')
ADDONS = os.path.join(HOME, 'addons')
USERDATA = os.path.join(HOME, 'userdata')
PLUGIN = os.path.join(ADDONS, ADDON_ID)
PACKAGES = os.path.join(ADDONS, 'packages')
ADDONDATA = os.path.join(USERDATA, 'addon_data', ADDON_ID)
#########################=XC VARIABLES=#####################################
dns = variables.dns
username = variables.username
password = variables.password

panel_api = variables.panel_api
player_api = variables.player_api

play_url = variables.play_url
play_live = variables.play_live
play_movies = variables.play_movies
play_series = variables.play_series

live_all = variables.live_all
live_cat = variables.live_cat
live_streams = variables.live_streams
live_short_epg = variables.live_short_epg

vod_all = variables.vod_all
vod_cat = variables.vod_cat
vod_streams = variables.vod_streams
vod_info = variables.vod_info

series_all = variables.series_all
series_cat = variables.series_cat
series_list = variables.series_list
series_season = variables.series_season

#############################################################################

DB_PATH1 = os.path.join(ADDONDATA, "media_cache.db")
UPDATE_INTERVAL = 48 * 60 * 60 # 48 hours

if not os.path.exists(ADDONDATA):
    os.makedirs(ADDONDATA)

# CÓDIGO NO ARQUIVO resources\caching\ini_cache.py
class CacheManager:
    def __init__(self):
        # Obtém o ID do addon (plugin.video.elysium)
        addon_id = xbmcaddon.Addon().getAddonInfo('id')

        # Obtém o caminho do perfil de dados do addon (userdata/addon_data/plugin.video.elysium/)
        # xbmc.translatePath garante que o caminho funcione em qualquer SO (Windows/Linux/Android)
        addon_profile = xbmcvfs.translatePath(xbmcaddon.Addon(addon_id).getAddonInfo('profile'))

        # Define o caminho completo para o arquivo de cache (banco de dados)
        # Assumindo que o seu arquivo se chama 'cache.db'
        self.db_path = os.path.join(addon_profile, 'cache.db')

        self.setup_database()

    # ❗ AGORA O MÉTODO DE LIMPEZA PODE USAR self.db_path
    def clear_all_cache(self):
        try:
            if os.path.exists(self.db_path):
                os.remove(self.db_path)
                xbmc.log(f"[Elysium Cache] Cache de inicialização limpo: {self.db_path}", xbmc.LOGINFO)
                return True
        except Exception as e:
            xbmc.log(f"[Elysium Cache] ERRO ao limpar cache: {e}", xbmc.LOGERROR)
            pass
        return False

    def setup_database(self):
        # Seu código de setup vai aqui...
        pass

    def setup_database(self):
        # Seu código de setup deve estar aqui, usando self.db_path
        pass
    def setup_database(self):
        """Setup the database for caching Live TV, VOD, and TV Series."""
        conn = sqlite3.connect(DB_PATH1, check_same_thread=False)
        cursor = conn.cursor()

        cursor.execute('''CREATE TABLE IF NOT EXISTS live_tv_categories (
                            category_id TEXT PRIMARY KEY,
                            category_name TEXT,
                            last_updated DATETIME)''')
        cursor.execute('''CREATE TABLE IF NOT EXISTS vod_categories (
                            category_id TEXT PRIMARY KEY,
                            category_name TEXT,
                            last_updated DATETIME)''')
        cursor.execute('''CREATE TABLE IF NOT EXISTS tv_series_categories (
                            category_id TEXT PRIMARY KEY,
                            category_name TEXT,
                            last_updated DATETIME)''')

        cursor.execute('''CREATE TABLE IF NOT EXISTS live_tv (
                            stream_id TEXT PRIMARY KEY,
                            epg_channel_id TEXT,
                            name TEXT,
                            stream_icon TEXT,
                            category_id TEXT,
                            last_updated DATETIME)''')

        cursor.execute('''CREATE TABLE IF NOT EXISTS vod (
                            stream_id TEXT PRIMARY KEY,
                            name TEXT,
                            stream_icon TEXT,
                            category_id TEXT,
                            container_extension TEXT,
                            last_updated DATETIME)''')

        cursor.execute('''CREATE TABLE IF NOT EXISTS tv_series (
                            series_id TEXT PRIMARY KEY,
                            name TEXT,
                            cover TEXT,
                            category_id TEXT,
                            last_updated DATETIME)''')

        cursor.execute("CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT)")

        conn.commit()
        conn.close()

    def fetch_and_cache_data(self, url, table_name, columns, cursor, category_id=None):
        """Generalized method to fetch and cache data for a given category using an existing cursor."""

        # Query last_updated for this category (or any row if category_id is None)
        if category_id is not None:
            cursor.execute(f"SELECT last_updated FROM {table_name} WHERE category_id=?", (category_id,))
        else:
            cursor.execute(f"SELECT last_updated FROM {table_name} LIMIT 1")
        result = cursor.fetchone()

        if result and result[0]:
            # Try parsing stored datetime string
            try:
                last_updated = datetime.strptime(result[0], "%Y-%m-%d %H:%M:%S.%f")
            except ValueError:
                try:
                    last_updated = datetime.strptime(result[0], "%Y-%m-%d %H:%M:%S")
                except Exception:
                    last_updated = None
        else:
            last_updated = None

        needs_update = (not result) or (last_updated is None) or ((datetime.now() - last_updated).total_seconds() > UPDATE_INTERVAL)

        if needs_update:
            tools.log(f"Fetching new data for category_id {category_id} in {table_name}...")

            # avoid 429
            time.sleep(0.3)

            data = tools.OPEN_URL(url)

            # Validate response
            if not data or data.strip() == "":
                tools.log(f"Resposta vazia ou inválida para {url}. Ignorando categoria {category_id}.")
                return 0

            try:
                parsed_data = json.loads(data)
            except json.JSONDecodeError as e:
                tools.log(f"Erro ao parsear JSON de {url}: {e}. Dados recebidos: {data[:200]}...")
                return 0

            for item in parsed_data:
                values = [item.get(col, "Unknown") for col in columns]
                values.append(datetime.now())
                placeholders = ", ".join(["?"] * len(values))

                cursor.execute(f"""
                    INSERT OR REPLACE INTO {table_name} ({', '.join(columns)}, last_updated)
                    VALUES ({placeholders})
                """, values)

        # Count items for category if provided, otherwise total rows in table
        if category_id is not None:
            cursor.execute(f"SELECT COUNT(*) FROM {table_name} WHERE category_id=?", (category_id,))
        else:
            cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
        total_items = cursor.fetchone()[0]
        return total_items

    def fetch_all_and_cache(self):
        """Fetch and cache all data for Live TV, VOD, and TV Series."""
        conn = sqlite3.connect(DB_PATH1, check_same_thread=False)
        cursor = conn.cursor()

        live_categories = tools.OPEN_URL(live_cat)
        live_parsed = json.loads(live_categories) if live_categories else []
        for item in live_parsed:
            category_id = item['category_id']
            category_name = item['category_name']

            cursor.execute("""
                INSERT OR REPLACE INTO live_tv_categories (category_id, category_name, last_updated)
                VALUES (?, ?, ?)
            """, (category_id, category_name, datetime.now()))

            self.fetch_and_cache_data(
                f"{live_streams}{category_id}",
                "live_tv",
                ["stream_id", "epg_channel_id", "name", "stream_icon", "category_id"],
                cursor,
                category_id
            )

        vod_categories = tools.OPEN_URL(vod_cat)
        vod_parsed = json.loads(vod_categories) if vod_categories else []
        for item in vod_parsed:
            category_id = item['category_id']
            category_name = item['category_name']

            cursor.execute("""
                INSERT OR REPLACE INTO vod_categories (category_id, category_name, last_updated)
                VALUES (?, ?, ?)
            """, (category_id, category_name, datetime.now()))

            self.fetch_and_cache_data(
                f"{vod_streams}{category_id}",
                "vod",
                ["stream_id", "name", "stream_icon", "category_id", "container_extension"],
                cursor,
                category_id
            )

        series_categories = tools.OPEN_URL(series_cat)
        series_parsed = json.loads(series_categories) if series_categories else []
        for item in series_parsed:
            category_id = item['category_id']
            category_name = item['category_name']

            cursor.execute("""
                INSERT OR REPLACE INTO tv_series_categories (category_id, category_name, last_updated)
                VALUES (?, ?, ?)
            """, (category_id, category_name, datetime.now()))

            self.fetch_and_cache_data(
                f"{series_list}{category_id}",
                "tv_series",
                ["series_id", "name", "cover", "category_id"],
                cursor,
                category_id
            )

        conn.commit()
        conn.close()

    def load_cat_data_from_db(self, table_name):
        conn = sqlite3.connect(DB_PATH1, check_same_thread=False)
        cursor = conn.cursor()
        cursor.execute(f"SELECT category_id, category_name FROM {table_name}")
        data = cursor.fetchall()
        conn.close()
        return data

    def load_data_from_db(self, table_name, category_id):
        conn = sqlite3.connect(DB_PATH1, check_same_thread=False)
        cursor = conn.cursor()
        cursor.execute(f"SELECT * FROM {table_name} WHERE category_id=?", (category_id,))
        data = cursor.fetchall()
        conn.close()
        return data


def silent_cache_update():
    """
    Triggers the cache update silently in the background.
    """
    def update_cache():
        try:
            tools.log("Starting silent cache update.")
            cache_manager = CacheManager()

            # ABRE A CONEXÃO UMA ÚNICA VEZ
            with sqlite3.connect(DB_PATH1) as conn:
                cursor = conn.cursor()
                cursor.execute("CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT)")
                cursor.execute("SELECT value FROM metadata WHERE key='last_update'")
                result = cursor.fetchone()

                if result:
                    last_update = datetime.strptime(result[0], "%Y-%m-%d %H:%M:%S")
                    if (datetime.now() - last_update).total_seconds() <= 48 * 3600:
                        tools.log("Cache is up-to-date; no update required.")
                        return

                tools.log("Nenhum registro de data e hora de atualização anterior encontrado. Atualizando cache.")

                # --- LIVE TV CATEGORIES ---
                live_categories = tools.OPEN_URL(live_cat)
                try:
                    live_parsed = json.loads(live_categories) if live_categories else []
                except Exception as e:
                    tools.log(f"Falha silenciosa ao carregar categorias de TV ao vivo. Erro: {e}")
                    live_parsed = []

                for item in live_parsed:
                    category_id = item['category_id']
                    category_name = item['category_name']

                    cursor.execute("""
                        INSERT OR REPLACE INTO live_tv_categories (category_id, category_name, last_updated)
                        VALUES (?, ?, ?)
                    """, (category_id, category_name, datetime.now()))

                    cache_manager.fetch_and_cache_data(
                        f"{live_streams}{category_id}",
                        "live_tv",
                        ["stream_id", "epg_channel_id", "name", "stream_icon", "category_id"],
                        cursor,
                        category_id
                    )

                # --- VOD CATEGORIES ---
                vod_categories = tools.OPEN_URL(vod_cat)
                try:
                    vod_parsed = json.loads(vod_categories) if vod_categories else []
                except Exception as e:
                    tools.log(f"Falha silenciosa ao carregar categorias de Filmes. Erro: {e}")
                    vod_parsed = []

                for item in vod_parsed:
                    category_id = item['category_id']
                    category_name = item['category_name']

                    cursor.execute("""
                        INSERT OR REPLACE INTO vod_categories (category_id, category_name, last_updated)
                        VALUES (?, ?, ?)
                    """, (category_id, category_name, datetime.now()))

                    cache_manager.fetch_and_cache_data(
                        f"{vod_streams}{category_id}",
                        "vod",
                        ["stream_id", "name", "stream_icon", "category_id", "container_extension"],
                        cursor,
                        category_id
                    )

                # --- SERIES CATEGORIES ---
                series_categories = tools.OPEN_URL(series_cat)
                try:
                    series_parsed = json.loads(series_categories) if series_categories else []
                except Exception as e:
                    tools.log(f"Falha silenciosa ao carregar categorias de Séries. Erro: {e}")
                    series_parsed = []

                for item in series_parsed:
                    category_id = item['category_id']
                    category_name = item['category_name']

                    cursor.execute("""
                        INSERT OR REPLACE INTO tv_series_categories (category_id, category_name, last_updated)
                        VALUES (?, ?, ?)
                    """, (category_id, category_name, datetime.now()))

                    cache_manager.fetch_and_cache_data(
                        f"{series_list}{category_id}",
                        "tv_series",
                        ["series_id", "name", "cover", "category_id"],
                        cursor,
                        category_id
                    )

                # --- FINALIZAÇÃO ---
                cursor.execute("""
                    INSERT OR REPLACE INTO metadata (key, value)
                    VALUES ('last_update', ?)
                """, (datetime.now().strftime("%Y-%m-%d %H:%M:%S"),))

            tools.log("Silent Atualização de cache concluídad successfully.")

        except Exception as e:
            tools.log(f"Falha na atualização do cache: {e}")

    threading.Thread(target=update_cache, daemon=True).start()


def manual_cache_update():
    """
    Manually triggers the caching process with a Kodi progress dialog.
    Displays progress for Live TV, VOD, and TV Series caching with detailed debugging logs.
    """
    dialog = xbmcgui.DialogProgress()
    dialog.create("Atualizando o Cache", "Iniciando a atualização do cache...")

    try:
        tools.log("Starting manual cache update.")
        cache_manager = CacheManager()

        # ABRE A CONEXÃO UMA ÚNICA VEZ
        with sqlite3.connect(DB_PATH1) as conn:
            cursor = conn.cursor()

            cursor.execute("CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT)")
            cursor.execute("SELECT value FROM metadata WHERE key='last_update'")
            result = cursor.fetchone()

            if result:
                last_update = datetime.strptime(result[0], "%Y-%m-%d %H:%M:%S")
                if (datetime.now() - last_update).total_seconds() <= 48 * 3600:
                    tools.log("Cache is up-to-date; no update required.")
                    dialog.close()
                    return
                else:
                    tools.log("Nenhum registro de data e hora de atualização anterior encontrado. Atualizando cache.")

            # --- LIVE TV CATEGORIES ---
            dialog.update(0, "Obtendo categorias de TV ao vivo...")
            live_categories = tools.OPEN_URL(live_cat)

            try:
                live_parsed = json.loads(live_categories) if live_categories else []
            except Exception as e:
                tools.log(f"Falha ao carregar categorias de TV ao vivo. URL: {live_cat}. Erro: {e}")
                xbmcgui.Dialog().notification("Erro de Servidor", "Falha ao obter categorias de TV ao vivo.", xbmcgui.NOTIFICATION_ERROR)
                live_parsed = []

            tools.log(f"Parsed {len(live_parsed)} Live TV categories.")

            total_live, total_channels = 0, 0
            for i, item in enumerate(live_parsed):
                category_id = item['category_id']
                category_name = item['category_name']

                cursor.execute("""
                    INSERT OR REPLACE INTO live_tv_categories (category_id, category_name, last_updated)
                    VALUES (?, ?, ?)
                """, (category_id, category_name, datetime.now()))

                cache_manager.fetch_and_cache_data(
                    f"{live_streams}{category_id}",
                    "live_tv",
                    ["stream_id", "epg_channel_id", "name", "stream_icon", "category_id"],
                    cursor,
                    category_id
                )

                total_live += 1
                total_channels += get_total_channels_in_category(category_id)
                percent = int((i + 1) / len(live_parsed) * 33)
                dialog.update(percent, f"Categorias de TV ao vivo... ({i + 1}/{len(live_parsed)})")
                if dialog.iscanceled():
                    raise Exception("Atualização de cache cancelada pelo usuário.")

            # --- VOD CATEGORIES ---
            dialog.update(33, "Obtendo categorias de Filmes...")
            vod_categories = tools.OPEN_URL(vod_cat)

            try:
                vod_parsed = json.loads(vod_categories) if vod_categories else []
            except Exception as e:
                tools.log(f"Falha ao carregar categorias de Filmes. URL: {vod_cat}. Erro: {e}")
                vod_parsed = []

            tools.log(f"Parsed {len(vod_parsed)} Categorias de Filmes.")

            total_vod, total_movies = 0, 0
            for i, item in enumerate(vod_parsed):
                category_id = item['category_id']
                category_name = item['category_name']

                cursor.execute("""
                    INSERT OR REPLACE INTO vod_categories (category_id, category_name, last_updated)
                    VALUES (?, ?, ?)
                """, (category_id, category_name, datetime.now()))

                cache_manager.fetch_and_cache_data(
                    f"{vod_streams}{category_id}",
                    "vod",
                    ["stream_id", "name", "stream_icon", "category_id", "container_extension"],
                    cursor,
                    category_id
                )

                total_vod += 1
                total_movies += get_total_movies_in_category(category_id)
                percent = int(33 + (i + 1) / len(vod_parsed) * 33)
                dialog.update(percent, f"Categorias de Filmes... ({i + 1}/{len(vod_parsed)})")
                if dialog.iscanceled():
                    raise Exception("Atualização de cache cancelada pelo usuário.")

            # --- SERIES CATEGORIES ---
            dialog.update(66, "Obtendo categorias de Séries...")
            series_categories = tools.OPEN_URL(series_cat)

            try:
                series_parsed = json.loads(series_categories) if series_categories else []
            except Exception as e:
                tools.log(f"Falha ao carregar categorias de Séries. URL: {series_cat}. Erro: {e}")
                series_parsed = []

            tools.log(f"Parsed {len(series_parsed)} Categorias de Series.")

            total_series, total_shows = 0, 0
            for i, item in enumerate(series_parsed):
                category_id = item['category_id']
                category_name = item['category_name']

                cursor.execute("""
                    INSERT OR REPLACE INTO tv_series_categories (category_id, category_name, last_updated)
                    VALUES (?, ?, ?)
                """, (category_id, category_name, datetime.now()))

                # Cache TV Series data
                cache_manager.fetch_and_cache_data(
                    f"{series_list}{category_id}",
                    "tv_series",
                    ["series_id", "name", "cover", "category_id"],
                    cursor,
                    category_id
                )

                total_series += 1
                total_shows += get_total_shows_in_category(category_id)
                percent = int(66 + (i + 1) / len(series_parsed) * 34)
                dialog.update(percent, f"Categorias de séries... ({i + 1}/{len(series_parsed)})")
                if dialog.iscanceled():
                    raise Exception("Atualização de cache cancelada pelo usuário.")

            # --- FINALIZAÇÃO ---
            cursor.execute("""
                INSERT OR REPLACE INTO metadata (key, value)
                VALUES ('last_update', ?)
            """, (datetime.now().strftime("%Y-%m-%d %H:%M:%S"),))

        dialog.update(100, "Atualização de cache concluída!")
        tools.log(f"Atualização de cache concluídad successfully. "
                    f"TV ao vivo: {total_live} Categorias, {total_channels} total de Canais\n"
                    f"Filmes: {total_vod} Categorias, {total_movies} total Filmes\n"
                    f"Series: {total_series} Categorias, {total_shows} total de Series.")

        xbmcgui.Dialog().ok(
            "Atualização de cache concluída",
            f"TV ao vivo: {total_live} Categorias - {total_channels} total Canais\n"
            f"Filmes: {total_vod} Categorias - {total_movies} total de Filmes\n"
            f"Series: {total_series} Categorias - {total_shows} total de Series"
        )

    except Exception as e:
        tools.log(f"Falha na atualização do cache: {e}")
        xbmcgui.Dialog().notification("Falha na atualização do cache", str(e), xbmcgui.NOTIFICATION_ERROR, 5000)
    finally:
        dialog.close()

def get_total_channels_in_category(category_id):
    """Get the total number of channels in the specified category from the database."""
    conn = sqlite3.connect(DB_PATH1, check_same_thread=False)
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM live_tv WHERE category_id=?", (category_id,))
    total_channels = cursor.fetchone()[0]
    conn.close()
    return total_channels


def get_total_movies_in_category(category_id):
    """Get the total number of movies in the specified category from the database."""
    conn = sqlite3.connect(DB_PATH1, check_same_thread=False)
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM vod WHERE category_id=?", (category_id,))
    total_movies = cursor.fetchone()[0]
    conn.close()
    return total_movies


def get_total_shows_in_category(category_id):
    """Get the total number of shows in the specified category from the database."""
    conn = sqlite3.connect(DB_PATH1, check_same_thread=False)
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM tv_series WHERE category_id=?", (category_id,))
    total_shows = cursor.fetchone()[0]
    conn.close()
    return total_shows
