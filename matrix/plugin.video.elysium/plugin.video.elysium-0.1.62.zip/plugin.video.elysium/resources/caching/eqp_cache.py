#############################=IMPORTS=######################################
# Kodi Specific
import xbmc, xbmcvfs, xbmcaddon, xbmcgui, xbmcplugin, time, calendar  # type: ignore
# Python Specific
import base64, os, re, time, sys, urllib.request
import urllib.parse, urllib.error, json, shutil
from urllib.parse import urlparse, parse_qs
import sqlite3
import threading
import xml.etree.ElementTree as ET
from datetime import datetime, timezone, timedelta
from concurrent.futures import ThreadPoolExecutor

# Addon Specific
from resources.modules import control, tools, variables

XMLTV_URL = variables.XMLTV_URL
DB_PATH = variables.DB_PATH
ADDONDATA = variables.ADDONDATA

# Lock global para operações de escrita no banco de EPG (thread-safe)
_epg_db_lock = threading.Lock()


class EPGUpdater:
    def __init__(self):
        self.db_path = DB_PATH
        self.xmltv_url = XMLTV_URL

    def setup_database(self):
        """Setup do banco de dados EPG"""
        with _epg_db_lock:
            conn = sqlite3.connect(self.db_path, timeout=10)
            cursor = conn.cursor()
            cursor.execute('''CREATE TABLE IF NOT EXISTS epg (
                                channel_id TEXT,
                                title TEXT,
                                start_time DATETIME,
                                end_time DATETIME,
                                description TEXT)''')
            conn.commit()
            conn.close()

    def is_db_empty(self):
        """Verifica se o banco está vazio"""
        try:
            conn = sqlite3.connect(self.db_path, timeout=10)
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM epg")
            count = cursor.fetchone()[0]
            conn.close()
            return count == 0
        except Exception as e:
            tools.log(f"Erro ao verificar DB: {e}")
            return True

    def download_and_parse_xmltv(self):
        """Baixa e processa o XMLTV"""
        self.setup_database()
        try:
            tools.log("EPG: Baixando dados XMLTV...")
            response = tools.OPEN_URL(self.xmltv_url)
            if response is None:
                raise Exception("Falha ao baixar XMLTV.")

            xmltv_file = os.path.join(ADDONDATA, "xmltv.xml")
            with open(xmltv_file, "w", encoding="utf-8") as f:
                f.write(response)

            tools.log("EPG: Analisando e salvando dados XMLTV...")
            self.parse_and_save_xmltv(xmltv_file)
        except Exception as e:
            tools.log(f"Falha ao buscar XMLTV: {e}")

    def parse_and_save_xmltv(self, xmltv_file):
        """Processa e salva os dados XMLTV no banco"""
        with _epg_db_lock:
            conn = sqlite3.connect(self.db_path, timeout=10)
            cursor = conn.cursor()
            cursor.execute("DELETE FROM epg")

            tree = ET.parse(xmltv_file)
            root = tree.getroot()

            for programme in root.findall("programme"):
                channel_id = programme.get("channel")
                start_time = self.parse_xmltv_time(programme.get("start"))
                end_time = self.parse_xmltv_time(programme.get("stop"))
                title = programme.find("title").text if programme.find("title") is not None else "No Title"
                description = programme.find("desc").text if programme.find("desc") is not None else "No Description"

                if start_time and end_time:
                    cursor.execute("""
                        INSERT INTO epg (channel_id, start_time, end_time, title, description)
                        VALUES (?, ?, ?, ?, ?)
                    """, (channel_id, start_time, end_time, title, description))

            conn.commit()
            conn.close()
            tools.log("EPG: Dados XMLTV salvos com sucesso.")

    def parse_xmltv_time(self, time_str):
        """Converte tempo XMLTV em timestamp UTC"""
        try:
            time_str_parts = time_str.split(" ")
            if len(time_str_parts) != 2:
                raise ValueError(f"Formato inválido de tempo: {time_str}")

            time_without_tz, timezone_str = time_str_parts
            if len(timezone_str) != 5 or timezone_str[0] not in ['+', '-']:
                raise ValueError(f"Fuso horário inválido: {timezone_str}")

            tz_sign = 1 if timezone_str[0] == '+' else -1
            tz_hours = int(timezone_str[1:3])
            tz_minutes = int(timezone_str[3:5])
            tz_offset = tz_sign * (tz_hours * 60 + tz_minutes)

            tz_info = timezone(timedelta(minutes=tz_offset))
            dt = datetime.strptime(time_without_tz, "%Y%m%d%H%M%S")
            dt_with_tz = dt.replace(tzinfo=tz_info)
            dt_utc = dt_with_tz.astimezone(timezone.utc)
            return int(dt_utc.timestamp())

        except ValueError as e:
            tools.log(f"Erro ao converter tempo XMLTV: {time_str} ({e})")
            return None

    def fetch_and_cache_xmltv(self):
        """Usa cache do XMLTV ou baixa se necessário"""
        xmltv_file = os.path.join(ADDONDATA, "xmltv.xml")

        if os.path.exists(xmltv_file):
            if self.is_db_empty():
                tools.log("EPG: DB vazio. Atualizando XMLTV...")
                self.download_and_parse_xmltv()
            else:
                tools.log("EPG: Usando cache local XMLTV.")
                self.parse_and_save_xmltv(xmltv_file)
        else:
            tools.log("EPG: XMLTV inexistente. Baixando dados.")
            self.download_and_parse_xmltv()

    def manual_update(self):
        """Atualização manual com barra de progresso"""
        self.setup_database()
        dialog = xbmcgui.DialogProgress()
        dialog.create("EPG Update", "Inicializando atualização...")

        try:
            tools.log("EPG: Iniciando atualização manual...")

            dialog.update(0, "Baixando EPG...")
            url = self.xmltv_url
            req = urllib.request.Request(url)
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; WOW64) Gecko/20100101 Firefox/53.0')

            with urllib.request.urlopen(req) as response:
                total_size = int(response.getheader('Content-Length') or 50000000)
                downloaded = 0
                chunk_size = 1024
                xmltv_file = os.path.join(ADDONDATA, "xmltv.xml")

                with open(xmltv_file, "wb") as f:
                    while True:
                        chunk = response.read(chunk_size)
                        if not chunk:
                            break
                        f.write(chunk)
                        downloaded += len(chunk)
                        percent = int((downloaded / total_size) * 100)
                        dialog.update(percent, f"Baixando EPG... {percent}%")
                        if dialog.iscanceled():
                            raise Exception("Download cancelado pelo usuário.")

            tools.log("EPG: Dados baixados com sucesso.")
            dialog.update(50, "Analisando EPG...")
            self.parse_and_save_xmltv(xmltv_file)
            dialog.update(100, "EPG atualizado com sucesso!")
            xbmcgui.Dialog().notification("EPG", "Atualização concluída com sucesso!", xbmcgui.NOTIFICATION_INFO, 5000)

        except Exception as e:
            tools.log(f"EPG: Falha na atualização manual: {e}")
            xbmcgui.Dialog().notification("EPG", str(e), xbmcgui.NOTIFICATION_ERROR, 5000)
        finally:
            dialog.close()

    def silent_update(self):
        """Atualização em segundo plano"""
        self.setup_database()
        xmltv_file = os.path.join(ADDONDATA, "xmltv.xml")

        file_age = time.time() - os.path.getmtime(xmltv_file) if os.path.exists(xmltv_file) else float('inf')

        def update_in_background():
            try:
                tools.log("EPG: Atualização silenciosa iniciada...")
                if file_age > (1 * 24 * 60 * 60):
                    tools.log("EPG: Arquivo desatualizado. Baixando novo XMLTV.")
                    self.download_and_parse_xmltv()
                    tools.log("EPG: Atualização silenciosa concluída.")
                else:
                    tools.log("EPG: Ainda atualizado. Nenhuma ação necessária.")
            except Exception as e:
                tools.log(f"EPG: Erro na atualização silenciosa: {e}")

        threading.Thread(target=update_in_background, daemon=True).start()

    def clear_epg_cache(self):
        """Limpa cache (DB + XMLTV)"""
        with _epg_db_lock:
            if os.path.exists(self.db_path):
                try:
                    os.remove(self.db_path)
                    tools.log(f"EPG: Cache DB limpo ({self.db_path})", xbmc.LOGINFO)
                except Exception as e:
                    tools.log(f"EPG: Erro ao limpar cache DB: {e}", xbmc.LOGERROR)

            xmltv_file = os.path.join(ADDONDATA, "xmltv.xml")
            if os.path.exists(xmltv_file):
                try:
                    os.remove(xmltv_file)
                    tools.log(f"EPG: Cache XMLTV limpo ({xmltv_file})", xbmc.LOGINFO)
                except Exception as e:
                    tools.log(f"EPG: Erro ao limpar XMLTV: {e}", xbmc.LOGERROR)

        return True
