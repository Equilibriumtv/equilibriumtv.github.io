#!/usr/bin/python														   #
# -*- coding: utf-8 -*-													   #
#############################=IMPORTS=######################################
	#Kodi Specific
import xbmc,xbmcvfs,xbmcplugin,xbmcgui, xbmcaddon # type: ignore
import time
import json
import os
	#Python Specific
import os,re,sys,json,base64,shutil,socket
import urllib.request,urllib.parse,urllib.error,urllib.parse
from urllib.parse import urlparse
from urllib.request import Request, urlopen
	#Addon Specific
from . import control, variables

##########################=VARIABLES=#######################################
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
GET_SET = xbmcaddon.Addon(ADDON_ID)
ADDON_NAME = ADDON.getAddonInfo("name")
PROFILE_PATH = xbmcaddon.Addon().getAddonInfo('profile')
ICON   = xbmcvfs.translatePath(os.path.join('special://home/addons/' + ADDON_ID,  'icon.png'))
DIALOG = xbmcgui.Dialog()
DP	= xbmcgui.DialogProgress()
COLOR1='white'
COLOR2='blue'
dns_text = GET_SET.getSetting(id='DNS')
USER_DATA = variables.USER_DATA

def check_protocol(url):
	parsed = urlparse(dns_text)
	protocol = parsed.scheme
	if protocol=='https':
		return url.replace('http','https')
	else:
		return url

def log(msg):
	msg = str(msg)
	xbmc.log('%s-%s'%(ADDON_ID,msg),2)

def b64(obj):
	return base64.b64decode(obj).decode('utf-8')

def percentage(part, whole):
	return 100 * float(part)/float(whole)
	
def getInfo(label):
	try: return xbmc.getInfoLabel(label)
	except: return False
	
def LogNotify(title, message, times=3000, icon=ICON,sound=False):
	DIALOG.notification(title, message, icon, int(times), sound)
	
def ASln():
	return LogNotify("[COLOR {0}]{1}[/COLOR]".format(COLOR1, ADDON_ID), '[COLOR {0}]AdvancedSettings.xml have been written[/COLOR]'.format(COLOR2))

def regex_from_to(text, from_string, to_string, excluding=True):
	if excluding:
		try: r = re.search("(?i)" + from_string + "([\S\s]+?)" + to_string, text).group(1)
		except: r = ''
	else:
		try: r = re.search("(?i)(" + from_string + "[\S\s]+?" + to_string + ")", text).group(1)
		except: r = ''
	return r

def regex_get_all(text, start_with, end_with):
	r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
	return r
	
def regex_get_us(text, start_with, end_with):
	r = re.findall("(?i)(" + start_with + ".+?[UK: Sky Sports].+?" + end_with + ")", text)
	return r
	
def addDir(name, url, mode, iconimage, fanart, description):
	default_icon = "DefaultIcon.png"
	default_fanart = "DefaultFanart.jpg"
	
	name = str(name) if name else "Unknown"
	url = str(url) if url else ""
	iconimage = str(iconimage) if iconimage else default_icon
	fanart = str(fanart) if fanart else default_fanart
	description = str(description) if description else "No description available"
	
	params = {
		"url": urllib.parse.quote_plus(url),
		"mode": str(mode),
		"name": urllib.parse.quote_plus(name),
		"iconimage": urllib.parse.quote_plus(iconimage),
		"description": urllib.parse.quote_plus(description),
	}
	u = sys.argv[0] + "?" + "&".join(f"{key}={value}" for key, value in params.items())
#files songs artists albums movies tvshows episodes musicvideos videos images games
	#if mode in ['live_category', 'live_list']:
	#	xbmcplugin.setContent(int(sys.argv[1]), 'videos')
	#elif mode in ['vod_category', 'vod_list']:
	#	xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	#elif mode in ['series_lists', 'series_seasons', 'episode_list']:
	#	xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
	#elif mode in ['search', 'search_menu']:
	#	xbmcplugin.setContent(int(sys.argv[1]), 'search')
	#else:
	#	xbmcplugin.setContent(int(sys.argv[1]), 'videos')
	
	# Create the ListItem
	liz = xbmcgui.ListItem(name)
	liz.setArt({"icon": iconimage, "thumb": iconimage})
	liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
	liz.setProperty("fanart_image", fanart)

	# Determine if the item is playable
	is_playable_modes = {'play_live_stream', 'play_stream_video'}
	isFolder = mode not in is_playable_modes
	if not isFolder:
		liz.setProperty("IsPlayable", "true")

	# Add the directory item
	if mode == 'addonsettings' or mode == 'gui':
		ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=False)
	else:
		ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=isFolder)
	
	return ok

def OPEN_URL(url, binary=False, max_retries=3):
    for attempt in range(max_retries + 1):
        try:
            req = Request(url)
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0')
            with urlopen(req, timeout=15) as response:
                if response.getcode() == 200:
                    if binary:
                        return response.read()
                    return response.read().decode('utf-8', errors='ignore')
                else:
                    log(f"HTTP {response.getcode()} ao buscar {url}")
                    if attempt < max_retries:
                        time.sleep(2 ** attempt)  # backoff exponencial: 1s, 2s, 4s...
                    continue

        except urllib.error.HTTPError as e:
            if e.code == 429:
                log(f"HTTP 429 (Too Many Requests) em {url}. Tentativa {attempt + 1}/{max_retries + 1}")
                if attempt < max_retries:
                    time.sleep(2 ** attempt + 1)  # espera mais para 429
                else:
                    log("Máximo de tentativas atingido para 429.")
            else:
                log(f"HTTPError {e.code} em {url}: {e}")
            if attempt == max_retries:
                return None

        except Exception as e:
            log(f"Erro genérico ao buscar {url}: {e}")
            if attempt == max_retries:
                return None
            time.sleep(1)

    return None



def clear_cache():
	xbmc.log('CLEAR CACHE ACTIVATED')
	xbmc_cache_path = os.path.join(xbmcvfs.translatePath('special://home'), 'cache')
	confirm=xbmcgui.Dialog().yesno("Please Confirm","Please Confirm You Wish To Delete Your Kodi Application Cache")
	if confirm:
		if os.path.exists(xbmc_cache_path)==True:
			for root, dirs, files in os.walk(xbmc_cache_path):
				file_count = 0
				file_count += len(files)
				if file_count > 0:
						for f in files:
							try:
								os.unlink(os.path.join(root, f))
							except:
								pass
						for d in dirs:
							try:
								shutil.rmtree(os.path.join(root, d))
							except:
								pass
		LogNotify("[COLOR {0}]{1}[/COLOR]".format(COLOR1, ADDON_NAME), '[COLOR {0}]Cache Cleared Successfully![/COLOR]'.format(COLOR2))
		xbmc.executebuiltin("Container.Refresh()")

def get_params():
	params = {}
	if len(sys.argv) > 2:
		paramstring = sys.argv[2]
		if len(paramstring) >= 2:
			cleanedparams = paramstring.lstrip('?').rstrip('/')
			pairsofparams = cleanedparams.split('&')
			for pair in pairsofparams:
				if '=' in pair:
					key, value = pair.split('=', 1)	 # Split on first '='
					params[key] = value
	return params

def getlocalip():
	s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	s.connect(('8.8.8.8', 0))
	s = s.getsockname()[0]
	return s

def getexternalip():
	import json 
	url = urllib.request.urlopen("https://api.ipify.org/?format=json")
	data = json.loads(url.read().decode())
	return str(data["ip"])

def s_to_json(data):
    """Salva credenciais no arquivo USER_DATA (variáveis do addon)."""
    try:
        with open(variables.USER_DATA, 'w') as f:
            json.dump([data], f, indent=4)
        xbmc.log(f"Credenciais salvas em {variables.USER_DATA}", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"Erro ao salvar credenciais: {e}", xbmc.LOGERROR)

def MonthNumToName(num):
	if '01' in num:
		month = 'Janeiro'
	elif '02' in num:
		month = 'Fevereiro'
	elif '03' in num:
		month = 'Março'
	elif '04' in num:
		month = 'Abril'
	elif '05' in num:
		month = 'Maio'
	elif '06' in num:
		month = 'Junho'
	elif '07' in num:
		month = 'Julho'
	elif '08' in num:
		month = 'Agosto'
	elif '09' in num:
		month = 'Setembro'
	elif '10' in num:
		month = 'Outubro'
	elif '11' in num:
		month = 'Novembro'
	elif '12' in num:
		month = 'Dezembro'
	return month

def num2day(num):
	if num =="0":
		day = 'Segunda'
	elif num=="1":
		day = 'Terça'
	elif num=="2":
		day = 'Quarta'
	elif num=="3":
		day = 'Quinta'
	elif num=="4":
		day = 'Sexta'
	elif num=="5":
		day = 'Sabado'
	elif num=="6":
		day = 'Domingo'
	return day

def killxbmc():
	killdialog = xbmcgui.Dialog().yesno('Force Close Kodi', '[COLOR white]You are about to close Kodi', 'Would you like to continue?[/COLOR]', nolabel='[B][COLOR red] No Cancel[/COLOR][/B]',yeslabel='[B][COLOR green]Force Close Kodi[/COLOR][/B]')
	if killdialog:
		os._exit(1)
	else:
		home() # type: ignore

def gen_m3u(url, path):
	parse = json.loads(OPEN_URL(url))
	i=1
	DP.create(ADDON_NAME, "Please Wait")
	with open (path, 'w+', encoding="utf-8") as ftg:
		ftg.write('#EXTM3U\n')
		for items in parse['available_channels']:
			a = parse['available_channels'][items]
			
			if a['stream_type'] == 'live':
				
				b = '#EXTINF:-1 channel-id="{0}" tvg-id="{1}" tvg-name="{2}" tvg-logo="{3}" channel-id="{4}" group-title="{5}",{6}'.format(i, a['epg_channel_id'], a['epg_channel_id'], a['stream_icon'], a['name'], a['category_name'], a['name'])
				
				if parse['server_info']['server_protocol'] == 'https':
					port = parse['server_info']['https_port']
				else:
					port = parse['server_info']['port']
				
				dns = '{0}://{1}:{2}'.format(parse['server_info']['server_protocol'], parse['server_info']['url'], port)
				c = '{0}/{1}/{2}/{3}'.format(dns, parse['user_info']['username'], parse['user_info']['password'],a['stream_id'])
				ftg.write(b+'\n'+c+'\n')
				i +=1
				DP.update(int(100), 'Found Channel \n' + a['name'] + '\n')
				if DP.iscanceled(): break
		DP.close
		DIALOG.ok(ADDON_NAME, 'Found ' + str(i) + ' Channels')

def keypopup(heading):
	kb =xbmc.Keyboard ('', 'heading', True)
	kb.setHeading(heading)
	kb.setHiddenInput(False)
	kb.doModal()
	if (kb.isConfirmed()):
		text = kb.getText()
		return text
	else:
		return False