import sqlite3
import time
import json
import xbmc  # type: ignore
import os, xbmcaddon, xbmcvfs, xbmcgui  # type: ignore
from datetime import datetime, timedelta
from resources.modules import control, tools, variables  # type: ignore
import threading

# === LOCKS ===
db_lock = threading.Lock()
http_semaphore = threading.Semaphore(2)  # Limita requisições simultâneas para evitar timeouts e sobrecarga

ADDON = xbmcaddon.Addon()
ADDONPATH = ADDON.getAddonInfo("path")
ADDON_NAME = ADDON.getAddonInfo("name")
ADDON_ID = ADDON.getAddonInfo('id')
HOME = xbmcvfs.translatePath('special://home/')
ADDONS = os.path.join(HOME, 'addons')
USERDATA = os.path.join(HOME, 'userdata')
PLUGIN = os.path.join(ADDONS, ADDON_ID)
PACKAGES = os.path.join(ADDONS, 'packages')
ADDONDATA = os.path.join(USERDATA, 'addon_data', ADDON_ID)

#########################=XC VARIABLES=#####################################
dns = variables.dns
username = variables.username
password = variables.password

panel_api = variables.panel_api
player_api = variables.player_api

play_url = variables.play_url
play_live = variables.play_live
play_movies = variables.play_movies
play_series = variables.play_series

live_all = variables.live_all
live_cat = variables.live_cat
live_streams = variables.live_streams
live_short_epg = variables.live_short_epg

vod_all = variables.vod_all
vod_cat = variables.vod_cat
vod_streams = variables.vod_streams
vod_info = variables.vod_info

series_all = variables.series_all
series_cat = variables.series_cat
series_list = variables.series_list
series_season = variables.series_season

#############################################################################

DB_PATH1 = os.path.join(ADDONDATA, "media_cache.db")
UPDATE_INTERVAL = 48 * 60 * 60  # 48 hours

if not os.path.exists(ADDONDATA):
    os.makedirs(ADDONDATA)

# ============================================================
# === CAMADA DE CACHE EM RAM (acelera chamadas repetidas) ===
# ============================================================
RAM_CACHE = {}  # Dicionário global para armazenar dados em memória
RAM_CACHE_LOCK = threading.Lock()
RAM_CACHE_TTL = 3600  # Tempo de vida do cache em RAM (1 hora)

def get_from_ram_cache(key):
    """Retorna dados do cache em RAM se ainda válidos."""
    with RAM_CACHE_LOCK:
        entry = RAM_CACHE.get(key)
        if entry:
            data, timestamp = entry
            if (time.time() - timestamp) < RAM_CACHE_TTL:
                return data
            else:
                del RAM_CACHE[key]
    return None

def set_to_ram_cache(key, data):
    """Salva dados no cache em RAM."""
    with RAM_CACHE_LOCK:
        RAM_CACHE[key] = (data, time.time())

# ============================================================

class CacheManager:
    def __init__(self):
        if not os.path.exists(ADDONDATA):
            os.makedirs(ADDONDATA)
        self.setup_database()

    def clear_all_cache(self):
        """Limpa o cache inteiro (arquivo do banco e RAM)."""
        try:
            # Limpa o cache em disco
            if os.path.exists(DB_PATH1):
                os.remove(DB_PATH1)
                xbmc.log(f"[Elysium Cache] Cache limpo: {DB_PATH1}", xbmc.LOGINFO)

            # Limpa o cache em RAM
            with RAM_CACHE_LOCK:
                RAM_CACHE.clear()
                xbmc.log(f"[Elysium Cache] Cache em RAM limpo.", xbmc.LOGINFO)
            return True
        except Exception as e:
            xbmc.log(f"[Elysium Cache] Erro ao limpar cache: {e}", xbmc.LOGERROR)
        return False

    def setup_database(self):
        """Cria as tabelas do banco, se não existirem."""
        with db_lock:
            conn = sqlite3.connect(DB_PATH1, timeout=10, check_same_thread=False)
            cursor = conn.cursor()

            cursor.execute('''CREATE TABLE IF NOT EXISTS live_tv_categories (
                                category_id TEXT PRIMARY KEY,
                                category_name TEXT,
                                last_updated DATETIME)''')
            cursor.execute('''CREATE TABLE IF NOT EXISTS vod_categories (
                                category_id TEXT PRIMARY KEY,
                                category_name TEXT,
                                last_updated DATETIME)''')
            cursor.execute('''CREATE TABLE IF NOT EXISTS tv_series_categories (
                                category_id TEXT PRIMARY KEY,
                                category_name TEXT,
                                last_updated DATETIME)''')

            cursor.execute('''CREATE TABLE IF NOT EXISTS live_tv (
                                stream_id TEXT PRIMARY KEY,
                                epg_channel_id TEXT,
                                name TEXT,
                                stream_icon TEXT,
                                category_id TEXT,
                                last_updated DATETIME)''')

            cursor.execute('''CREATE TABLE IF NOT EXISTS vod (
                                stream_id TEXT PRIMARY KEY,
                                name TEXT,
                                stream_icon TEXT,
                                category_id TEXT,
                                container_extension TEXT,
                                last_updated DATETIME)''')

            cursor.execute('''CREATE TABLE IF NOT EXISTS tv_series (
                                series_id TEXT PRIMARY KEY,
                                name TEXT,
                                cover TEXT,
                                category_id TEXT,
                                last_updated DATETIME)''')

            cursor.execute("CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT)")

            conn.commit()
            conn.close()

    def fetch_and_cache_data(self, url, table_name, columns, cursor, category_id=None):
        """Método interno: só deve ser chamado com cursor ativo e dentro do contexto de lock."""
        if category_id is not None:
            cursor.execute(f"SELECT last_updated FROM {table_name} WHERE category_id=?", (category_id,))
        else:
            cursor.execute(f"SELECT last_updated FROM {table_name} LIMIT 1")
        result = cursor.fetchone()

        if result and result[0]:
            try:
                last_updated = datetime.strptime(result[0], "%Y-%m-%d %H:%M:%S.%f")
            except ValueError:
                try:
                    last_updated = datetime.strptime(result[0], "%Y-%m-%d %H:%M:%S")
                except Exception:
                    last_updated = None
        else:
            last_updated = None

        needs_update = (not result) or (last_updated is None) or ((datetime.now() - last_updated).total_seconds() > UPDATE_INTERVAL)

        if needs_update:
            tools.log(f"Fetching new data for category_id {category_id} in {table_name}...")
            time.sleep(0.3)
            with http_semaphore:
                data = tools.OPEN_URL(url)

            if not data or data.strip() == "":
                tools.log(f"Resposta vazia ou inválida para {url}. Ignorando categoria {category_id}.")
                return 0

            try:
                parsed_data = json.loads(data)
            except json.JSONDecodeError as e:
                tools.log(f"Erro ao parsear JSON de {url}: {e}. Dados: {data[:200]}...")
                return 0

            for item in parsed_data:
                values = [item.get(col, "Unknown") for col in columns]
                values.append(datetime.now())
                placeholders = ", ".join(["?"] * len(values))
                cursor.execute(f"""
                    INSERT OR REPLACE INTO {table_name} ({', '.join(columns)}, last_updated)
                    VALUES ({placeholders})
                """, values)

        if category_id is not None:
            cursor.execute(f"SELECT COUNT(*) FROM {table_name} WHERE category_id=?", (category_id,))
        else:
            cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
        total_items = cursor.fetchone()[0]
        return total_items

    def fetch_all_and_cache(self):
        """Atualiza todo o cache (usado raramente)."""
        progress_bg = xbmcgui.DialogProgressBG()
        progress_bg.create("Elysium", "Atualizando cache em segundo plano...")

        with db_lock:
            conn = sqlite3.connect(DB_PATH1, timeout=10, check_same_thread=False)
            cursor = conn.cursor()

            try:
                total_stages = 3
                current_stage = 0

                # === LIVE TV ===
                progress_bg.update(0, "Carregando Live TV...")
                with http_semaphore:
                    live_categories = tools.OPEN_URL(live_cat)
                live_parsed = json.loads(live_categories) if live_categories else []
                for i, item in enumerate(live_parsed):
                    category_id = item['category_id']
                    category_name = item['category_name']
                    cursor.execute("""
                        INSERT OR REPLACE INTO live_tv_categories (category_id, category_name, last_updated)
                        VALUES (?, ?, ?)
                    """, (category_id, category_name, datetime.now()))
                    self.fetch_and_cache_data(
                        f"{live_streams}{category_id}",
                        "live_tv",
                        ["stream_id", "epg_channel_id", "name", "stream_icon", "category_id"],
                        cursor,
                        category_id
                    )
                    progress = int(((i + 1) / len(live_parsed)) * (100 / total_stages))
                    progress_bg.update(progress, f"Live TV: {i + 1}/{len(live_parsed)} categorias")

                # === VOD ===
                current_stage += 1
                progress_bg.update(int((current_stage / total_stages) * 100), "Carregando VOD...")
                with http_semaphore:
                    vod_categories = tools.OPEN_URL(vod_cat)
                vod_parsed = json.loads(vod_categories) if vod_categories else []
                for i, item in enumerate(vod_parsed):
                    category_id = item['category_id']
                    category_name = item['category_name']
                    cursor.execute("""
                        INSERT OR REPLACE INTO vod_categories (category_id, category_name, last_updated)
                        VALUES (?, ?, ?)
                    """, (category_id, category_name, datetime.now()))
                    self.fetch_and_cache_data(
                        f"{vod_streams}{category_id}",
                        "vod",
                        ["stream_id", "name", "stream_icon", "category_id", "container_extension"],
                        cursor,
                        category_id
                    )
                    progress = int(((i + 1) / len(vod_parsed)) * (100 / total_stages) + (100 / total_stages))
                    progress_bg.update(progress, f"VOD: {i + 1}/{len(vod_parsed)} categorias")

                # === SERIES ===
                current_stage += 1
                progress_bg.update(int((current_stage / total_stages) * 100), "Carregando Séries...")
                with http_semaphore:
                    series_categories = tools.OPEN_URL(series_cat)
                series_parsed = json.loads(series_categories) if series_categories else []
                for i, item in enumerate(series_parsed):
                    category_id = item['category_id']
                    category_name = item['category_name']
                    cursor.execute("""
                        INSERT OR REPLACE INTO tv_series_categories (category_id, category_name, last_updated)
                        VALUES (?, ?, ?)
                    """, (category_id, category_name, datetime.now()))
                    self.fetch_and_cache_data(
                        f"{series_list}{category_id}",
                        "tv_series",
                        ["series_id", "name", "cover", "category_id"],
                        cursor,
                        category_id
                    )
                    progress = int(((i + 1) / len(series_parsed)) * (100 / total_stages) + (2 * (100 / total_stages)))
                    progress_bg.update(progress, f"Séries: {i + 1}/{len(series_parsed)} categorias")

                conn.commit()
                progress_bg.update(100, "Cache atualizado com sucesso!")

            finally:
                progress_bg.close()
                conn.close()

    def load_cat_data_from_db(self, table_name):
        key = f"cat:{table_name}"
        cached = get_from_ram_cache(key)
        if cached:
            return cached
        with db_lock:
            conn = sqlite3.connect(DB_PATH1, timeout=10, check_same_thread=False)
            cursor = conn.cursor()
            cursor.execute(f"SELECT category_id, category_name FROM {table_name}")
            data = cursor.fetchall()
            conn.close()
        set_to_ram_cache(key, data)
        return data

    def load_data_from_db(self, table_name, category_id):
        key = f"data:{table_name}:{category_id}"
        cached = get_from_ram_cache(key)
        if cached:
            return cached
        with db_lock:
            conn = sqlite3.connect(DB_PATH1, timeout=10, check_same_thread=False)
            cursor = conn.cursor()
            cursor.execute(f"SELECT * FROM {table_name} WHERE category_id=?", (category_id,))
            data = cursor.fetchall()
            conn.close()
        set_to_ram_cache(key, data)
        return data


# === FUNÇÕES DE ATUALIZAÇÃO ===

def silent_cache_update():
    def update_cache():
        try:
            tools.log("Starting silent cache update.")
            with db_lock:
                conn = sqlite3.connect(DB_PATH1, timeout=10, check_same_thread=False)
                cursor = conn.cursor()
                cursor.execute("CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT)")
                cursor.execute("SELECT value FROM metadata WHERE key='last_update'")
                result = cursor.fetchone()

                if result:
                    last_update = datetime.strptime(result[0], "%Y-%m-%d %H:%M:%S")
                    if (datetime.now() - last_update).total_seconds() <= 48 * 3600:
                        tools.log("Cache is up-to-date; no update required.")
                        conn.close()
                        return

            # Baixar dados fora do lock
            with http_semaphore:
                series_categories = tools.OPEN_URL(series_cat)
            series_parsed = json.loads(series_categories) if series_categories else []

            with db_lock:
                conn = sqlite3.connect(DB_PATH1, timeout=10, check_same_thread=False)
                cursor = conn.cursor()
                for item in series_parsed:
                    category_id = item['category_id']
                    category_name = item['category_name']
                    cursor.execute("""
                        INSERT OR REPLACE INTO tv_series_categories (category_id, category_name, last_updated)
                        VALUES (?, ?, ?)
                    """, (category_id, category_name, datetime.now()))

                    cm = CacheManager()
                    cm.fetch_and_cache_data(
                        f"{series_list}{category_id}",
                        "tv_series",
                        ["series_id", "name", "cover", "category_id"],
                        cursor,
                        category_id
                    )

                cursor.execute("""
                    INSERT OR REPLACE INTO metadata (key, value)
                    VALUES ('last_update', ?)
                """, (datetime.now().strftime("%Y-%m-%d %H:%M:%S"),))
                conn.commit()
                conn.close()

            tools.log("Silent cache update concluído.")

        except Exception as e:
            tools.log(f"Falha na atualização silenciosa do cache: {e}")

    threading.Thread(target=update_cache, daemon=True).start()


def manual_cache_update():
    dialog = xbmcgui.DialogProgress()
    dialog.create("Atualizando o Cache", "Iniciando...")

    try:
        tools.log("Iniciando atualização manual do cache.")
        cm = CacheManager()
        cm.fetch_all_and_cache()

        dialog.update(100, "Concluído!")
        xbmcgui.Dialog().ok("Cache Atualizado", "Dados carregados com sucesso.")

    except Exception as e:
        tools.log(f"Erro na atualização manual: {e}")
        xbmcgui.Dialog().notification("Erro", str(e), xbmcgui.NOTIFICATION_ERROR)
    finally:
        dialog.close()


# === FUNÇÕES AUXILIARES ===

def get_total_channels_in_category(category_id):
    with db_lock:
        conn = sqlite3.connect(DB_PATH1, timeout=10, check_same_thread=False)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM live_tv WHERE category_id=?", (category_id,))
        total = cursor.fetchone()[0]
        conn.close()
        return total

def get_total_movies_in_category(category_id):
    with db_lock:
        conn = sqlite3.connect(DB_PATH1, timeout=10, check_same_thread=False)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM vod WHERE category_id=?", (category_id,))
        total = cursor.fetchone()[0]
        conn.close()
        return total

def get_total_shows_in_category(category_id):
    with db_lock:
        conn = sqlite3.connect(DB_PATH1, timeout=10, check_same_thread=False)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM tv_series WHERE category_id=?", (category_id,))
        total = cursor.fetchone()[0]
        conn.close()
        return total
