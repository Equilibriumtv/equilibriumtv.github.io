#############################=IMPORTS=######################################
# Kodi Specific
import xbmc  # type: ignore
import xbmcvfs  # type: ignore
import xbmcaddon  # type: ignore
import xbmcgui  # type: ignore
import xbmcplugin  # type: ignore

# Python Standard
import os
import re
import sys
import time
import json
import base64
import shutil
import sqlite3
import urllib.request
import urllib.parse
import xml.etree.ElementTree as ET
import threading
from datetime import datetime
from urllib.parse import urlparse, parse_qs
from concurrent.futures import ThreadPoolExecutor

# Addon Specific
from resources.modules import control, tools, variables
############################################################################

XMLTV_URL = variables.XMLTV_URL
DB_PATH = variables.DB_PATH
ADDONDATA = variables.ADDONDATA

# Lock global para operações de escrita no banco de EPG (thread-safe)
_epg_db_lock = threading.Lock()


class EPGUpdater:
    def __init__(self):
        self.db_path = DB_PATH
        self.xmltv_url = XMLTV_URL

    def setup_database(self):
        """Setup do banco de dados EPG"""
        with _epg_db_lock:
            conn = sqlite3.connect(self.db_path, timeout=10)
            cursor = conn.cursor()
            cursor.execute('''CREATE TABLE IF NOT EXISTS epg (
                                channel_id TEXT,
                                title TEXT,
                                start_time DATETIME,
                                end_time DATETIME,
                                description TEXT)''')
            conn.commit()
            conn.close()

    def is_db_empty(self):
        """Verifica se o banco está vazio"""
        try:
            conn = sqlite3.connect(self.db_path, timeout=10)
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM epg")
            count = cursor.fetchone()[0]
            conn.close()
            return count == 0
        except Exception as e:
            xbmc.log(f"Erro ao verificar DB: {e}")
            return True

    def download_and_parse_xmltv(self):
        """Baixa e processa o XMLTV"""
        self.setup_database()
        try:
            xbmc.log("EPG: Baixando dados XMLTV...")
            response = tools.OPEN_URL(self.xmltv_url)
            if not response:
               xbmc.log("EPG: Falha ao baixar XMLTV. Ignorando atualização automática.")
               return  # sai da função sem tentar parsear


            xmltv_file = os.path.join(ADDONDATA, "xmltv.xml")
            with open(xmltv_file, "w", encoding="utf-8") as f:
                f.write(response)

            xbmc.log("EPG: Analisando e salvando dados XMLTV...")
            self.parse_and_save_xmltv(xmltv_file)
        except Exception as e:
            xbmc.log(f"Falha ao buscar XMLTV: {e}")

    def parse_and_save_xmltv(self, xmltv_file):
        """Processa e salva os dados XMLTV no banco"""
        if not os.path.exists(xmltv_file) or os.path.getsize(xmltv_file) == 0:
            xbmc.log("EPG: XMLTV inexistente ou vazio. Abortando parse.")
            return

        with _epg_db_lock:
            conn = sqlite3.connect(self.db_path, timeout=10)
            cursor = conn.cursor()
            cursor.execute("DELETE FROM epg")

            try:
                tree = ET.parse(xmltv_file)
                root = tree.getroot()
            except Exception as e:
                xbmc.log(f"EPG: Erro ao analisar XMLTV: {e}")
                raise Exception("Falha ao analisar o arquivo XMLTV. O arquivo pode estar corrompido ou incompleto.")


            for programme in root.findall("programme"):
                channel_id = programme.get("channel")
                start_time = self.parse_xmltv_time(programme.get("start"))
                end_time = self.parse_xmltv_time(programme.get("stop"))
                title = programme.find("title").text if programme.find("title") is not None else "No Title"
                description = programme.find("desc").text if programme.find("desc") is not None else "No Description"

                if start_time and end_time:
                    cursor.execute("""
                        INSERT INTO epg (channel_id, start_time, end_time, title, description)
                        VALUES (?, ?, ?, ?, ?)
                    """, (channel_id, start_time, end_time, title, description))

            conn.commit()
            conn.close()
            xbmc.log("EPG: Dados XMLTV salvos com sucesso.")

    def parse_xmltv_time(self, time_str):
        if not time_str or not isinstance(time_str, str):
            return None
        try:
            parts = time_str.split(" ")
            if len(parts) != 2:
                return None

            time_raw, tz_raw = parts
            if len(tz_raw) != 5 or tz_raw[0] not in "+-":
                return None

            dt = datetime.strptime(time_raw, "%Y%m%d%H%M%S")
            sign = 1 if tz_raw[0] == '+' else -1
            tz_hours = int(tz_raw[1:3])
            tz_minutes = int(tz_raw[3:5])
            tz_offset_seconds = sign * (tz_hours * 3600 + tz_minutes * 60)

            timestamp_local = int((dt - datetime(1970, 1, 1)).total_seconds())
            timestamp_utc = timestamp_local - tz_offset_seconds
            return timestamp_utc

        except (ValueError, TypeError, OverflowError) as e:
            xbmc.log(f"plugin.video.elysium-EPG: Erro ao converter tempo XMLTV: {time_str} ({e})", xbmc.LOGDEBUG)
            return None

    def fetch_and_cache_xmltv(self):
        """Usa cache do XMLTV ou baixa se necessário"""
        xmltv_file = os.path.join(ADDONDATA, "xmltv.xml")

        if os.path.exists(xmltv_file):
            if self.is_db_empty():
                xbmc.log("EPG: DB vazio. Atualizando XMLTV...")
                self.download_and_parse_xmltv()
            else:
                xbmc.log("EPG: Usando cache local XMLTV.")
                self.parse_and_save_xmltv(xmltv_file)
        else:
            xbmc.log("EPG: XMLTV inexistente. Baixando dados.")
            self.download_and_parse_xmltv()

    def manual_update(self):
        xbmc.log(f"DEBUG: xbmc.LOGNOTICE = {getattr(xbmc, 'LOGNOTICE', 'NOT_DEFINED')}", xbmc.LOGINFO)
        xbmc.log(f"DEBUG: xbmc.log callable? {callable(getattr(tools, 'log', None))}", xbmc.LOGINFO)
        """Atualização manual com barra de progresso"""
        self.setup_database()

        progress = xbmcgui.DialogProgress()  # type: ignore
        progress.create("EPG Update", "Inicializando atualização...")

        try:
            xbmc.log("plugin.video.elysium-EPG: Iniciando atualização manual...", xbmc.LOGINFO)

            progress.update(0, "Baixando EPG...")
            url = self.xmltv_url
            req = urllib.request.Request(url)
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; WOW64) Gecko/20100101 Firefox/53.0')

            with urllib.request.urlopen(req) as response:
                total_size = int(response.getheader('Content-Length') or 50000000)
                downloaded = 0
                chunk_size = 1024
                xmltv_file = os.path.join(ADDONDATA, "xmltv.xml")

                with open(xmltv_file, "wb") as f:
                    while True:
                        chunk = response.read(chunk_size)
                        if not chunk:
                            break
                        f.write(chunk)
                        downloaded += len(chunk)
                        percent = int((downloaded / total_size) * 100)
                        progress.update(percent, f"Baixando EPG... {percent}%")
                        if progress.iscanceled():
                            raise Exception("Download cancelado pelo usuário.")

            xbmc.log("plugin.video.elysium-EPG: Dados baixados com sucesso.", xbmc.LOGINFO)
            progress.update(50, "Analisando EPG...")

            self.parse_and_save_xmltv(xmltv_file)

            progress.update(100, "EPG atualizado com sucesso!")
            xbmcgui.Dialog().notification("EPG", "Atualização concluída com sucesso!", xbmcgui.NOTIFICATION_INFO, 5000)

        except Exception as e:
            xbmc.log(f"plugin.video.elysium-EPG: Falha na atualização manual: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification("EPG", str(e), xbmcgui.NOTIFICATION_ERROR, 5000)

        finally:
            try:
                progress.close()
            except:
                pass


    def silent_update(self):
        """Atualização em segundo plano"""
        self.setup_database()
        xmltv_file = os.path.join(ADDONDATA, "xmltv.xml")

        file_age = time.time() - os.path.getmtime(xmltv_file) if os.path.exists(xmltv_file) else float('inf')

        def update_in_background():
            try:
                xbmc.log("EPG: Atualização silenciosa iniciada...")
                if file_age > (1 * 24 * 60 * 60):
                    xbmc.log("EPG: Arquivo desatualizado. Baixando novo XMLTV.")
                    self.download_and_parse_xmltv()
                    xbmc.log("EPG: Atualização silenciosa concluída.")
                else:
                    xbmc.log("EPG: Ainda atualizado. Nenhuma ação necessária.")
            except Exception as e:
                xbmc.log(f"EPG: Erro na atualização silenciosa: {e}")

        threading.Thread(target=update_in_background, daemon=True).start()

    def clear_epg_cache(self):
        """Limpa cache (DB + XMLTV)"""
        with _epg_db_lock:
            if os.path.exists(self.db_path):
                try:
                    os.remove(self.db_path)
                    xbmc.log(f"EPG: Cache DB limpo ({self.db_path})", xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log(f"EPG: Erro ao limpar cache DB: {e}", xbmc.LOGERROR)

            xmltv_file = os.path.join(ADDONDATA, "xmltv.xml")
            if os.path.exists(xmltv_file):
                try:
                    os.remove(xmltv_file)
                    xbmc.log(f"EPG: Cache XMLTV limpo ({xmltv_file})", xbmc.LOGINFO)
                except Exception as e:
                    xbmc.log(f"EPG: Erro ao limpar XMLTV: {e}", xbmc.LOGERROR)

        return True
