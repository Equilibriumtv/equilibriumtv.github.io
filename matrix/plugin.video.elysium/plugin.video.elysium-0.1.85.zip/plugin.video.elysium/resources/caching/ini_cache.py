# ini_cache.py (versão revisada)
import sqlite3
import time
import json
import xbmc  # type: ignore
import os
import xbmcaddon, xbmcvfs, xbmcgui  # type: ignore
from datetime import datetime, timedelta
from resources.modules import control, tools, variables  # type: ignore
import threading

# === LOCKS / SEMAFORES ===
db_lock = threading.RLock()  # RLock para segurança em reentrância
http_semaphore = threading.Semaphore(1)  # 1 por padrão (internet ruim). Pode aumentar se quiser.

# Configurações
ADDON = xbmcaddon.Addon()
ADDONPATH = ADDON.getAddonInfo("path")
ADDON_NAME = ADDON.getAddonInfo("name")
ADDON_ID = ADDON.getAddonInfo('id')
HOME = xbmcvfs.translatePath('special://home/')
ADDONS = os.path.join(HOME, 'addons')
USERDATA = os.path.join(HOME, 'userdata')
PLUGIN = os.path.join(ADDONS, ADDON_ID)
PACKAGES = os.path.join(ADDONS, 'packages')
ADDONDATA = os.path.join(USERDATA, 'addon_data', ADDON_ID)

DB_PATH1 = os.path.join(ADDONDATA, "media_cache.db")
UPDATE_INTERVAL = 48 * 60 * 60  # 48 hours

if not os.path.exists(ADDONDATA):
    os.makedirs(ADDONDATA)

# RAM cache (thread-safe)
RAM_CACHE = {}
RAM_CACHE_LOCK = threading.Lock()
RAM_CACHE_TTL = 3600  # 1 hora

def get_from_ram_cache(key):
    with RAM_CACHE_LOCK:
        entry = RAM_CACHE.get(key)
        if entry:
            data, timestamp = entry
            if (time.time() - timestamp) < RAM_CACHE_TTL:
                return data
            else:
                del RAM_CACHE[key]
    return None

def set_to_ram_cache(key, data):
    with RAM_CACHE_LOCK:
        RAM_CACHE[key] = (data, time.time())

# Variáveis externas derivadas do módulo variables (atualizáveis)
def _vars_refresh():
    # pega valores atuais dinamicamente
    return {
        'dns': getattr(variables, 'dns', None),
        'username': getattr(variables, 'username', None),
        'password': getattr(variables, 'password', None),
        'panel_api': getattr(variables, 'panel_api', None),
        'player_api': getattr(variables, 'player_api', None),
        'live_cat': getattr(variables, 'live_cat', None),
        'live_streams': getattr(variables, 'live_streams', None),
        'vod_cat': getattr(variables, 'vod_cat', None),
        'vod_streams': getattr(variables, 'vod_streams', None),
        'series_cat': getattr(variables, 'series_cat', None),
        'series_list': getattr(variables, 'series_list', None),
    }

# -----------------------------
# Helper SQLite functions
# -----------------------------
def open_conn():
    """Abre conexão com PRAGMAs adequados."""
    conn = sqlite3.connect(DB_PATH1, timeout=30, check_same_thread=False)
    cursor = conn.cursor()
    try:
        # Melhorar comportamento de bloqueio
        cursor.execute("PRAGMA journal_mode=WAL;")
        cursor.execute("PRAGMA synchronous=NORMAL;")
        cursor.execute("PRAGMA busy_timeout=60000;")  # 60s
        conn.commit()
    except Exception:
        pass
    return conn

def execute_with_retry(conn, sql, params=(), retries=6, base_delay=0.05):
    """Executa SQL com retry exponencial ao detectar database is locked."""
    attempt = 0
    while True:
        try:
            cur = conn.cursor()
            cur.execute(sql, params)
            return cur
        except sqlite3.OperationalError as e:
            msg = str(e).lower()
            if 'locked' in msg or 'database is locked' in msg:
                if attempt >= retries:
                    raise
                sleep_t = base_delay * (2 ** attempt)
                time.sleep(sleep_t)
                attempt += 1
                continue
            else:
                raise
        except Exception:
            raise

def executemany_with_retry(conn, sql, seq_of_params, retries=6, base_delay=0.05):
    attempt = 0
    while True:
        try:
            cur = conn.cursor()
            cur.executemany(sql, seq_of_params)
            return cur
        except sqlite3.OperationalError as e:
            msg = str(e).lower()
            if 'locked' in msg:
                if attempt >= retries:
                    raise
                sleep_t = base_delay * (2 ** attempt)
                time.sleep(sleep_t)
                attempt += 1
                continue
            else:
                raise

# -----------------------------
# Singleton CacheManager
# -----------------------------
_cache_manager_singleton = None
_cache_manager_lock = threading.Lock()

def get_cache_manager():
    global _cache_manager_singleton
    with _cache_manager_lock:
        if _cache_manager_singleton is None:
            _cache_manager_singleton = CacheManager()
        return _cache_manager_singleton

class CacheManager:
    def __init__(self):
        # garante pasta
        if not os.path.exists(ADDONDATA):
            os.makedirs(ADDONDATA)
        # cria esquema básico (uma vez)
        self._ensure_db_schema()

    def _ensure_db_schema(self):
        with db_lock:
            conn = open_conn()
            cursor = conn.cursor()
            cursor.execute('''CREATE TABLE IF NOT EXISTS live_tv_categories (
                                category_id TEXT PRIMARY KEY,
                                category_name TEXT,
                                last_updated DATETIME)''')
            cursor.execute('''CREATE TABLE IF NOT EXISTS vod_categories (
                                category_id TEXT PRIMARY KEY,
                                category_name TEXT,
                                last_updated DATETIME)''')
            cursor.execute('''CREATE TABLE IF NOT EXISTS tv_series_categories (
                                category_id TEXT PRIMARY KEY,
                                category_name TEXT,
                                last_updated DATETIME)''')

            cursor.execute('''CREATE TABLE IF NOT EXISTS live_tv (
                                stream_id TEXT PRIMARY KEY,
                                epg_channel_id TEXT,
                                name TEXT,
                                stream_icon TEXT,
                                category_id TEXT,
                                last_updated DATETIME)''')

            cursor.execute('''CREATE TABLE IF NOT EXISTS vod (
                                stream_id TEXT PRIMARY KEY,
                                name TEXT,
                                stream_icon TEXT,
                                category_id TEXT,
                                container_extension TEXT,
                                last_updated DATETIME)''')

            cursor.execute('''CREATE TABLE IF NOT EXISTS tv_series (
                                series_id TEXT PRIMARY KEY,
                                name TEXT,
                                cover TEXT,
                                category_id TEXT,
                                last_updated DATETIME)''')

            cursor.execute("CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT)")
            conn.commit()
            conn.close()

    def clear_all_cache(self):
        """Remove arquivo DB e limpa RAM cache."""
        try:
            with db_lock:
                if os.path.exists(DB_PATH1):
                    os.remove(DB_PATH1)
                    xbmc.log(f"[Elysium Cache] Cache limpo: {DB_PATH1}", xbmc.LOGINFO)
                with RAM_CACHE_LOCK:
                    RAM_CACHE.clear()
                    xbmc.log(f"[Elysium Cache] Cache em RAM limpo.", xbmc.LOGINFO)
            # recria esquema
            self._ensure_db_schema()
            return True
        except Exception as e:
            xbmc.log(f"[Elysium Cache] Erro ao limpar cache: {e}", xbmc.LOGERROR)
            return False

    # -----------------------------
    # Utilitário que atualiza uma categoria: faz download fora do lock e escrita dentro do lock
    # -----------------------------
    def _download_category_items(self, url):
        """Faz o download e parse do JSON; retorna lista (ou [])"""
        if not url:
            return []
        with http_semaphore:
            data = tools.OPEN_URL(url)
        if not data:
            return []
        try:
            parsed = json.loads(data)
            return parsed if isinstance(parsed, list) else parsed
        except Exception as e:
            tools.log(f"Erro parseando JSON de {url}: {e}")
            return []

    def fetch_all_and_cache(self):
        """Atualiza todo o cache: baixa categorias e seus itens. Redes e downloads FORA do db_lock."""
        progress_bg = xbmcgui.DialogProgressBG()
        progress_bg.create("Elysium", "Atualizando cache em segundo plano...")

        try:
            vars_now = _vars_refresh()

            # 1) Baixa as listas de categorias fora do lock
            with http_semaphore:
                live_categories_data = tools.OPEN_URL(vars_now.get('live_cat') or "")
                vod_categories_data = tools.OPEN_URL(vars_now.get('vod_cat') or "")
                series_categories_data = tools.OPEN_URL(vars_now.get('series_cat') or "")

            live_parsed = json.loads(live_categories_data) if live_categories_data else []
            vod_parsed = json.loads(vod_categories_data) if vod_categories_data else []
            series_parsed = json.loads(series_categories_data) if series_categories_data else []

            total_steps = max(1, len(live_parsed) + len(vod_parsed) + len(series_parsed))
            step = 0

            # Para cada categoria: baixar itens (fora do lock), depois INSERIR em lote dentro do lock
            # === LIVE TV ===
            for item in live_parsed:
                step += 1
                category_id = item.get('category_id')
                category_name = item.get('category_name')
                progress_bg.update(int((step / total_steps) * 100), f"Live TV: {category_name}")

                # Baixa os streams dessa categoria (fora do DB lock)
                streams = self._download_category_items(f"{vars_now.get('live_streams')}{category_id}")

                # Prepara dados para inserção
                insert_rows = []
                for s in streams:
                    insert_rows.append((
                        s.get('stream_id'),
                        s.get('epg_channel_id'),
                        s.get('name'),
                        s.get('stream_icon'),
                        s.get('category_id'),
                        datetime.now()
                    ))

                # Agora gravar no DB com lock e com retries
                with db_lock:
                    conn = open_conn()
                    try:
                        execute_with_retry(conn, """
                            INSERT OR REPLACE INTO live_tv_categories (category_id, category_name, last_updated)
                            VALUES (?, ?, ?)
                        """, (category_id, category_name, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
                        if insert_rows:
                            executemany_with_retry(conn, """
                                INSERT OR REPLACE INTO live_tv (stream_id, epg_channel_id, name, stream_icon, category_id, last_updated)
                                VALUES (?, ?, ?, ?, ?, ?)
                            """, insert_rows)
                        conn.commit()
                    finally:
                        conn.close()

            # === VOD ===
            for item in vod_parsed:
                step += 1
                category_id = item.get('category_id')
                category_name = item.get('category_name')
                progress_bg.update(int((step / total_steps) * 100), f"VOD: {category_name}")

                streams = self._download_category_items(f"{vars_now.get('vod_streams')}{category_id}")
                insert_rows = []
                for s in streams:
                    insert_rows.append((
                        s.get('stream_id'),
                        s.get('name'),
                        s.get('stream_icon'),
                        s.get('category_id'),
                        s.get('container_extension'),
                        datetime.now()
                    ))
                with db_lock:
                    conn = open_conn()
                    try:
                        execute_with_retry(conn, """
                            INSERT OR REPLACE INTO vod_categories (category_id, category_name, last_updated)
                            VALUES (?, ?, ?)
                        """, (category_id, category_name, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
                        if insert_rows:
                            executemany_with_retry(conn, """
                                INSERT OR REPLACE INTO vod (stream_id, name, stream_icon, category_id, container_extension, last_updated)
                                VALUES (?, ?, ?, ?, ?, ?)
                            """, insert_rows)
                        conn.commit()
                    finally:
                        conn.close()

            # === SERIES ===
            for item in series_parsed:
                step += 1
                category_id = item.get('category_id')
                category_name = item.get('category_name')
                progress_bg.update(int((step / total_steps) * 100), f"Séries: {category_name}")

                streams = self._download_category_items(f"{vars_now.get('series_list')}{category_id}")
                insert_rows = []
                for s in streams:
                    insert_rows.append((
                        s.get('series_id'),
                        s.get('name'),
                        s.get('cover'),
                        s.get('category_id'),
                        datetime.now()
                    ))
                with db_lock:
                    conn = open_conn()
                    try:
                        execute_with_retry(conn, """
                            INSERT OR REPLACE INTO tv_series_categories (category_id, category_name, last_updated)
                            VALUES (?, ?, ?)
                        """, (category_id, category_name, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
                        if insert_rows:
                            executemany_with_retry(conn, """
                                INSERT OR REPLACE INTO tv_series (series_id, name, cover, category_id, last_updated)
                                VALUES (?, ?, ?, ?, ?)
                            """, insert_rows)
                        conn.commit()
                    finally:
                        conn.close()

            progress_bg.update(100, "Cache atualizado com sucesso!")

        except Exception as e:
            tools.log(f"[Elysium Cache] Erro em fetch_all_and_cache: {e}")
        finally:
            progress_bg.close()

    def load_cat_data_from_db(self, table_name):
        key = f"cat:{table_name}"
        cached = get_from_ram_cache(key)
        if cached:
            return cached
        with db_lock:
            conn = open_conn()
            cursor = conn.cursor()
            cursor.execute(f"SELECT category_id, category_name FROM {table_name} ORDER BY category_name")
            data = cursor.fetchall()
            conn.close()
        set_to_ram_cache(key, data)
        return data

    def load_data_from_db(self, table_name, category_id):
        key = f"data:{table_name}:{category_id}"
        cached = get_from_ram_cache(key)
        if cached:
            return cached
        with db_lock:
            conn = open_conn()
            cursor = conn.cursor()
            cursor.execute(f"SELECT * FROM {table_name} WHERE category_id=?", (category_id,))
            data = cursor.fetchall()
            conn.close()
        set_to_ram_cache(key, data)
        return data

# -----------------------------
# Atualizações: silent/manual
# -----------------------------
def silent_cache_update():
    def update_cache():
        try:
            tools.log("Starting silent cache update.")
            cm = get_cache_manager()

            # Verifica last_update no DB
            with db_lock:
                conn = open_conn()
                cur = conn.cursor()
                cur.execute("SELECT value FROM metadata WHERE key='last_update'")
                result = cur.fetchone()
                conn.close()

            if result:
                try:
                    last_update = datetime.strptime(result[0], "%Y-%m-%d %H:%M:%S")
                    if (datetime.now() - last_update).total_seconds() <= UPDATE_INTERVAL:
                        tools.log("Cache is up-to-date; no update required.")
                        return
                except Exception:
                    pass

            # Se precisa atualizar, executa de forma incremental (CacheManager faz downloads fora do lock)
            cm.fetch_all_and_cache()

            # grava last_update
            with db_lock:
                conn = open_conn()
                execute_with_retry(conn, "INSERT OR REPLACE INTO metadata (key, value) VALUES ('last_update', ?)", (datetime.now().strftime("%Y-%m-%d %H:%M:%S"),))
                conn.commit()
                conn.close()

            tools.log("Silent cache update concluído.")

        except Exception as e:
            tools.log(f"Falha na atualização silenciosa do cache: {e}")

    threading.Thread(target=update_cache, daemon=True).start()

def manual_cache_update():
    dialog = xbmcgui.DialogProgress()
    dialog.create("Atualizando o Cache", "Iniciando...")
    try:
        tools.log("Iniciando atualização manual do cache.")
        cm = get_cache_manager()
        cm.fetch_all_and_cache()
        dialog.update(100, "Concluído!")
        xbmcgui.Dialog().ok("Cache Atualizado", "Dados carregados com sucesso.")
    except Exception as e:
        tools.log(f"Erro na atualização manual: {e}")
        xbmcgui.Dialog().notification("Erro", str(e), xbmcgui.NOTIFICATION_ERROR)
    finally:
        dialog.close()

# -----------------------------
# Funções utilitárias finais
# -----------------------------
def get_total_channels_in_category(category_id):
    with db_lock:
        conn = open_conn()
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM live_tv WHERE category_id=?", (category_id,))
        total = cursor.fetchone()[0]
        conn.close()
        return total

def get_total_movies_in_category(category_id):
    with db_lock:
        conn = open_conn()
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM vod WHERE category_id=?", (category_id,))
        total = cursor.fetchone()[0]
        conn.close()
        return total

def get_total_shows_in_category(category_id):
    with db_lock:
        conn = open_conn()
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM tv_series WHERE category_id=?", (category_id,))
        total = cursor.fetchone()[0]
        conn.close()
        return total
# -----------------------------
# Atualização automática do EPG (a cada 1 hora)
# -----------------------------

import importlib

EPG_TIMESTAMP_FILE = os.path.join(ADDONDATA, 'epg_last_update.txt')
EPG_UPDATE_INTERVAL = 3600  # 1 hora em segundos

def should_update_epg():
    """Verifica se já passou 1h desde a última atualização do EPG."""
    if not os.path.exists(EPG_TIMESTAMP_FILE):
        return True
    try:
        with open(EPG_TIMESTAMP_FILE, 'r') as f:
            last_update = float(f.read().strip())
        return (time.time() - last_update) > EPG_UPDATE_INTERVAL
    except Exception:
        return True

def save_epg_timestamp():
    """Salva o horário da última atualização do EPG."""
    try:
        with open(EPG_TIMESTAMP_FILE, 'w') as f:
            f.write(str(time.time()))
    except Exception as e:
        tools.log(f"Erro ao salvar timestamp do EPG: {e}")

def silent_epg_update():
    """Atualiza o EPG em background com feedback mínimo (bolinha no canto)."""
    if not should_update_epg():
        return

    # Mostra indicador visual leve (sem travar navegação)
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")

    try:
        # Recarrega o módulo tvguide para evitar stale references
        importlib.reload(__import__('resources.gui.tvguide', fromlist=['']))
        from resources.gui import tvguide
        updater = tvguide.EPGUpdater()
        updater.manual_update()
        save_epg_timestamp()
        tools.log("EPG atualizado automaticamente.")
    except Exception as e:
        tools.log(f"Erro na atualização automática do EPG: {e}")
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")

def start_background_epg_check(delay_sec=15):
    """
    Inicia verificação do EPG em background.
    delay_sec: espera antes de verificar (evita sobrecarga na inicialização).
    """
    def worker():
        time.sleep(delay_sec)
        silent_epg_update()
    thread = threading.Thread(target=worker, daemon=True)
    thread.start()
