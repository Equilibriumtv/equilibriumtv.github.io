import os, sqlite3, time
import xbmc, xbmcvfs, xbmcaddon, xbmcgui, xbmcplugin  # type: ignore
from resources.modules import control, tools, variables, popup
from resources.caching import ini_cache, eqp_cache
import shutil


def addonsettings(typ):
	if typ == "clearcache":
		tools.clear_cache()

	elif typ == "AS":
		xbmc.executebuiltin('Addon.OpenSettings(%s)' % variables.ADDON_ID)

	elif typ == "ADS":
		dialog = xbmcgui.Dialog().select(
			'Editar configurações avançadas',
			[
				'Abrir AutoConfig',
				'Ativar AS para Fire TV Stick',
				'Ativar AS para Fire TV',
				'Ativar AS para dispositivos com 1GB de RAM ou menos',
				'Ativar AS para dispositivos com 2GB de RAM ou mais',
				'Ativar AS para Nvidia Shield',
				'Desativar AS'
			]
		)

		if dialog == 0:
			advancedsettings('auto')
		elif dialog == 1:
			advancedsettings('stick')
			tools.ASln()
		elif dialog == 2:
			advancedsettings('firetv')
			tools.ASln()
		elif dialog == 3:
			advancedsettings('lessthan')
			tools.ASln()
		elif dialog == 4:
			advancedsettings('morethan')
			tools.ASln()
		elif dialog == 5:
			advancedsettings('shield')
			tools.ASln()
		elif dialog == 6:
			advancedsettings('remove')
			xbmcgui.Dialog().ok(variables.ADDON_NAME, 'Configurações avançadas removidas')

	elif typ == "ADS2":
		dialog = xbmcgui.Dialog().select(
			'Selecione seu dispositivo ou o mais próximo dele',
			[
				'Open AutoConfig',
				'Fire TV Stick',
				'Fire TV',
				'1GB Ram or Lower',
				'2GB Ram or Higher',
				'Nvidia Shield'
			]
		)
		if dialog == 0:
			advancedsettings('auto')
			tools.ASln()
		elif dialog == 1:
			advancedsettings('stick')
			tools.ASln()
		elif dialog == 2:
			advancedsettings('firetv')
			tools.ASln()
		elif dialog == 3:
			advancedsettings('lessthan')
			tools.ASln()
		elif dialog == 4:
			advancedsettings('morethan')
			tools.ASln()
		elif dialog == 5:
			advancedsettings('shield')
			tools.ASln()

	elif typ == "tv":
		dialog = xbmcgui.Dialog().yesno(
			variables.ADDON_NAME,
			'Gostaria que configurássemos o Guia de TV para você?'
		)
		if dialog:
			try:
				pvrsetup()  # type: ignore
			except:
				pass
			xbmcgui.Dialog().ok(
				variables.ADDON_NAME,
				'Integração PVR concluída, reinicie o Kodi para que as alterações tenham efeito'
			)

	elif typ == "Itv":
		xbmc.executebuiltin('InstallAddon(pvr.iptvsimple)')

	elif typ == "ST":
		try:
			speedtest.speedtest()  # type: ignore
		except:
			pass

	elif typ == "XXX":
		if control.setting('hidexxx') == 'true':
			pas = tools.keypopup('Enter Adult Password:')
			if pas == control.setting('xxx_pw'):
				control.setSetting('hidexxx', 'false')
				xbmc.executebuiltin('Container.Refresh')
		else:
			control.setSetting('hidexxx', 'true')
			xbmc.executebuiltin('Container.Refresh')

	elif typ == "GUI":
		if xbmcaddon.Addon().getSetting('gui') == 'true':
			control.setSetting('gui', 'false')
			xbmc.executebuiltin('Container.Refresh')
		else:
			control.setSetting('gui', 'true')
			xbmc.executebuiltin('Container.Refresh')

	elif typ == "LO":
		control.setSetting('DNS', '')
		control.setSetting('Username', '')
		control.setSetting('Password', '')
		xbmc.executebuiltin('XBMC.ActivateWindow(Videos,addons://sources/video/)')
		control.setSetting('first_run', 'true')

		time.sleep(1)
		DB_PATH = os.path.join(variables.ADDONDATA, "epg_cache.db")
		DB_PATH1 = os.path.join(variables.ADDONDATA, "media_cache.db")

		try:
			conn = sqlite3.connect(DB_PATH)
			conn.close()
			conn = sqlite3.connect(DB_PATH1)
			conn.close()
		except sqlite3.Error as e:
			tools.log(f"Error closing DB connection: {e}")

		userdata_path = os.path.join(xbmcvfs.translatePath(variables.ADDONDATA))
		cache_dirs = ['media_cache.db', 'epg_cache.db', 'xmltv.xml', 'user.json']

		for item in cache_dirs:
			item_path = os.path.join(userdata_path, item)
			if os.path.exists(item_path):
				if os.path.isdir(item_path):
					try:
						shutil.rmtree(item_path)
					except:
						pass
				else:
					try:
						os.remove(item_path)
					except:
						pass

		xbmc.executebuiltin('Container.Refresh')

	elif typ == "RefM3U":
		try:
			variables.DP.create(variables.ADDON_NAME, "Please Wait")
		except:
			pass
		tools.gen_m3u(variables.panel_api, variables.M3U_PATH)

	elif typ == "TEST":
		try:
			tester()  # type: ignore
		except:
			pass


def advancedsettings(device):
	if device == 'stick':
		file = open(os.path.join(variables.advanced_settings, 'stick.xml'))
	elif device == 'auto':
		popup.autoConfigQ()
		return
	elif device == 'firetv':
		file = open(os.path.join(variables.advanced_settings, 'firetv.xml'))
	elif device == 'lessthan':
		file = open(os.path.join(variables.advanced_settings, 'lessthan1GB.xml'))
	elif device == 'morethan':
		file = open(os.path.join(variables.advanced_settings, 'morethan1GB.xml'))
	elif device == 'shield':
		file = open(os.path.join(variables.advanced_settings, 'shield.xml'))
	elif device == 'remove':
		try:
			os.remove(variables.ADVANCED)
		except:
			pass
		return

	try:
		read = file.read()
		f = open(variables.ADVANCED, mode='w+')
		f.write(read)
		f.close()
	except:
		pass


def cache(_type):
	if _type == 'cat_cache':
		ini_cache.manual_cache_update()
	elif _type == 'epg_cache':
		epg = eqp_cache.EPGUpdater()
		epg.manual_update()

	elif _type == 'wipe_cache':
		delete_cache()
	elif _type == 'users':
		try:
			UserManager().manage_users()  # type: ignore
		except:
			pass
	elif _type == 'start_cache':
		dialog = xbmcgui.Dialog().ok(
			variables.ADDON_NAME,
			'Pressione OK para começar a configurar seu cache?\nIsso armazenará em cache todas as categorias e dados do EPG.'
		)
		if dialog:
			ini_cache.manual_cache_update()
			epg = eqp_cache.EPGUpdater()
			epg.manual_update()

		control.setSetting('first_run', 'false')
		xbmc.executebuiltin('Container.Refresh')


def delete_cache():
	time.sleep(1)
	DB_PATH = os.path.join(variables.ADDONDATA, "epg_cache.db")
	DB_PATH1 = os.path.join(variables.ADDONDATA, "media_cache.db")

	try:
		conn = sqlite3.connect(DB_PATH)
		conn.close()
		conn = sqlite3.connect(DB_PATH1)
		conn.close()
	except sqlite3.Error as e:
		tools.log(f"Error closing DB connection: {e}")

	userdata_path = os.path.join(xbmcvfs.translatePath(variables.ADDONDATA))
	cache_dirs = ['media_cache.db', 'epg_cache.db', 'xmltv.xml']

	for item in cache_dirs:
		item_path = os.path.join(userdata_path, item)
		if os.path.exists(item_path):
			if os.path.isdir(item_path):
				shutil.rmtree(item_path)
			else:
				os.remove(item_path)

	xbmcgui.Dialog().notification(
		"Cache Cleared",
		"All cache has been deleted.",
		xbmcgui.NOTIFICATION_INFO,
		5000
	)

	dialog = xbmcgui.Dialog().yesno(
		variables.ADDON_NAME,
		'Gostaria de recarregar o cache?\nSerá mais lento se você não fizer isso! \nVocê sempre pode fazer isso no menu Cache mais tarde.'
	)

	if dialog:
		dialog = xbmcgui.Dialog().yesno(
			variables.ADDON_NAME,
			'Gostaria de armazenar em cache todas as categorias?\nSerá mais lento se não o fizer! \nVocê sempre pode fazer isso no menu Cache mais tarde.'
		)
		if dialog:
			ini_cache.manual_cache_update()

		dialog = xbmcgui.Dialog().yesno(
			variables.ADDON_NAME,
			'Gostaria de baixar os dados do EPG?\nCaso contrário, ele dependerá de dados curtos do EPG. \nVocê sempre pode fazer isso no menu Cache mais tarde.'
		)

		if dialog:
			try:
				epg = tvguide.EPGUpdater()  # type: ignore
				epg.manual_update()
			except:
				pass

	del dialog
