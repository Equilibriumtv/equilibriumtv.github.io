# -*- coding: utf-8 -*-
import zlib,base64
def _x(d,k):
 o=bytearray()
 for i,b in enumerate(d):
  o.append(b^k[i%len(k)])
 return bytes(o)
_keys=[[130, 137, 41, 223, 16, 206, 5, 123, 130, 95, 22, 230, 121, 174, 15, 119], [214, 97, 225, 154, 157, 97, 32, 159, 154, 2, 118, 223, 128, 117, 19, 67], [118, 151, 250, 104, 66, 125, 111, 120, 242, 40, 161, 68, 132, 172, 236, 172]]
_d=(
    'eNoN1olP2gfDB3ArWjzfgqJ4ULk8QBF/IPfZ5V2yWkW3LNk8afa4rmneLPHW2LyJyuO5rat5wIEXTvu8tjba2aG1mR'
    'cgilhQqbCCcigq7PXA5bXWtra+/gvffL7ffMMtkmQiBxS0lL9P9komnID3aTwDTCR2fefBGDTWd1zb0y9KiAkwddFe'
    'sKprXUVRtiel+RPC5oqOyDuS9bOwueHAcjAoZRJ5P8y1NSnFap4Gs5NZ1/5ZqEM7PTMS/q/TiWy/VNIP2Sb/xeb69f'
    'izdmgVPChIWSMJ3tX2yuPVY7nV8PzA0c9UoR5XkwpYbWFWJBfkNN0yhxg1jbMMy7RvGYdJXooz8F5Im3r5y3/E4HFx'
    '13/Ik5GVZ/WvGE6RX2WEz7Xp0lP6uF69gfqffhSV6hOugZ6mGtetDu6vi7F3mQGY2UJP9bz14WaSsi2sGs+5UZdh8H'
    '/pWn+f9vI5s1aQCGnPlVWdbMrs3PdPuSUCYk5doStw63hwnfF6BA3wqDBL8R7E4G7yJJ7NMOiCPKRaeApd1fUdoI1j'
    'ISwe+sqzUknlG0ljL8rbTyxl++DrkR6E8VRmYj5pYbCyktE/1Jiwyt2H79Dvn3Bx7MucWYgsUambtDIGH/HoePClyX'
    '844Qp30wbJ+9SPEUlL7hLIUjfXG1XYkX6gjJ0Ka0G+CVLre10UR1sskU8I0gjNpcbmRk3EwVRoCR75yfPPJKEeccca'
    'abYFXQENoM5lGEu25lq1lIHp3LtptOQfMj3Vht22Y/7bHgQBGprWUngM3tE6ROEvp/LonNSI58VOrqtTYqUst4AZTB'
    '/f5qx5uuGgVYcdqEOU+AmJtkIvXbPbe5xkfJZWzbmWps5ykt2vOk6w5tUkdgQYOo6cx3kcT0yss35iBQPz5VzBcdDG'
    '+uMu+saPUSUp1NQGsDdI527ysh+0R1elcMLqhJ6UTcPEEkrVVVAlwONH89t9XHbFFvbf0i8q8VSOrmbbx+npszD7R3'
    'jpxFhSW/Yi1ezqlXPWHt6kEeMj64T7l5w2tSdtfjqKzuBmTuXqIGPayS5gsJuTGknM+qfAnWDzKiSAvj+/DB/sW4c8'
    '5ugN6/Yk428FqXBGqK7GBTHqBl/BTVpsLTwx8l81ulCXo/4ifym6HI8ERLfegzdOf9LT7V15lQR0lq5AGqZstq8D7x'
    '+G4TmfcuqKzTSluGOXMTd6uYLAC2svO4Z6dINq+uDQFwCe6CvPPMYaNAti1no/ttYvgFhXdB83v3FvjjP4O5AMpqN6'
    'oNulO9ZeSbxKHlOG9wmb/uYUtH82Y0LPmy5/L4iKbr7hjDAd1i+jN1o+p0ETyPU1loDZXYk9cbA1qVoQB+8RGlP/tE'
    '/shp1ro+7wQV8/vy1LGeu0WhPeieNJyQFouWCfq/84YOJut0Tf5bPQNqGFpLHdk9PnJHnJeI5PC1iPUG92boZ9XE0C'
    '/JGBirhj2F+dfct00+jl1BwiVQaSEV+ezuhII1JWWRaYJQJ7KlY2Hks5HwdYFN6nmfNCGU251fGBq+lGsCICwp/f3r'
    '6qWJx0pJtGIN/n8NBdt40gu0d2CLjEhTRYfshSsR5k2HjgTD9ouFkN842ZAx3BN62dzeyj0aBKuF/g9A3zVVeXYhNY'
    'EUdXQFJZUsFxmXm98RBtr/tPtn8sXJPlTtBJGzp5H2eikqEo5FyWCep29brh3jowwz+WP5O/Dd2X3JOj3t8vKscjmH'
    'LkPnjrY6uS7RqHlvjTMAuFb7hKt+KcrJrIq/Irwsx+t+/r3uo8YJinr1bjvw5U5FqCX+sedlIcLX5sHAItEjorNpbU'
    's1xbd1g5nkvUfXsM6E96rBiVDFLFx6bM1by/oDMhw549jSpjIwUzZQbYgXb9HcnRwgNwvGtSkJFo9EreMk/6+WyiH1'
    'F0+36AVt0jZ64+huDxOOLct3tXV1+1aVnz8jSG39fQKcE+WGHpPCZr/oWkMnjohhuqkK2Dh7OcExO7hAC+Xn9LHGBw'
    'K9wMxzI0IYjAVIJUIWZRnxp2bopm+IO497814A+0j18xl4cCqXBE7AL41HfnfGaWdSJm3yUGZ4uEb+Aad+cr+uCzGF'
    'IMG2MDO4FV0cAa3GlCMjhMxPN8GXRf17BLN0khJVQar67YiDes1Wv5dlFMOZwaYAFZKkwbvXb2cqt/ApTDFIHaKxbE'
    'Ta8Z891RZTxmzijo/+IO9X09rKMfQ+5k08KbC/bTtuStSmrfELSUjY6wCN3kF80OPe9McTMt5tOIpSwdXCluE2FeDh'
    'eVMJiUScExxeVqkvNXpnKBHF5or+CI/FIj0Sa4R4BawlepyixL2gu7QoNZ/h2UCkMBs+DVCLdDIWJ6RbllfvjAX8Dt'
    'nLEt9TZj3kSsZXIxC/n7BJtmxoU61ScBhESKBaSHqV537DCVPXlpsDzcEmQ+/M+zXjt6cPgyHYdPGStSJf69qN7hGO'
    'uivs8KCF+6Lfb5U9nYDfz680U/8RhNjSn4RdfELPngp9RkTlGOLU4CWz1r0IUdmWLvMEMiFAIZ9KOt3kZWSlEVWSGx'
    'C0V7gZvbTyQY1/gVMj/4kuj2KmlF3TsHrA7EpkFxgK1m74pJ2+EI/6iPq4QjsxTfHF06aO47ZZqGAtPZiMj6Gl3Qjv'
    'zJNnngx6uVeFCKrfj+5bWNBivv3x15QERMRuMtY8jLxU45/MMwpAQGj5zI9YAOXz0wYI16fzbeJ1KeqSs3mmTnnAFt'
    'Xjo8laKJa6/SdvWdAGtPcinwmOvqmn1fo1XRzdIMh9Eibl6bub0Nfb31xEp5OxR6J5n2peyWBO3+YLeyT8SJlSkJaR'
    'f+qjSdTWrM3DM0KYLD1xQaSldEbUsY9XDMXbjwk44yCWnM+eCEMigNoeb4fCkvOv4vs/cPCVcvJlRzkOEi4RFF7Wx7'
    'm3Q4kFwNDrre8u1p8K7IusFQPwqrjAmOu18sgRzYBuyo8+GYWgES0VR0StfLe7r49rrocgZSsJS1TZnf7dCTVmRCPD'
    'w+WJfvga061kUJH34mVoBBAR3/aCe/1iocnPMhDg1H+6QZ+QbtPmyVUy1iDovwFc0mNFYYFlulzHd/AJUR8TxV3hFY'
    'pevcIBwOs+8QaYGjN3RBf7t6FwBHS95dVhRGdusIbF9al2BPpSElMSF4S/ZepNmt/pCo/B2E80P52Gok4Urbejf24F'
    'HBXT4V8htIE7H/Si1POBuLYzOEOBnSmWQyDcq5A+Os0ojY1AXhG6jeolbSH+ig1VBUeP2N03Lj1roVfiYn0fEgyPgN'
    'D80remJjmcZDSDgqv1ngIS551UqGfpxTkcLNnBWeUubdrXL2gwGAwPwPniVLF7rrbjIRzI8uV/Lx2TMgSeixfvJ/KQ'
    '+GvkgNx/CbhaeQrdPBPcpAP6Iy6CtSW6HeZ80gudivNnClPx2jKtIlq/RqL8w5FVwFR/J/KZJc2rc07VJUi2wqHJMh'
    'zZQG6dfqX6OPW8jpTBCs/jtXmVl9bzN9UOaPy0pBN2Xr0v+0Nsjg5jFUbVDCpd+KXMFvbJMO7NvR3Dt4BF2evZdgmB'
    's8wewMfVbr54Ou/05ctiJte0dZmUm48EudrXGSncttW6iDn9klOGrWb3lm3F/ihl22SswpYycGy2/vBe2YGxao/dO+'
    'rBT09TrQXqXW3rnLP+wTVnHywuoKnWk20YQGdTSVQGOir0wgZaGvdffU7OVR/1ImSzCX7blkNLUuYrdbmOX++OjZW4'
    'YKk73tjLQ2E3jxPwmaGqPvrvUnK3xuLLCCQYVNZ2jgfzUP2DkrJvb30OSwBsjxf+s11rcUQ11iBQEEKAu8Jerdh6r0'
    'lccAjZGLVglV6av6zhOMZphfhkem3/9mO25M9GATc/40BmAHMDWg+XDTud0K6LvD0mNAGS2FewhTs+Mv4kdFPoHAuN'
    'SSOY+wW2X2BOfU1TIwL2vqhq7UZXV8oMx2f17G8GM2Z4p9Nr09C1TLSEEJngnV1KgoJlmbhbzcjsD5o4JscbIK9WbT'
    'B5jxRSCJF5yhKHbS/z5TqxjGrty7cCKrN9NcsrTdMw/YTbnsi/7aaixX9Cf35PHvZH4Uoi96Pu7NFXuz4gDtbUGQIr'
    'nE5xmqkg+OngWSYwrMFiSH62pOfZZ7G2WUkSHoHd5NTF2xoeql7qGZsdoGBvxiULbsxWCnxG6PV/+CZfnBYybiZJzx'
    'TXUXRdn9eTkbjdCA9yvchz2LwEh/NCONRrFkmtK0O609ZMfkTVwECqq78GlfvHcO04iRJZHcaAXCDOzrWu2Yd9rLtO'
    'R85gLIk27wNi4BtumgWpgfTpThAbQbChtncCCQEhmXoxTKQtyWjh7s0aOidP9U5DhCEv7M/bMeYpUw/x9qAyM/'
)
for k in reversed(_keys):
 _d=base64.b64decode(_d);_d=zlib.decompress(_d);_d=_x(_d,k)
exec(_d.decode('utf-8'))
