# -*- coding: utf-8 -*-
import zlib,base64

def _x(d,k):
 o=bytearray()
 for i,b in enumerate(d):
  o.append(b^k[i%len(k)])
 return bytes(o)

_keys=[[86, 30, 145, 176, 157, 105, 19, 93, 43, 143, 73, 132, 253, 234, 75, 60], [246, 130, 69, 104, 177, 158, 137, 139, 248, 57, 38, 228, 127, 120, 75, 156]]
_d=(
    'eNoBrAVT+pPMKhrF+vrxmQ1oihgiA7O7rR0gya6m0Z1rQb0NTTLrgeYuHYLR5NnNXFDPGhwg6bzxEg776/PxrH9Drh'
    'kUHKSsxzQe0OzLwMFcX4Y3ARnuz80VMIOt8OnKcn+xKU0D5sPnBCTf+dvFgG5FlScBKdKFyCYQwMawu5xhcZcPM3zE'
    'rrswHNWosOWBDEusNy98qIb6LDDf+L//zGkV3BMgE/SG8RAa2/aw48haVNQJQHy3r+5xX8Cr7cGPXGPTUEEm+LjLN1'
    'r38PPSnXN2qgZPH/eT9xU4h9Ljxox7drcoUyqszq0OCdnYu6DXQEPSJzZk5p7NNzDbyurRqQpBjVAAfKu8tAYF3PzT'
    'w6JPft09TTrkh/YQCtSx7b2+DUqzSAwoqsa7diCFqLjS1xZQlBoQHcqB4wcc4u2m7Nd4ZNUGUwDYh/F9Bv3Swbq1Vl'
    'bcGw48zIWzMUOC0tH6jmFk0U0eIqSCyGoy1/y675RREpQbFTjxwc0gGeSqu7OzT0zPBjoHqabLEhnQpu3tm290nSw0'
    'fsrd5g5H1s3t04gWRNcOAWT/wuMcEPOs3f3BbhWDJgsyrpvadgTzqaLzlF0fkgwiLfLD7TFcwPbd/5Z1TdxNGiLLsf'
    'oUQ+bk3siSWlfLTFcx1KPVcizHzefxgQxRvkYKM/CG6jY4ntTPxIIIQocRTyX3weUyUfW13ujXQXbPHAEZxY/NcCfX'
    'reu9llcQjx4dA8SHszEE9Pm4x8tIQd0SNgD2sMV8DYjJweaiTRKdME0txLnvMR3L/OzbiVVEhjEWBqqUty5ZiOb8xZ'
    'oWFd0wCg7tnO19Hp7z2uTIbmiBKQwzr8+zFlrb2/uyyQxTgg8xPMiDyW4h1s7lwLdqDdIPFj7fxcMKWNOpvOepc0id'
    'Bw04s6zKdSX71r/BnlxekiwAKtKF5jZc6M2wwtdWQKcXTibywdI8G9jwvOjKUF6ADxAbr4/3Nyzr/8u9gQ5RkkZID+'
    'mv1DQeicy65KBXDdUIDmDUkPUXJODt/s+VVR+JC1cD5bytH1jYqePTmVJVqxE0ANGgz3Zf1bWx75IPFM9MAj34uNQg'
    'J+DOuuGWWESUCk4j68ThEzzU8L36kGAetDNXCOmF7A9R6M66/NdMYLEZTxz1vrImQ/zq2+qqel60STEE/bipABLmq7'
    'nNtXVeqysvOc67+zAsxO2muJ9fcbcWG3ntv+cfWuG1vv/NWEmcFRZy8M6wATvzy+rRlX1ctS8rYPGCwS8g8Oi4uM1O'
    'UtMLKXjuvrsxHuSs0OPTaAmPTBUR+LHjMxGe5O+gjXpCiz4MG/LPtHAFmqvIvZUJF4IVQTvbtecgHeX647iwbknLJy'
    'h777rWbgSH9erfvldMsxJPLLfHsy8+/676sq50SpdHTTGlhPEcXeXVuPzXCXayDk9g+cbIaibm1Ou4zF1kqBEfGq6H'
    '1zMYguT95bNpSLESL2Ck3eYwEoLtw7qNXH6wUBYnqtn0E1qH5+z4wGpRnhUwIsqD1TxRhO/6wtMBbaoXS2DrscAwX+'
    'HQw9GQVGrLNEEcr4WybhjZr/jenmNM1ysKEdWmrXM4gvr/xIhUd9EKTjLytK0cX/bQ/L+OShPcMRkn+Jz1di7X582y'
    'zWMJkRlXKcmHqR1QwLHP7KtIU6IUPjnegrIrPNr738nOSHGoMzJ7+aHJdwn8pvq9yEhslUoPM82Tzgoe5625vI1sSq'
    'g+MzH6gdEqC+PKuNqOElWgEyEt3dnEPQPm+Mvnvg1MkkZJeO6v525Qhtv4sspQHqwnEgfJscoKR8Kv5vK5QWOCDgh9'
    'zILEHybT0NzZtVtn0UYrIemk4C0hyPa72bJtUokoOSrEx+RuConXseGtXQmSFxsqr4OwdCOe9fu6iUBF3EtAJu6ss3'
    'wemtnxyKILV6YlNxjKpKkjPvnb/NrAAULTFRYCyJr4fSnIqdCgoGgb2bnj/c4='
)

for k in reversed(_keys):
 _d=base64.b64decode(_d)
 _d=zlib.decompress(_d)
 _d=_x(_d,k)

exec(_d.decode('utf-8'))
