# -*- coding: utf-8 -*-
import zlib,base64

def _x(d,k):
 o=bytearray()
 for i,b in enumerate(d):
  o.append(b^k[i%len(k)])
 return bytes(o)

_keys=[[200, 150, 50, 185, 69, 254, 121, 52, 99, 137, 49, 247, 184, 129, 110, 194], [141, 248, 27, 77, 133, 50, 130, 147, 23, 235, 40, 120, 5, 181, 87, 169], [105, 13, 142, 136, 172, 249, 174, 152, 176, 175, 159, 147, 139, 248, 168, 31]]
_d=(
    'eNoN1PtTEwcCwHGsvdO5aW07/mLtVWf6g221ct70bqbjizs6dCp60E5rCwFpmZ626ljP1gfWmx4aECgiYjWJJpBQ2k'
    'oIcpSHHgIhuwlhd/OChGw2m93Nhjw3JCSkee2SZK9/wvfzw/eZtz2I5H+ZghRJ94YN1sPPXIlE88PZRZZlDbNSoLio'
    '3q/GhjDyaiadw+TYWUGJ/hfJ6FoU5YO6CYCrfrHEsgyh/HwjkvC6u5Ajb542+fIjIS7J2vy6EfDbzUfdsTtDBN8kM2'
    'TCSuzjY5do2t4ufcjCMDjZ7zm3roSNpWQ9aLMx/ANjiH/87EmYtrRGRvNrgzrrTfzVl+ujWvTuItusLWRCA0zx+0cz'
    'FonZlLCToYzaYWgQ1OuwJflslBIZPaAcrNlzmo8hbb5YftnA6qS5nU+VPyKFQ3mVJoIxmJI4u/mIiZH3LYdQycJUwk'
    'xUF1Uy84jyPtGMY1RYhXz03A7E4DcCXNrO/ujqAD/aUvNo8o6YsDWx/fGVW/cubSrHrYRIzq7ya7nceLiu+oSDzg97'
    'Ta0ioxeTx/91sDTGpkTyWJZ1cfp26a6nDhoo90xg5To75iA6XV9s/mQauDssZ3IuamHaodu9tWaORMaQVAs/5iQN+h'
    '373w6xeQ3O+mSDfcYfhBc3HzBYKbHGCmXCCAx1n1tXHjG2SHNDCfOALmdmLtYccOU5jdfjIMN4SEE17HpleTj5mA75'
    'sikWdMzu/N3hSbVE1T04lzMuM6pbpwTfIF6n0aeiiRCcBSwniwSOyZxyVnFNvOgmlS273zyN0H6F3JBiLYboeHbH9g'
    'rNhLD33oomxGlst7vOC8pBs7RNDDJOEhiRWc5tP5h/ULCKCiS9GCaHc2f27wUpWEJb2Sy7MNsOvrdF4NG6pyBaCHJJ'
    '7fe6Q4IKfeR+GxnmXGts9kbi/XWfcbMFEU80LrFabLiluORkzm82yw3pcB6elYGHXq5hTfYhzOjmxijz1FJxXQUclY'
    '9HDCg5y68CuvNb93tinChoccHKn/BB/NV9l3MU3Cd2ecIrDu3I7FfbBKwVH/SopIAfZW7P7d52Ac9LRT4b7XUOzNxb'
    'EbxU4/cgmswA1LRIUdfk/97zV3SFbaMUXo4hgY74t5sE2qBsxhKBIlB8YXLujc21oQf3+0BTzmNCCzfuVb5Q9mSa7R'
    'YnG40FnXsQrNl4OebhFCKE1uY1Oo31/PMH1UEJHFVpgoGfzRPEibpDOOccEbO8a4FdtRXKtxy1aPnu2bUWb1gVU/V8'
    '+cxp3GcZpQk6g6H6EfDi+ipIfX+GSFwFXDBxrWv3+xXTwbsWiskgy/EpoHBeUPYozz4mFUIn5LUOSKs2HsvG8xJxxM'
    'MO2pmO2FdPHwgMS3oIqikYTmu7mC9rDyF+IYDTiaYhO99O7HzxXQMPPVpOkwRrICblb+y7QnL+cTrv0zp+BB3CP20Q'
    'zExI77hVkG4xbhuInnj61ITm3mPEkXXBfdkO14Wn353RQwr5ry28McNM4Lv/8AriWzPTMU/I1WuRWa+sL89HJL2aIV'
    'gWKDgHuj7YVhIJuNp/828cMqhtunfWl3t4kyiDkEQat3YhF54tjVDJcWowvQa5Fm5Eyl6qV0e6e93K5m4WxdWBE8cu'
    'TQSEY2h8lXZmRqUrnwsEBYD9LgM2maCk9VbLkbcuU6a0REx7w6xGJ5MWF51/AkpnMPS6zJaCIc0/qip/WuiWoKMJsT'
    'UzAXR/UXSYI7KyGHfNwPWSA+Cpna+AYdhMF7IstBgdB1/fUjHnl9w20hqZMkXdDte9UDmdEH4H2u3G2XmFY+njrSUe'
    'd0HTA17D50HbMH7yrVI+gGhQ269hbP63zoaiCj+GIe6YpsdIugfCR9/5hmRwo9iSXgqhIz2SU9vL1MGksuchhCuXY5'
    '1I3b4r4FJKEaK8XBTV3qS/LqrSBu/ejC65e7ApaoA4XlqZjBFtclMaeQBPtgUOPfUZW+CUpFLemM7FlPTZfQ1JZ2B0'
    'lk2D/uRcB15dfcmyjIkddFMIy4RvYWe3XUj6FkcpNkvE7IkbmnNbTizO8QpEcd31MB16Yj288W9Za9qUpVP2QZ8eAM'
    '9sqHcFpHfSqbkeiMcau8trP5medraK47x4Qc8/1h1bd8ChLpgyEcrbjzOdkdN7dmRi+VYRnF5jDZZ2+C9F1W5g8SYX'
    'gezpn1c6NTWbalGj07ScWDUGrdP9uneLPp2LmhTBeDO/is9NIHXPnUYX0iO5x15df9I6jpwpqofUv/2faIyMpaku4k'
    'Jp3RSOi6jFrCvomQG6GorKZ+aTpjWI8o5hGlXuw73/yS0XJLncKkM4Fjr4i9tP+GdkKk1MzwRcttvGhtpKRG+XhDK5'
    'plic1/hP/b6eAz1jzqgQGfvR/aRn967S7ATbJlpL6wYZq4yq3H6YNWE9nEUYsq1GB7vOVV3qZSUjvoEs/Ss+6XB9XX'
    'SY5XNKb0JIB8KMSl+864ovZu5A4zQD2Y3d/GvPlyyp7UjzwPUcRkSvas69UIvCwlF5LGMiPfyN1V1/LDPEC0Au2YpE'
    'DaFb1JHnLueiKU0Q5gEXa24Hz28uU3tk/+VwOVtA3FP+V7cd7+1zmp0RtHFoSTGuO7Kt8ok2KxdFITqgY6bMDfv/rg'
    'dZUWg+GcyTlu7IqfWfu8nuwUC8LahcDDdyZzaVg8Pa7yKqAgynJtsDO2sEfmfW6uWv0f1aZjJ+fG8pzRYsITyVGdTq'
    'ZMKLWz9Vh+/CYUgaevhg4ft7tbX/nOjraQ0mMi7Ys+rInxQc92sRgEch0wpFdkUaNu7NkdkOcJ4Fxuywxvp69X5mWX'
    '6ToyHUmFnoYo5v+BQ0aNtoAjWYXJxMdnJdlWM1PcYDUsSGE5P64j3fTsD+Nl8+HVx0Ad34By+V6X65fxuyX11LZYyd'
    '4c/XHyENrlYqhxrIZb7N+NqLAoeB7gSUzd6HP60MSD/cczabTbVKPTQwnDbbyNdfLs+voP3E/FXAYjUPGS+9V9HLYo'
    'rIkr2JdCjG3A0bSozzrNLpaJb0z+GdwI4/76BZiwhlfXImbjYiH1Xv101IVDKVPmRMaTt1Ve+V86TrriWRxn4Y+j9z'
    'EHlD'
)

for k in reversed(_keys):
 _d=base64.b64decode(_d)
 _d=zlib.decompress(_d)
 _d=_x(_d,k)

exec(_d.decode('utf-8'))
