# -*- coding: utf-8 -*-
import zlib,base64

def _x(d,k):
 o=bytearray()
 for i,b in enumerate(d):
  o.append(b^k[i%len(k)])
 return bytes(o)

_keys=[[158, 101, 173, 129, 10, 207, 127, 203, 213, 6, 206, 221, 138, 158, 101, 81], [17, 190, 28, 218, 65, 108, 68, 200, 38, 31, 173, 77, 228, 81, 90, 223], [118, 210, 244, 39, 255, 204, 99, 188, 238, 250, 193, 245, 227, 94, 222, 181]]
_d=(
    'eNoN1PtTEwcCAGDnhlMcYw0SmvHKCdIrtEKDsSoPqVTBdpxa66PKXDtn27mrA1in500799PN7SbZJJCEEPPa7G5eG7'
    'J5kpDHkmwSEoomIAdE9OSpgoqiAUGOlx4D3n1/xJeJoT8kJeW9cVzJATNaX1SoAt9j5K5Fq1/MackKvfwjqMnsMNDm'
    '4riIL9mu7SpWqc5oprfd5wa93cbL3rF3hZ0n1Xq6ZDSm4fNrqeQBEPyHEy9sbEQBHGRhkiqr7FK7tCapc3u46HZNsp'
    'Sv3d0OMZJYlDcmYKamMgk9s1mbNwBxZQpqy9xaWRiq0mkyeFETHLEcnh/NlpnoEYIxATtF/J6chv+UTmo+1/HfuzFk'
    'E8k5tak1OgxkitBNQ5B3ztTOVD8qIX1nMfPpXsJHIpbCjvunYhAtKN20oAuKmtH8Zwv7wlA1Ydp2i0MRBmtGaPXdFv'
    'lfZGbWKCILJGwM6eIRoOuYa/30qlBkw8xp3omcWOJiJLwpAXCWxJps91iFUpKhma4ZgFxCyLEFG2e87qcr2veucmSy'
    'GFCovsEKBmgB/PCoW+mKcOqwl9VI4irlSJPw3C6OosC9ctDczbSHtq01RIWwnS2ezFyHMwZEH/ZzOiB32050hQ0Evj'
    'QjJY1R5RIGFs5NfCmYOI1IWTfialEMfbth/YhScqGN2jKMegGnIQvrynytr1W177mJujXdtsrU9D6Skx5S/OY+7lnu'
    's9Y1r5+ClFcw/7amhh4uNbY19l/2QxPdEisTNsiBkLnY3rUnRVbBxrxxvvqaxZM2N1rJt/xC8b5aafEDGF4XWs1BfJ'
    'e0hkOLfAUPuVsgeVoymcjSgReeCyRCjeHq/HgugdObjHlxvtMa9aeRax+bE99Rxu1DBp2iEy9uHzka0Zwldedmgd5l'
    '8Pbvn12v5HZdsVPvQKOOZZ2jEhsq13JrFEL6Kip3c8n3RV1slfIMJv2qV9imhhxpoVtvKQJ/DQvLFxtUXLDv0GyCyd'
    'eeQaa/GRDYcDNUgU3sCfxKl+r29gDe1QjFmr+Rr5L82anYPmAYIDxEffu9qmjgGCI914/2CIzDO9yj+XbJFRT8+v6I'
    '16a2FU0/yXot/0FmzBNBuMnQVtQxxlJ11VOijBGzcjlgZWHQ8UlNtU9SLuZapdHhzcsbbCB2EXmcOayXmE14pXQqK8'
    'VNV+C0KQ6eotqYc7f3gV3paENWyuLHO4mr2P3dD6HLZAvtGXRN3aXYob23D9BUWV9t+8+IgtdprPO8OaznMpIbe1cx'
    'rzJkrZuDDiCGbyljxmprP2AyX4Yf50Shi37podu8m3Lz7e2yVXYIPGYBz85gHKEXKPbGM439dHELS8znqixA4VNBqc'
    'r0I4UUPLf4YJ3lqn7kaCN0LihkiIEIl3M3273wsT1cT9jzkw0crw56y77CDOi/T4ZZcr1cGQWyyDcHwa6LEaTwlr8R'
    'NhL107pP+OHTOjNtdqhV1IpcefGoOKZlOpfZD/ReczNYO7/G0pJvNznyF9GYssV6mRyvsHafsJC7NnAhrOXUhl58Er'
    'Gk+/W0uF4tl/UVhF98JAscd06/k4QlwmYfw3Yn10MekxK055BTg3PSOvoqrLLjrZqscWMSjwnSFOs7JlWngtJvBgWt'
    'UvTu1tjgEQdYhZm2jQIAHrDXEWPverj1Axvpd2BKKSYr55Psh8qjFkPuG6OpFXJW8layEX4NqaPNAb0khZZp1pjypv'
    'OIcosYihJqQa1QlxvoPNqs3y+H8DAKMgSj+VbnTge59TVhkmIWFjaW/TjGaGtMG4mrXyGD2bOJInOCjrovzGNBBWy7'
    'Stwr73BlqlrS1aMyjSXAfjp+AFGdsEhPrjivL8COUoz7peraebIpbbmBgwaHS3xQBTRx3IVlxgU3ee2uLNtUrl59CT'
    'buXxRElIq2YmrtSLh7d1ifMeVuAxQhFny7WgkyUMeHvfF/LSWGN88OVYQTDJvqvZccyt5vLSLuMfQdNWLRphGeu8FM'
    'FYlvlJCBT8LIvicWvxwGK4W6z8AEo0PLegHg6vDd/OUnFZMTx+wUs2fUSnoEDK+OBZuPq6Rpb3S9TSYOkxwtsCpP2K'
    'UnRUR/c3OoeIZbFTbRUS2Nx+fAguGClifsZrCa4LAbR8JCP/H+9BoT1x8VN124Cynm4tBh+eIBmeYnF7prw69c0Dgv'
    'z4xVRRI7gzq2lHdtqWswJ7BSaZedQ1+l9wxbgWZjsbdzz7TgO7Uu/QnmbYq6M9q7yhDTSaph67/tyYU4XuiCjsa6v/'
    'CSH/TCPTjadMixWhaSfW6LMZ+hQdLpe39mqhxD/ybXlz/nUiYeWSrk7+eHMyOat1Nmn8IIVLqQaqjr79EWWkob4cLI'
    'FfdQKYgwzfav1TxHc9S6RbCWp6d2w469IixioSBWx8tSJHARQ3fNWvuEMRejfbE6arno1efxwN5Xob4c2XhZqOW0Jn'
    'R2BuC2PzCwU3eYMPfTBm1eCqKUKg9DyD8AOHdq3xSk8D7hNZA1c+9PD5XnUen+Hm4vt/vuHyQjh2NN512R9yS88ILb'
    'WpGarlg318A6llDQC6k5hba1XJnmrE1RnLK18x6ECnngKTBR6/EzpmCVGejZ7Bys5MvolscHIZTD01uysFV6R+s/VZ'
    'K8pwJKE7HWqsdLw+HdzjcfLTlNrjZr7fRqdlRGI/U1Izx1q/rW79yTJaqJE+bps2PDOPzAyJ55wYA7GSLzjh5er1IG'
    '1s/3sVS+ny3mjFd+objbUU9IPn2E1PjMrL74zaVmSY4vediqvYoGy5axIBCxFMGCzHXuT0kh8w5mc6BkfWq2krye7l'
    'J8NGL2vEZDbAKiRTU/Bxu/UYMxUWzwg2fdB/mSKncws2eEI+xwXyYe5Xo8P8q0rJs8eUPQwxA8LrA6v3Vs/HYDv65Q'
    't9aJbleDE1+g4UNSKCj3IVfapooivp8sS7Q+bVAhMDBneAwizpT7Weu8VqUaYumh//91waXZvGb1EHqCSYg/QybqUc'
    'NB3q/BV/2DP8Y2PraCdPNSWZPgGtkMsOAVhh6mKR35CdQtiXOYT3kFDyWXwooCuUXU3k39okRKsKYz/wM37yGj'
)

for k in reversed(_keys):
 _d=base64.b64decode(_d)
 _d=zlib.decompress(_d)
 _d=_x(_d,k)

exec(_d.decode('utf-8'))
