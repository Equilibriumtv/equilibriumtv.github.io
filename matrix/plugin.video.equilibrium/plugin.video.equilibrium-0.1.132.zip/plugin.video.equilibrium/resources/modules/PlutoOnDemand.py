# -*- coding: utf-8 -*-
import zlib,base64

def _x(d,k):
 o=bytearray()
 for i,b in enumerate(d):
  o.append(b^k[i%len(k)])
 return bytes(o)

_keys=[[4, 89, 44, 31, 246, 24, 18, 80, 25, 148, 139, 128, 182, 76, 144, 161], [109, 224, 177, 133, 185, 199, 227, 78, 4, 111, 103, 242, 108, 28, 81, 239]]
_d=(
    'eNoB9A0L8giuwbTvqZcbUUAEll8qKNkZgdP274CTPHBaUqYVVR6sI6XB1oGoqB9tGEyDXVob2R2R59D1lLkXYzwzwV'
    'p7YKVai4DG/K+5D1JeFME7Kh6uHqf0yo6mujt2PAKcFSop2R+l5MzYjJB2QRdRsAJ7GIcktfDt/oiiBUU6LcAvRWen'
    'Caie4IHo0nczQAGICkQmxF7LmvfAq9s0cRsAoT1TH9wYtZrBy7O5AzYJKbMqZGHbLLDF6Ouu0j1RGCjEIGU/3Cet3u'
    'va87oGVl4VxyZyJbgPq8Ds7IqoCkY2SMRHKiDdVK/d4O+muSBqCzW3G2oS2wzZ4Nbvn7keQyMypidxE4Eoy+fR/ayA'
    'PkBdEqEPXXqjN5npsOCSi2FzKSO2ASpjp1mU0ub1v6YEQyQv2UNzNd0DjP7r06zRJTI6Itk9L2OVNITW5NOtuw1+XQ'
    'adVVsmnwSE4eaWn6YaSEAks0NaIKgZpcbG2PO0F2ZWELlHdGamAKLf7PeqpnxFJwuGKGYi2guD6NTYrIEZY1tWwgFb'
    'HIoqgv7N1PGaDUg7E7Q+RDqABIXn//aqlQ13JT6GGixoqlSl29Ls8ZFlazYDpQJpOpcblIDV8aaSNDcJItlDThy4Gp'
    'SD84iyhyVtOiu8PncBlz6a6crNl7UfLx1Ipl9zFaVYiZ73jpKbKGI+UMUdT2GLBrjlw4v01RY0F1CUHC8nlTqD/dL2'
    'rrkcfiQLiglMZ4Qgr8PQwb2ANDZWUKIoVh/YC9Pl39+yrTxuPj2UBXkopieR/u3/nYAAQyEx3TgsBY0uusnTiayIKV'
    '4HHYEDd2SOBa3BwciuqDZsHgKrD3co3D/TwMvwpNsCQFxQwQpvIJldkcX0/Y3ID0UVP7EZXQGkKNjG9taqqXhlHQ6W'
    'BkQ8vziO1P3UtLQUQCUx3Q1MO98GhZqu//+AI3xaNJ0pTRPeC9T56+n0jx5sLVKzFnE+3zqS5/fbtaAaSQIGtDRoIo'
    'o41uDX+ICnYWMkEcAFUn6sB9Dd7d31zC08CS2QOkYzmhqvmrPr/4goQRomphZZJo4jsMTV8JOXIjMDM4sVZj2fXsvL'
    '4IGRmQVuWgS/Ai8XgQ+08//DoasdYiY+ixhbHbpcseCuyrShNnEXK90naDKeGqiGttWjrThpJzWZNkgh3wWS1t/LvY'
    'crSBckhAhlAq1fodP9zJ+vYTApMb46V2ihHqPm4YCouyNHKj+GKHArqEbPgNfQjaoPcCMvikNqA9gbq+nQ0KOSCnAo'
    'M4Y7TWCJGoLC/4ylqgdpGhS3HlQD3VjX+67sl4B3YgJMlyR9JoIA0sbM8L+me3xENogPcj7WWdnm3/WqkAE8WiSDIl'
    '0zwBuNh+aPhtQGQwYzp1krM7hdhda10qONIHUaMrUrcBmaLtXC0paOs3pgLgDBNEoCql2p3fSA/5shRlsklj1+Np8I'
    'tJ7X3rGLKkALEoU2cDafF6SH88CUtwpJFlK2Iy4SllWi0+/TvZZ4cBtVhyozAbgmjYGy3fSnDEwCA5gULnqXL9DV39'
    'z0gn5iDCacJWkwh12F+vHLt7k9YAg9hVV4YaIot9fQjb3IfXMuSJMWejeKXoLitsOzqTdJOQ6ER3p+lyq28vPD9qx2'
    'ThsmnV5eNL0d2dfWj6anKDM9EL9dcCSOHNDU/P+WqChxXBLZNHsnlz+x3/yS8ax3NTkzpl8kOa4elta914WqPmlAF8'
    'oddSScKIGezcyqoWU8JQ2gNS40jVql+sL3jNsLaCxQvyApZZkihsvxipezezY9H6UHKh7cBprjsNCokTtjLhSZIXNl'
    'pC6Xy+TQo4ACcF8DnBtQC7YIlYTtw4PQH0ABCJAVVBSfOKr3wu2vrCwvXleWAlIkqQaDw7zUsap2Sz4w2Tt4J4A6rt'
    'K3yo+WNE0aVrU7bz6ZWM//7M+TqxdcWiaUPn0h2yWmmt/4kdsPMj0jvV8qJ5VCpeb1/pKLPmIHHr1fNwucN9PE3Yy0'
    'pihnJzKwCVRknSepx7zYrqp7YCEKwipZPJ8/h8fBif+6NktXC8cmdh+CP9GHz+2MlgdqRB2AW08ThlSy+fLAsdUFNi'
    'ETpA5OBdlbmP3IjKWkCTcNU74fejCmVIbG9uuhmX40Jg3DXl9gixWk4c/MkNIpdxdIgwhFeooi0cO3/o/MH2JYDpAj'
    'VwGFJqbh1/ystwBvIV+RK3kopgmmw9CIi7YEcStetjxYYd9epdzfkr6lDVAEDoVcTjOBC4SF4/KjtT9nJ1erK1s2gR'
    'eM3fyJg4YcUQEypT0lFZUIt+S2gZGrCjBABLoAbmGnIY3D9emMsiBDJF/KNl8/xAqKgPDJ8bEPax4GnScvAqNa0/ay'
    '1Y+tIHUdAcYAeDOHQrLEwM6GjwdHHCjZJX4y3l6u4PbQg9cDaBYWwwJfAbYMp4n9iPWQd3UEHaQqcTuECq7WqveP1j'
    'x9CV6KCktotxSB+tbzkIckbCwRhRZSJdo9uYfPw7aLOH0cCoEAWinWWqnDvYyy0yFKKxTBNXQBwD7X1arS9K84bgtX'
    'uj0lHNkhmYLc75ayYSstIsstRmTdVKbr//GBtHpUXiafKUYQuSuzx6rDvaVhNgtevVVaIYdascfE6eiFOFwfE8AaKy'
    'OoGcvr0omJ1AViGw/AFXYorAm14MLdj5R8VQ4eqj9KN4VV1ITV7o+PNFI7Cr8mUT+JCrXZ3I6phXdcPwW1VGp+vxvP'
    'nujXoIkXfTdQsxZpAYMX0cuz3IC1dmtEIIhUWRKbLKme49eMrCJVKyjAXEYzvlWzwNzMv4A7QQUlpRRMJKoZi8vVyI'
    'jaCnQKEMofaD7cK4bI4/CDmxhgPSyZDmQbogiIhNLssKgAXj89mj1QeoQL0Pau1fGlN1YJUcMcbQugB5L/7fW+lwZS'
    'DlKnFDdlliPUyd/qjLo/dwksoxh3OKJZlsj8iKzbJHQEU7AjeQXeI4qH5taLk3twVi/FCEwJ216Hgvf/soUUQRowwi'
    'VPK6whleHCw6WrP0kOKJgEdhuNCJrw9OyRsA90HR6HWkwW21qCy8fs6IplUCwQpw1GBKMLosWx0outZW5YPbMFeh+b'
    'F6Th1+qq1As9OCWGCG46nAWz+uDIoJknbBgksS5TN4VCz9ndz6yaHk5dF8YPKyOrDJn+xoGmq2V3NRK+VGUBvCyq9b'
    'DUqqV2PERVxS9UHNg6o/XOjfWPOG42XsIEd2S6GoXG6c+J0j0zLiCDCl1m2yaN3P3xqYUIND40mT1WHsAAkp7/gfSJ'
    'PXwcFcc2MyWODtfbsZa3oSVJODO+R1oyiBSF+vTL9tM3aicRtTplfoQoi/K814LUOzEuNIU4aB23JdaC8oz/1XxeGj'
    'eKICgbgCyNx8iNkI8mXVw9qylyGtcpquXu9LSbFk8GTIcBVjeuPKWCsf6K1H1OIyGXFnEJrF3W/NGIq4kgdT4NgyBw'
    'Fto+i4PByfHWdlMJHYsGZAGZG6Pzy5L/2nlsWjaRVC4HqyjT5rfpqJYqTwIRvgdOGLlYkN/t/qmBKW4mHsMqZjiHAo'
    'b8s+6S1gpKDj+UC2kpjT2Pmq7BrJkjMgEQhyV2GIhCksD9/LOAKDBAK8dbUmSGDIjj0fqhrXpoQDPFCjMLpR3W1OT0'
    'qoUKPVcxixpLOK0C1f60jKWVNi8YFYQ4JASePYrG9PuMjT58X1+jKTMbqTWUmu+OqtAXZTU0kwRTab8Brdjk3YCsf2'
    'YiHrkDczSEBYHzwvq9jmVDJEyfI1clrTeq17X7hpAAY1ZWvRwzCaYX2IGwiImxA3FeH7kLbijEHNGCsMugkBwvWlCj'
    'Jy4Hpl+m38vRv5oYcFYTqiozB7kAmfCu44mtBUsYIIVUTQCiHoP8/4y2qQNTJS6hKHQcwDu3wc+PqpZ4TkAzsDtMPZ'
    '8nrujKwZS7YXc6NLk9bzTXCtXmtteyoTg8DSGAGEUbmz63w7yLvoscMScDxDxsF7kDj9/L0PSEDUAWIJo/RWCoGqr+'
    '4I72kCViDFexOm0gnianh9PXsrYNNiIdtgJ1Oacu2OXm6KabJlYCFJhDZnqKCtnX44u0uRtQKlXHFm1jnlrZ1aqMqa'
    '4eTSAEwwRrFqFcz4Lx16aKNnMDMcQCajKiCKb2vPWSmStDFwCGCmYHvi7WgsDM9KllRQ4DpBtSZcQX0tTc37S1Fy8M'
    'Kb4KTguqL4nf8ty/tAVKFxS/CGY8rTuT97PPgcwncScxhCJoJNgnmtS107XXClZZHp0iLAOhF4qCx9WOugRyPFKcLn'
    '0nnC6CyOjS9KEDcQM0olplN4Qpl8nnkqaVOm8aD7c0WGmpN6z3ttiAsB8wWQ6iNFIJmSmF+M7yjcwBcV0WkUdVP4Uf'
    '1N29joXaIEIeUaItTBnYI4nrw+GEih1zBg61W2Y3rjqC5vTxs4wlPT4wtyV5Hd9Up/fh7vXbFGpbDoQlaxSfBoj71/'
    '+sky8wIAOUKmkm3win0+/xsJsAaiMLkx9EGr8Zh4DAzKXIOVwYPsUYewOgVZDjz9Ks2hw3GhXLC3h+wDuOyarSpqod'
    'cDgCszQrFdgd18P3zrWUKlZEKqY6f2CqRozB/cv1hQgrGQ2FXiQJ2gqw4+L3r6Z/SxYGgVhEYK1CqMCu0YSrPUkLPr'
    'VbJDS2A7r4t8mWoRlcXlbKAi9goCGU+c7j87o4ShdVxVskYNohsoOu3qayNl4lDb5HSAG2DIvm3PuI0whwADafW2o0'
    '21/T3OiPtrMbXiIytDlOZ6E3qIbqzKjMKE9EFcZbeSCgQrKavdyMiQE3Gg+RGXA0pluQh7DKltQ5KwIduwprFpghhM'
    'bPGziBjQ=='
)

for k in reversed(_keys):
 _d=base64.b64decode(_d)
 _d=zlib.decompress(_d)
 _d=_x(_d,k)

exec(_d.decode('utf-8'))
