# -*- coding: utf-8 -*-
import zlib,base64

def _x(d,k):
 o=bytearray()
 for i,b in enumerate(d):
  o.append(b^k[i%len(k)])
 return bytes(o)

_keys=[[186, 229, 222, 126, 186, 22, 17, 199, 210, 55, 232, 42, 17, 207, 199, 112], [194, 133, 0, 106, 54, 221, 144, 158, 240, 207, 144, 148, 222, 80, 28, 70]]
_d=(
    'eNoBoBJf7afLcSRhmqHLpf31pro7WjeY/Epab5nS0L2Z0qSrPUZtmslqJlvtxsaBo6TgkjtWdoTGUhpGl9P5k/jq/6'
    'l7cHaj3GUtRpzBy7W9593mOFkQqcQ5LlueydaVvOfchBleApbAczlZ7vH3sZzH55s6KS2t4lI/ca2irJiF5N+ZBlQ2'
    'pNArKWWywfjfqf3h52dmcfHjdF8P7qesg/epoexkJByo11MoHbTay4Smv/HsZC5xoOM4PVep6bWWrNPB7QVILK/veR'
    'xyi/Kts6K/7rciS23t11c7BpbDzpSr5dmLNiwAmtVULEOwqMzHtef5vBRJI5fOVB8OltzMqfbbpqcfWX6p7nIgebL+'
    '8KeXweykJlAcjLR3UnKo6dqkosnMiWFYAajnTg5TjfX7uIGi0rIcahP2tFpbX5Df2YiG6d6nAHh/889wGQKH5/DbpK'
    'XCiGV7carqURsG6fOsm72g8aYlLwGw7GpfXu3GqLn+5MaXHF0ho7x5JF/lw+aH98XTthZ1ELroa1lkjcrSwvr87b8m'
    'VQz00GULWaX78pSWyOGYN2k2rLVNQVS5ofqKutrMmTtWAYXwOCYDj8PngPv0w6ggaDWl0E4iTK/y1oW5/N6JI2ptru'
    'kxKQ7lwNvAmODAthlRK4/OQ11sjufnn6Og7u4hdQC6601fVL7i07ql4qewJXp1hrBYPFvopaabidbGqiVMM5D1Rj1O'
    'uPnog4Okv5UlWyGx8TIGXvL41bz+5uWGCUgtrshUGgSPoayggfz2imNeE7buZV59menfpvf78a0GVwKp7XEkXYXZzI'
    'eMqNDqG0oRqv9oJnns2aiXm7u/qhxoco7BN18PjvL3xovW/KRiZXLt004TXKTK56SA4dCWHUl+oNZlXVGx4K6K+MDx'
    '7QddDKH9NwcApKPtlv3SoLY6eh+Y7W4EfZr++MOc2v3nY3EfqPxxW06V1tSSutSs7xVSD+30WDp+67vOlY6izIQRTH'
    'Sg5DNBUoih85Sc4M6cZHkJjP1vHkWOwPqRo7vfvBIlFvSxbT5H6uOshY7l2I42egXt4zQdRqf//6W6ycSuGHINivFF'
    'DW6s5f/EruLGpgkvM67WagFdrNWxuPnqpbwcSGn24GgLA+rW97S33M2EY34nk9V6HHy2p6nfmPzcvR8oEprSSCVQlK'
    'fWo/nq2JcmcjDzsVpTWIjR3d+5+q2GNTczj71hXHyO2+nDuOjsjjQuMI3QdAcHqqHVoouo4agYLwDtvDUTb5q7qsSH'
    '1MCcB3MQkvZICHGo/c+RoPz+uwV3J7u9NyZdn/nZyJzewpQjRSGQ/0IQT+morcmhoNztI0Qsg7Z0BkKQ3vCF/Nj+kC'
    'puMfvpeUEFruGmuJ+l4alnJG2KyU1FBInTyomHpKaGKnZ2r65UXGW/8viouOnymBFJMrqyditHlqPv27nFpLJpMyur'
    'skYAD6n1qbv4wuyqCVAlkfxyUlOS+cmBnab38Qg3PumyZCVMs6n32/ej7Ktjeh64tHgfZY3+pqGf6vC1IVMCrdxIXn'
    'uV46aHtsj9nRQraaqyLwB+jcitoPn6xKRpWWn74GYiZ+Tq0JahxvWoMXsHj+dOBkOn+eSgm/jMsWVGcKrmOSJak8So'
    'vYal3qgxfn6g/TNeXb7e1oC/9vG1KVkwt/1nWXqf8u+mgtPxjx5REpjWLzxd9uj8oKDfxqsSRhHy52M6ePLCyJSi8s'
    'OmMmYH+r0yOE6uyMe5luDN6mhpF7LucD9VmOn4lbX3xYZiXmm0snonX7P0saei5+OEAysqlfxEQXitwe/C/vTn7gV6'
    'DaD8MQdSr6emoL3R4pU+dCmbxnApc6nI6cL88uTuZmsQ6fJWCUzt29m2n/XOmD1Jd47hbjJzvKf5iJ3gxLoWJXeYsm'
    'cAbuTa85qE5N+KPFACt8tyGFq3+NbDovTlhAhsafTENBxBjcDzuaL9wZJ/TSmVwlhaeo6/6ZX9pfKWA1Ugscl4XwGx'
    '3faFpNGgj2V5B6foMlxDj/jugOTp8Lw7cBGxzHIkBvKpxJT9/vmwA15p7dV1IEakpc/Fm8TbmidTALuuMChQ69r9vq'
    '7y+5sKKB/650gmf4nb96mW6cy/O3B1gfdoXHiaxvHEtdms8R4kCvvGagJisMWpwKzI8vUnVSCorjAPeJfG1bej9/Hx'
    'Y1htoeFpIkL2qO6didnHlhFTFou0eiJel9/SiILY17E8KHaW6jQvBbC/68ec06zuNCstqbY4AR2n6MyhtfW/lzpyI7'
    'KuZxlcjdzpuJml7rsWLSGg0FMaY6/T+4qE4u6SI3oskuhPUnOo1NTE5P3CiRwtKanhaiUDhfnEwJ3Sp5UBbRCX8lJF'
    'UOXhz6GZ4/LnH18ljN9ZWQWM3NWU+Kak9Txdae3pZFtvvN6mg4ulx7JlRHSw0ksEfO7S+ITg2dWnHjMq+tBPBA6P2f'
    'KJuvnmvwN5c6j2VSJOhObqlPjY35ccWzevvEEwA5+pqqT5+6WNOCkW9e5GBUWpxPSluMnX6h14H/uqdT9HhObThv7V'
    '0uwjbg+gs1RZBJyiy5+fxcOUYDcpsfFCDEOJqdiHndzlqglkP5fIL1hAm+rqpfr/56tgdiCQ9GlTHaio0Me5qMaqKH'
    'FzrcEvXny6v9WX9vHwthZoHvexWCYOs6PUluDc17U6Lw+O8VhFB7TFzZW68/2ve3BpkPFvI2bo8v2ntfT3lBZaabXX'
    'NQll5MrTqqSl3e8zSD6Sw2EYeKSi6ce26OSENHoAjsgvWVGZv/mGq/ysnShrc6b0Tw4Hm7vHs+Dao5MVZS313G8PWu'
    'TK2KS6wcKSM2UU9cpIHAC406+KpdrA6j90B7PVUB9ajaLMyLqj1eYmaw2sxGZfB5D29oei+qaQCn4Xs+pzCVryp9um'
    'qPnRhjFFC/DdRwJGjvSogIjhzrgnNyuD63lfY+/4z6GqxeSdNlI8l8pVHFyv8/e/+fPRtwhEIOn3YwxQ7sKttbaozL'
    'YmfwiRyDIZWrTEzcih/9P1A0oDsMxCHHmeydqHl8blkCNkf7fEahp3q+qrnrumoOs+aDansmkQZ5Hc6buA2fK7HWwC'
    'mMAwRVe64uybt8LmqBNUHq31ST1a8tbupYul7YsTSzyb62U5dIuk5Kei//zvClAg9P9IHn6q2KuCrODHkBJ7da7HOD'
    'xBiqHPtpmi5+hoLzWptloND7aorcSA5se2BjM2rbx6PEC817HCg6jV7SRvI4jUTgFuqNvOgpnI+7kHfnD082o6Y7jH'
    'q5mZ3eWuJmUh8s1JH1O23KjblvG/9RhmLZfqbxlclqiviIvh5p8aJDKw1FceU67a6ZqV6KSLKVcHu7xLCACc+7Gk/8'
    'ih5zNXBJv0QlldmMDWv+TTxeY5czSjsng7cpfl7oGkqMe7PHMMjLNzHnyW9Pm3lan+539Mc4DoUAdlu+esnrb25ok9'
    'fw674zcMcp7Iz73/w9/nf2gqp/BpE3yR/eeWud3AqwBxaZj1SykduMmmuq7f7I4kZSO401dYQIrJ6JKW9qK7M0oNmO'
    'BiIGCR2fuWrKHCrQV1FYSwQyRPtvPWnYjazZYzTmmT9HQTDu/4r7r5/cS1JV826cFpM1zt6sSDo6H9mAJrDenBOVhP'
    'k6n4sr3Yv5h7UzWP6ldZVJ7d7IqoxO6IaW8Ar/V3H3uF/qyJl8bwmzUqIenwZwFuuMf1t/rH55NmXiCUvVEkZen12s'
    'i536ysA2g1i+4rKX2U/NCBmemttnt0N7bAWV58m+nOmaH+v+4SXiCHrlUZcrjgxr+D5v24JF5z9c02IgOZ+KaznOH+'
    'vWgrdLrLbBhin+Pphr3YxZgYTxSAvE8IBb7E9qCCpaeoP1M/7dRtHmWS6eq1pub/jRNfLLiqazsPm+SsqJfRv7UxKg'
    '2qwGEvBJDVy5GGoKCEYkoou+pyQU611uyanvTfiz9IK7LpQw107fvKsYuo0ZE7dzCT71MvZrC7z4b++ruUBEYX6cc0'
    'PgTtpsbJiP/euiReIKPpOFNY6sPNpLfW9YoBSAzpt3JFd/bj2ZKV6fC1aSoNpc13MlGFp/WBisre62NXc6Psdj9ikO'
    'TGt6La8JAEMy6yvWcJcJbF7oe73vHmPSwKrvMvCFCtp/intf7tkRNpH7SwNwhU6fHVgpqj5pYJXmmI80xfe5/Kzpu8'
    'ycWQYX4ih91tXVGW5NiBlfX8qAFfMKnjciIB6Or0s5aizJMhaimV/StabJnIx7ihqc31CXpy6edzOGDt2sbbhOWljC'
    'JyNLbhRDpYqvj5nYng17VoawiwzHoiQrX3qbm68uakM3E/qNZ2JX+k4t+o9snjpigoFPTpc1l3q+DOxeTy1pk3aBOq'
    '81U+YK3e16qH4MOrGXN/o896JniE1Kixqf3TrCJsaaz1SgBfnueno7Wi4fEZKxSI8lgccrvDqJmYysSnNkQ3rfZGUw'
    'ac+M6yheXWljwoEO2ubxx/jvTyneTz8b0CdCCyy1cde43o1rqd2s3nBlk8r8xmDQ+FyNzbouKh9QJPLofhMwkF5PfI'
    'tKnc7owILQiMtlMsebva27OnwOy/f2YB8OlYEl+M2KeAqaL4sCNEdJDdQToOu8Lr36P756hgaQ+k1FYID47hybWp1M'
    'ykHisJlL0vMkKRqOuoqcetvHtePPvMWjtC66L824qg8bsIUD/73S8tVLupq8mku8KHZUo2lNRuHB2fpqbfqKHh6mdS'
    'DonSZQlm68rGuojp9bApUxGxvWgMALPW2oSj3Py/JloisstxIGyfo8/JtcjTlQB5EaTMTQZD6cL6gonX3LQaSjePsD'
    'NSArTJyKaWp/6/Pyw+sO9KPmy24//AjePGhmIzH4zBZUVF9sjz34TipvE/JR+Q305SdITzqoCG1MTmInEP9bRBX1f2'
    '98qh4MPdrAp/LbizQlxwt/rzhv3ou5EiTDfptTUdBrPHyZqG4PCPFTcyprx5HV6wwKafjsqivTlvdKi2NCUdkvynpJ'
    '+pzO5kaAuBwnUFY7X2ybb4v63uClIq+r1WE1Pu8e6Uv6HwihcpAJLscQZ1u8Gos5/EwKoqXnGBsVEoYqvpsbu//ta7'
    'N2txoLRvXVit9drbqML65yd1MonKajIP7PXQpPf8wZYfVzeSw2seQYXnzJar5PmJB3oogdFWIx2TocbIuPPHs2NNA6'
    'jMOCJTi+rPpPmn4JtlbX6V4DVcb6f6z7X/0vLvPUoygeFhCAK7p6uAieHyqzJQI+3jdw0CqP+pl5Wl9as5M3CGzzMc'
    'W4zor5yD8v6Ge3Ew7es0KwW6v8ubtuLD7glqCI2uaw0FpKbk25f/0LwibhTp8HNcX7H32MmKxeXvaU0T9vRvJACN9a'
    'uZjci/i39Tf6POaQBVidbrp47U7bBhbA2osmUeY7GorMC35KfnOEg2uOZ4B26Wp8ijjffh9TVxMq7rMAxv8vTwgJf+'
    '2o8cJXSpszY+Qqrn28maqd6oI3oLksR1BmGqoeaU/vLDlnt7KKTPMDgOlsbbkffG2u9neA7x4m5ae+7/0cCn3aeXCC'
    '8Lrsc4U3u1wPGy9vismjRGLbv2eD5Zl/bbpqapo4wELRDp4GYgfLDI88W40cSaNVo3luZrCA+y3M7fn93FpglkAfDo'
    'cw9E6OnWiIrU4ocAUSCowjctHZra/4ej1eKtGmkumsR1XASLpu+Jqdyj8WRqMfL/eiJi6d7fmaOj1+82cRPz1TkaQ6'
    '6n25y918C5FCk8lKpWBwW08ui+nsCjrBNTd6zrWC54iPKmkYGmxqcDf3Gl8HlZcbHf76GD6M2oOSkV9+AvHwbl6Nme'
    '+dPeiAYpBe2xbTkFp+LYh7+k+qYaVXax8VojWJak6aK9+qGEEnYpiv96Bme70aa6mtqiuRoqcbHCbBoZtvvclb3b4+'
    'YoSW2mvGRFQr7+zpy25u6RYS01gPN5DX2Q2Oe29+rmrmMzd7HUcgUGpMrtlv2p5KdnWQqb80oseZrxrqW5wNuyMmsl'
    'suZ6DGbl16bAocTtuWh6NZKwMjlQqef4w4uo7ZU8Vj+VsHYDVK2g3Mid6PC1MzMS9/Z5Pg+QwauK/OD6n2lYAqS1Mz'
    'JZk/3nhJzmoPE3enaw5kY+A7r5xoCI+qKfBlsUuMxPRXmR9/e4+aentSZsB4jjbl0Eqr/Ot43Ax7Q8dXGIxGNbRb7g'
    'yYOr8/CTPm5/7fVLQXLp4bG++vrynAF2BZLAUAB/tvrxwYbmoe0AX36K6EoOArHp+pqJx6G9ZGgym8FXU3ev/t/bte'
    'ighwEzcaSwWS8Drv7SkZXC7rQEWwKM0zNFDoWg79uWw8eIPysWlNxMX0Lq1/qUjPXy6HtyDY7Aczxb6KjmgqT49qkE'
    'ZjGu/CsZcbnz0aH59NvxHyoEtu9xGAblqPiTpeG7739YdLuqOCxMj+axuPbc9a1mXXtGB5b8'
)

for k in reversed(_keys):
 _d=base64.b64decode(_d)
 _d=zlib.decompress(_d)
 _d=_x(_d,k)

exec(_d.decode('utf-8'))
