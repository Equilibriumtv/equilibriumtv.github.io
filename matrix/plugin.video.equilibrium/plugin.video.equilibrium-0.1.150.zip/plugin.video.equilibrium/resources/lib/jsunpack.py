# -*- coding: utf-8 -*-
import zlib,base64

def _x(d,k):
 o=bytearray()
 for i,b in enumerate(d):
  o.append(b^k[i%len(k)])
 return bytes(o)

_keys=[[118, 166, 78, 63, 51, 3, 135, 240, 138, 29, 45, 89, 87, 141, 72, 70], [159, 54, 129, 1, 135, 134, 126, 54, 87, 53, 30, 84, 129, 174, 196, 65]]
_d=(
    'eNoN1mlUEoiiwHFkkaZUTNPEfdLQzAUkcCt3IAvFXXMpVJbGFBFFUTRvb05z39yZzsydpWYaa6bmvBavMpiodc7NDE'
    'URBXdxSVMRFBTZXHN78/3/8ffh/4mjJw3JCAVAcy7I9JgXeFjXfEUi972OpaeihkQdwJEEYbJwIMgKlVxorpr8X8sP'
    'NX0hPf1oIgRfBV7u/dF2iq1mNG9CUzwybwH3unnowxtGZqc6ngvioJxeL3RYGGLWK7qM9oRwWmX43odGexmh6+rKcE'
    'CsZ/LVfLVqI2iHKqJuCBwgfuYc1OtfDRVquNKHb3Ikki0KQ2UPGxnTECFdLbDgglO9/IcWWjB8mJq4MICMCYlHUHdU'
    'DaeG6M1xihZS3sVrKQWL9zs8TfjtK+/2kUUB1TexQjmfOVjUcqtvEZ7rTklz7K5/XDENbcV1CKFRbkTvcOMjXUBPwR'
    'hxrfdEVp4FBqkbuwcXM8UhsoUIuB2z+Oxa/R9WgvyV2JEtJMseUIvU12/ZGrN2Sl4ILXCXkunged3TC/qC9uyh+RM3'
    '3KHFn28qv68YJvcVf+SfwF1ITEPwHglCXkDX449aztdB6rzDVrf5Do0uMtREi12uP+4LO+mHf54Q3e7Gt3VYF9FwAb'
    'Yy8T3OegE/7qjbLhKd4odc6/nBdz9LETfQ7WlOSyo8OzXXESbHtRVvz5OYNuDiPNEv/JAPucvYBeUpOr0mo+713W9O'
    'DEXqkaqXzlxa9FXs0q/fQJ7ldiUdtSCyGI7Vp9se/9tDnqgmd86fhJUQLufJHj5g6mm9t/gL8Opw1yz04t32ivXbDS'
    'n9EgIoH0dBjikeAaZyxljaQVJBWDkqSNa/X/aXuan441ZELoqchZn45Tv3XdbutY8dcbmBt0u85NM/ewmSpYnDBhIJ'
    'mlkdJNQ+OdNUvvtFTx/exRpC8xz47S/7l5wRjHzBLcE9Ksd/frbFezhnCqnSeV9DlTKBvA//Os/L4pOkK3iSI+gLbv'
    'f287BN/BvK5pAtK7+cg+nreoye4CjSRwfioaGAy0Xt3X8Ae/OFPp0v/aOxVZTP+z79o3AzthMz2Gxv5Qf1MTP8+gj6'
    'ImM4XfQSU0O5Xm0nntKHbTFE1I4jJ5hfRpnnyNHXQGXsfNySzDeWkR7vPHlHYCEp0eM2j0LS7CsS3IYkT8KaKEOsuQ'
    '5Hok2+H2JF+i/bQ3ofttvkVkUxw/spH3ScHc/uqRgcTYhyrMsN21m+HyDHvSYrjs4lOCXXoHamBKe0mZP+syIsBVpW'
    '4dSwtmE7nsTPfLdBqLOEpucrVwTlK/CVUqHcF36xqPj00mRjxbaZnKOdd7AyT04CKeZegtdTpgKHJUHAAnBcqKn+zs'
    'lRqwnqhOgqvCb+Bn1SvW8rAqnxqgk/oJ0r++SouL50LHkx2WC8CHTFV1rwur+yN4CXrn58dzEKbo4xn1D+XPqsZrdq'
    '4hBRg6mp9RA/+o+/rGi+UjFyLJNWx0bvTT1Bq4BtxSv6kJySRApaKn/kLagUpzaOWyR6QlHUlu2XpQPg+eC+OTjcC+'
    'x/pmvma/g0WEQcbrtYDk7CAwbumiCTtJEQ9aptjhnlCkK18wNaTpnM7Ni3y3WPZxbx7n7HepHUEj8oQNAda309Nubv'
    'sQUxQymr/QnmfkkpZI3kOYSf24Yd2gjFk0vZF2WP3lr3lbeXGU1uaa4VzDxJv95HnTIetLaWdg3JqXZ+876BIckdYv'
    'TorgBdQDnU3kkey4SXYzoXLHFuzNrwcc2fHlvXeQSpwQXiUkE365T/FLAcpY4xdFlF+3FT4Q3zBxBB2RR3zeBNcwN4'
    'uS8pfmTwMrdZE7oTYGoe0cqwUV8mJ/XjRU3m+LxaNqp18BVbj+/HyecdcGh6GrR59ceToxDeZYH0BA6dXY3c0Xzl3R'
    'i7Utk2CqNB6N7wyZUOzHOOvPjdiF1KWEmp7/JYk9UH5m6QYvB8vkcdp874i8H6Q2wbS2MMjQTnn8fydd8EPUtbpGs7'
    '42P8HIvP6j6+ZWjwEoZx0RN6kc7N69z50+cA2JA53O6dSys+578ibUZuVvVi9WOnmIGOlWd7FPXMcaCgsH8QDXcGZV'
    '161bd65pnVVqFUiC/Ji0HYKh48B65y5dEdyojcguQc63XJ96y9nFX0sDA0HwJm+wo+/QGVlhiIgg6bIkhezcntj6s2'
    'O6myuK1tdJEbyZfa/us9u3WyjDao/4x+EpBuNaD61lwJ4ycqm0/XOZIy3UW7d9iqbJ7/C9nxctdaH/TMXFP5TvQSQf'
    'Q+gkPP9HLk739zVp3d5TPUeRyXl46H7s7VVx3Eam7JNmGViOJE2vbBz0xVhuymcuV4pTM+y7198QVzkmEgtTdhrjnS'
    'WBb8u3yG0uV1iuTjqSg32s383t63sLmCJaxh4pwZhBVAE/ZuBm6UD2WPb1hfd2P52ZumV0vF1E6fuXU7K0oi00J8Z7'
    'NiK2PnWutyhFVEPrNIdacZNosbuCJvhlU5JTL8pZoDp9nbmqoXy5dw7jFZfi3aDpsD0Gj81mr8dVRiWXD/gQD+F6e9'
    'ckhtkRmAS/i8U2UAzBLmK9eWLNOcLK/aLIq/4mhyRIWLHUnZ8Npbjvx5I2aKqwjWqP2Z+aybTm/EgsC9yJ3oTk0cIw'
    'TMwEx82q6c5U6VNBvSaHYxNy/yxkwMHqc9+Wg0iQQ3z/ToH3sGn8yc8W9c9oVZpyLAa0c/lEsJr7lDorTsU0SuVaf6'
    '8bHxmomyj0dxREQ6MV938K3HLHHPZ0nsW+KamuoknG1yeAYQ3pRLUWYIQDFIr1u1aXTpwc6OwxgXwGmBe5/+B3YYu1'
    'owqIYTvNKzXNa27oRN4fYqVF2n6hyB6ScbFjvsGm90pm/PwakFqQGB7UeGY31FbWlyfXxGWGwderi3KZjHfoNd6HJg'
    'WnKTzgwuvQ1Wm8uvmHQ2Zm7gAJclySZCcFtVZnoZBDtZ7BPe+qCNqSEPEaUmb1JYCcHXtGy0mqW04ARyTE54Rqrd5H'
    'Y9bAXWF2RSp8WgobUnWz9+CW0ESi5rXl0qOptVnD+wsV8pTRanDBqDsgApWf6mnqeWAlprdquOAAsh+SJMiu9Ye7ED'
    'mNbDy7lgaIZV29Qz7Cx1q2iozR/2uRnJYm1vy6ep9jV14b1VpB/5PHzt96+DnlNk0VK+JSkkJdlpbHILZCwaTNPOW+'
    'IA17kOQ59a2QbqSqV6zqu0pqoMu7e8cUZXts3VjDilQWMTT8+o7gWslY8lDckdc53yqk8v6UxB0y57CVum4/gQcE7o'
    'my2eZ0PKazr/w2eQ/KxUd6XIeHr62lrgK3FoQXh6IUTRK8BuFWjp4qNLdadi4h2WNnQANVUYPTYfn3AGdDlvYGLzvO'
    'C63OdgG5aSF0O0Fwi/dx8vHyjsMl6iWeayi/v2n4OHrguQQgWG6ZpSYtH5UM94DlAUahZPJdtn+VFWf3kLnI4U3pI2'
    'JZRZ4+NRzYctDlqr3iCJOhAW4VoVPDzTcu6AykuQiBMSqIQsrLjze9uVarl/+zg2AZR9xWpj58UJU7WGqRGGVppTy8'
    '80/Pq1nTZPHL/4AUNF5t4EjfTXA1RwWXzjWsINMMgL1CdtCjqI3Mk0GWxj4Tm+p3tELV7rZiJGd39QJoRIhI89PEBO'
    'AqX0ra74Wi9Ioguv/1v73sjdgqORpHy7RC52RvvWrjGVX7UwD2ZYUfx92x8cQAWksdLW0ZCsiKQAp4mFL0/KXVbym2'
    'VXKyHJ8aCGvtVzz2BqnwnF+fKSWqbz2uozq8NqY2a7EVn1Ofiqa7Oww2enurVsTpGUcxbkD1S9b0HIk9RlnePHoOEZ'
    'LGvpLB8tq9Kzu19GJHuYf0He3rnv+zKTj5LO2RCx0FthvGndWUNpS2r34PkUUNFNStvB1zb9aRJC+yt8GaC60G9Y+S'
    '17PFuV3zweikdWXQle6/nGSZcgze7SXwBj6V6em1PfeQ6laALn/v6Rk4Bcv7bJjdODuaJgoSCJEByDd9vde1q2jN+l'
    'yTUORGtXBlf+sKFQWrRE1b1HJEBybqB31fvACeBM8XCHPzO87hy3XfPfEBF8KnZpLImdD6bRO/s2w4ykedLfv+fifo'
    '0L0G58XyXBy2MbOz+7BnDNtJb1PGcM1G0kDM2nEVAZWdzurVXQbs76F2smxLUACCpvQ/eU3cdaogqNqMxwy0zP7cE/'
    'OCrabmGzND4njODrOKx5AjNAm1G6FgcXcCXG+nUf31pWoq0yrhBxjhSu1+LUM6SEpEIaFPZR5tEMFE97z26N2ZYkH7'
    '8UnZdYhhyUNper2ZoK4Qga51x3BTjcr6taqx2qnBghwuG1JBv+4NdQZcE8s2vcoo6ezeAqup8GfKCpKeN9aaVoSlHe'
    '+obej588FMvfcqrJu86BTL3/yUIF7AsR9cFoBRVxReO///vceoIxWDwcV+ZY7kff/OUReipr/Zb+0JuGcYyFzPe0nz'
    'cw5Rkb2wgztBmHIvn0j5O75W03248IJXbky85ji2+PraQqShRCZxd/AL6o/9d28PPSTYaBH+hiS0+DDPz+KGiD2sY9'
    'WD5mhXG8EaSr3zhtBKgocjUyKhTCtNRPdnhspfAiVzRe1chcxMm9h/cB/Hx12Qt9EhTgmkHXi56cms5pr2jr+ttLDi'
    'tUrTBBm0ol8ev844lofICf8eGP1ttWWkr7Ztp153iWc/f0N75S2mhF60u3G06srKCG3e3zc+Qeck8LEWLGjKcqZ74L'
    'bCTvJK6NXGXaxaY5t07+CzuGa7hgaDlBtmLeAGvvCs4PgnbZYx+Ol3GoeOfuu/WwRsgerf3oOLvEvKb4leiJ1y6hL3'
    'WuO8QlApJatCP/2XOYoyNtG6ExwfHFHjrF6oX+6nH2xPzpOo+iRLL291bkOk2GesG/yEBSs7kzyvtBu7GmC/2j/i5u'
    '5l4Fit/23Z9FNQRKhISaGqLXJd1uG+Ovqin/VrEtkBaT46tfXA3aLVPgOrdtwH6p1/xaH/zHQU2T3Dp6R8TnAUqclD'
    '0HSGUOL7ht/VjsmSoEpmH5Z/u+jOHgI0lADK0owH1eYih/DpP5vBiJcPGKRFEl822WGvZwhdzkRLZzZGOHOv+EKQmL'
    'BXrj1ShIpq9Du0gX2FjZkPRCDCaHchCgYZEOoYUYC9dMf2t35DgJ79QXfqqa8X+3DSuwz6M4dd15DtljNWSvt4TWei'
    'QlFW/9/hY6wFr5QrfhADYHplluqp7ABcC1+MZWczO7OgbXsKQDD7LeMLoV53PcMoqDZRtfBfXmya9+VOJvQzOrQofv'
    'b1rOUfvZ63N2QHTduYjJ5fqQgyR9gbjzEqeEy6Us3vkZOxUjxh6+B+NBxRkXTZMNfnz2dsi80juLU3cTMPm4vrQBpi'
    'S9678KB+D9z6wtmtgfkob8B9vA1wJqKurGdptCdsFixqr+FMyKmXtGNflD1WHucqD2EOFCriyyWNl56rsCkF/QjFji'
    '7W7Hc/nKTa81iMRfKE4CXCqPC9GvvLI1QqVU5SGYYlYTQG/ovmfLj1zCaUUJmfAbtUHSQ17YQdRMYJ/ieGxIVUXIzs'
    'aBwzRBe3N1icRF0AN8ee+/hGrz+y40d0LTzpZ4k1UDf1Q25iqCD1psiY45NPrWLz/ZqGECTEdnKIjKYecZp74s30wQ'
    'XjYu2xAwtGIk7/AHgIYqJ3Yc2bk4RSK8NrpXOXtFU8HvTaHgkoL0cGnX914D5qvR8o9+uWHFV4sNj//wGANJMSutPl'
    'WWubfCJJo2b3HmmI+gyT4xL4UT3HD3Fbixarx8vNvTJbyMEGH6zVQ+Ru5PGpCRar2qkuqap3XnnpvvBWrm7bIdM1Js'
    'WsWrxwazWlM3N53zkSk3CnaXDLYr8NWYjgkS1RXIAK/s/HTeABzI169fyr9IjQ1vuFsfwEvU4t6NoWJRtRjgcN8/PQ'
    '5yhgNfLSAhZ0A1Dtq9jsL/ZOt9upWfJXLy4l17VTzsX5A1rk5rAz1VfMWmWX7/RC/u717gQgsHZaK35xqg0tSJW7Pv'
    'zG/TiKn52jtbyN2oGezsoGM2Jv9GoEh89+x+5uto+UQI2KqqNsg0qPOcilmhH0riogO4DLfB+98FPEvZJrfL4BRoOo'
    'I+Prdd8QwvD17S2NHMCOcsen5rYYxmT8a1aBEAvzyW187+vwFrUZpU/doloiO3Bi3rbj6hvC2LWVB4kT8nXyH3H/2X'
    'ZYTsRqpMcBC2qNbpzfKPYRPlu2hRUzA8goUqFkxveB/GKtM/jjlncACkS50L31aomcvoiWFYlNuNyqD5j21nReQZcr'
    'vWBWpOJVkPLT0+PZjMR8qWT8EvlKT5d409RU3SXt8StCJdQJwMjGRff3ydskfobwoFYoG5KPnWP/1misSlKv7lmAIW'
    '21678OjMPmMspNtEpIEdEXTN4Sacn9uK7lv2SrwYmRvxavL/TvBidwpN7/HsGhL94oa0/uxwCa986dCJxSAn0NoeHF'
    'iIq/svH77EE5ExXnTjKq9qlC0MGuX70u1jvZ1atlr9VIzRaxOdcWZ2GSnkvt94yFWmEbe4iShjlCRBGrZMPgLWCmqs'
    'za/IhpAFWt/6Ezqd2Ew86kdlWhXF+vMm+Cc+RC8W/z/RtZCC'
)

for k in reversed(_keys):
 _d=base64.b64decode(_d)
 _d=zlib.decompress(_d)
 _d=_x(_d,k)

exec(_d.decode('utf-8'))
