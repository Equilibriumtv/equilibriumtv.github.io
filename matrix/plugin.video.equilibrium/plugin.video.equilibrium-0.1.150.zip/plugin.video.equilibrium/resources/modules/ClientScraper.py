# -*- coding: utf-8 -*-
import zlib,base64

def _x(d,k):
 o=bytearray()
 for i,b in enumerate(d):
  o.append(b^k[i%len(k)])
 return bytes(o)

_keys=[[78, 73, 136, 133, 38, 97, 244, 35, 250, 82, 199, 202, 241, 225, 8, 143], [33, 11, 47, 109, 41, 213, 80, 191, 239, 54, 7, 12, 165, 109, 37, 122]]
_d=(
    'eNoN04lD0ocCAGAPTMWGJ3IjpSaZT9NAUUROuU8BBX7clyCCoqIgCuuYHXaY2eGWleva29rR2uta19ax7K5Ny9LOlV'
    'vqXKvWsd723vc/fKxKvSI0kPX0U5AVeA7YC+AaZ3b9emPfqEGnfgdqiwrognjLcfLT93WM8FAUnaRoVyNoR+Imd7bZ'
    'HBvmdBTChPYs46Gyc8eaxPbfchrIDkkdwbg87uU+wCfeOsec2Brw60JLMocHdDTdWFbbAhgPXiA/GHFhEMOwTsW7uZ'
    'W8dAZyZ8SzxQon9XQGWKQoh2lM/eB3HwulZZMLkgrldRgNe3HWT3swC0l/zncLAC2M2P4zePRooNr2Ko8OFjmMhPrd'
    'OT1rVSbbaUYzNp2kS2h+MG/F+7FKyri6SeS0w2KTluXcWNVIrLysZRYkkbAZlsPUc+ONBMGrHEi0xcGPke6dc+6Otl'
    'hzU5MkhGXpSaJ+8+oVxibj2Px0ijKEnqPalrXinsSaOVKqK03x0zWq+4Rza2rcHe8SW3OrAS06/MjYvVPnDv2BMwiB'
    'IFupHsBfPF4jr3hHTC+WB+BE6X7Hky8YwrrTZKvITq5jdxyufbrRJAs9KvEtTHOCqMFtFb+eSmSr/oj1zXd2dsAlj2'
    'LHDivZ/itzwkxFnQ5t3VC89ohFIJrRuAQpIpEG/XHhyMFEaU4PWKr0ARws7Vj6k0OqJt+ZTHcRrwOm4y5ZdH2lvIh4'
    'fnZNnognQgAH8JN3tU7KrzhWBKdOR2zejlrTzRFyfs7komXCalXtI+P5oypGy3WDZDaUIyp3f5t9qV/CcPdQfFBBmJ'
    'FR+yDq2icIOeU+iJZRzWWh9LuRP66yusJDFfXlaVxjAXcQOtTd4bScwSjT6yX0cs0G4us1ESHgEbyugIZjoelLnOvu'
    'RPvsY1Ap3JflgHUeKPnxpJcZemdojPMx25HiHZnP3q+qtkyCm/Isam4U/2Tcu42R8vY/GKzkJBNfjTlmfHzXz/RdJn'
    'DyGhv0mIxB6vn++lDHDZwgTtXUAfF+jXszDrE3/FbOf49H05IsD2LGbiP4LafBToq5ykZmfZ11dqm9ybFJ6UtIqauM'
    'oa0mP/vERHd8r08lif2hfNWuua+3V9YEJlSGXCs7CGvvjb34YYPBdTorJQUccpKFJ8N/7eEU+3ozdbnpfOx89M/pb5'
    'eE6wPfUxWFvKL0aP/gvL931BvcwyWMuYA+PV9/hPpbP6Bg/aIHxwc4lvzwJuybLp/eMBLPXGTjVGuFH0StumVv9E+n'
    'tf2LZ9fik/ZTri/RmVse4NPLm9RcpH5/2ehdltu4FqXDJXmRKsFExY8fIoj2e6o6kSXETOR8S5m5GWnSzaga3+MB7D'
    'TO34Uzm6V82u+EKn5LWK10rLfdOiRrq94wiyUTFKm0wony13d0JZorMbq56iAqO3lZ5vBWqcf3e5YwlSPmUgSDjksf'
    'NAntMwxRfD2VieZ+PveHW6CF9hGCNsXDVoMD28LnVrXQNZuidWg1DoUzHsDfOmhvVf9QUEtJCgSRqGPFTwaj6ipelV'
    'dDYDQRmPuIMnXXI+ZPK825SRr1HNt94ugRS5X9O7BhvnhREKrfQXm202aonEqQJjINygXaAeqKYx2V9jPZMD5bVItM'
    'Okzq+3eltWxan5pgVPEZsg8J18dtTGAkL/29pKxqsGhHdtfnVdzwC72FBA5y84G9OVdHEouUPyIkIqkR0Jr6iM/+Y5'
    'aa7uVL0K08Vwni/vyJZSAi/x+MAG/nRShcu0krRtnOwE/qJpScYSRi99hm7kbltb9kmHKbHAbFrH3xK/s1RfYBsqXA'
    '50QRDHsRlwc9TsWDWMl7UI05t+HL3OGdxpKWl1FOqqdINZt+4P8/ZD7/JOCKammiEVyrCc9G1W2SPoQD1yYGsv27U6'
    '59a5U4n2KNXDGJns/pKr39H6CCszVWTmrkieOxD6NXrYzNU71IbCwB17fHeD6mjmyCFHFmZvO45nBtHOdz5OqVkfTQ'
    'qnk+ARAQVTTsorweDUu0M/DWtGCWKx+9vPjsYpqpfSQ/LblSX481T1jGboZ47BezhMUiKzvHvNVyZVyGtw/MAy8Uqd'
    '15gXX2kVE6j78RWb1IZRGz7f0xE/0Qhe38HHqeNwsAWMfm3d5Ma24fyKHFizxOQLw+/HyrzUvsiTHlp2SxlFHHoUN7'
    '5ZX6PpIxVyp0ZyW9Ley610Qt/Sm7llhDFShlf+fcOlojsl4FxLhau4Bs6yoaH0UUtm+FuRKguBBCsoV84bOG4vCAlq'
    'EEGD6Keht2+miQT7sHM8LB/DBbumTR0zuhluAqlJbUHGLrTfdzrh5rd3P7ykSFCBN3Lrc/PP2JvYnzW56AGmjSIoS7'
    'guPH/fSKcYaguMHPyTNsin2zIyrcfm9OPYqXxUjjLyl9N1ZFFAzPhyZb1ar5yY+LukciFpbOJPDeU8poSns/5q8tYn'
    'z1Rj03GWxvU+h2JF8ZifGGZoAUpqcBxXCsply7G5A7J1DJVFoFmuI/AZ26owo5N+NTU70hIB79KGL0Mx81czgtOS4o'
    'AvKlW+ZOfiGvc67HOOJY7ppIYVfwxd5or3Ykq4WMEKpmJ+8ijJ5iMZ1jbC810CEqQPYbrx4LsnQ/RmCEMq+WHD4R89'
    'PhFjxrIoMdweNw2fC32c+ONJm4vShLEtjvyurcnHLzlFQQPKPW5qbyxHnND6CrP9UsVJ0HyVOEAB8261HFnRNa8/9/'
    '1KYlMelE/0Dt+DZ1m6NXixak6TJQiG/iRz7uxLvPZdTzZcwMuKS3dPhUlcMxrdOiOTRPgmag/NWq5pDkNwzmPUhVhC'
    'L8NfzGuIfgmIz2gq1+oFw6CJ78wC7UDIA4ZHU5Vu0/vGjopJTpfghuEbZ2YOY0TMz5ZbnKbv2TbMQEKJ5sWQ/ply10'
    'Bfkp2JfAEiv1gfvIlUuNlZkPQcnCoDBMtUzFT4558yRTeFapqMkYGVxXPnpCw9TemMchw810hW26sGeL1iJYhWTjGh'
    'vaZ0n3wdcclLqre3Mg6FY/kuzdgXjepbAbn2gtFIQhRJScRKwcpUuCQ2BXRDqvYx7iJOnu3sSF/skEJgwI0DFAr2PV'
    'XlZL5laGLEMp6oxs7ot/vAyQk54gFTihyKw1bXeu/EwhMlyNTsH7AjU6+0fYs/2RTtvPbIfSWsGlSL+M/O9Bk87+J8'
    'i0wF3eCbgPIK6OMYvJw5l2oq8WluBfh7i9G0TN+T3DW+yzW0pch1F/fSCp7rwR2Smo4iJAxq6MFaM2fOvLuPq8ZBIM'
    'Ivsy/twgC++e0TBTlQyaYdY3c5+fSXRSr+IMuFotMAu5tfDuMo2o4jskA59eVxeNHIANDYCshHfR4VwJDYQ3Hsx5fT'
    'OSbRlgeBNVHizC9Dhyxc0GF+dUHO9f9lA9LGo//M0JqYt8SmlipFYys9uXYbsPyallL9miiCYLM7vum6KRL/QLzRPI'
    'GmIQEMdXfui4uDo6j/UnmoexkQ2x9gPQvhF5UcOlxLbCNFxNQnAdfmLUpLduzMXwKgFgduWjRZd3YLiSZ9iWgqCDpp'
    'H9TZne3VJnvUDiwvzNHGjz9tqzJw2Fgp8UjQyEHkESnySs3WF3GYcTdPFCKidS/Sj68apYccWGyHS+yqCGYZ9QJ44q'
    'KyzD2bXc6qbOfN2T9BfdzS76RmJ9XKBMh1MdtHWPNdgDm/T8KKcVqUN/GXxzu4VVdrE0vRRO0sK9D0uHxhOLGVOq6q'
    'I0Y3tW7Z7sc4srqaFnmZBSsM6ZaOwqenLMqvT8oDWQ7RJ4dtRm4tjiiFDgmUabX6VDk+X3c/q6GUWMf7JpSaqG2vnC'
    'HaWv90VTKyYXdEIdpk5qeHvEcHcsnXUlKjUXptbkcR6knbvrl5Rez4Skp5BFgP3AnLsj0YzMSxhZSpOHjZB9BbqwQu'
    'nybMWBeezmQKxkG+zqpyFu+RklM0lc5SpteFy45jP9QsKZhKRML9cEwPemrRptbjM+0esgaQBAlb9N/+/7tYXl11BW'
    'pdwIo1r3ka/frvR5elF1pZYs6wJpP/i//WKn8RKpCecAQImCnTlvR7xt2vvssJJHAUjh46CuUUuL+1oibS5MZ5wd2p'
    'tyfQWz2PpjRhrfaVPDmU/gK281CCWX2fZ4ZWX97PpDpotLlfzSa1ojKlUcAXJMZ64+pCFofsoxYV2AeAF9+5y+k2Jj'
    '7SVMJyaNE1Bhjpa8HNEJGPejPGD3orpoyTT05bFGmWYchYmC+GvwxnWFa3dJ6LqhbGhhstmupPeah48afNorkemCFE'
    'd9BHt7xpOTLKrvAhUCh9Jt8819oMd3g7yKl3FWXnXYrwKmzF1bZI2dz2D18UxyZ0z7N0WXT9W2tE7mtya0adARsq7C'
    't3c5DaVTuJREcZEbS/82rm93bSP3OrWDicgSkCsfEs+eTNQLNhpSJTCHEOTtye45HkNovYGqzmhohuUhv6aOfBLdUv'
    'eUIufBdC4IZwv60kF2qOwUtDUXQRYZGvan9Ky0KmzXQQ6unc9C2jYsurxdaVFNz25Jd+pNOuB+7tttYl74gV4BkXlU'
    'BNnj0jcftfHZG3XeKLUmSBHuhj5dq+WV9SAgeHCHS1O7v2jojL5SM6CUCzgiDEy3vmzkU4vcchPVhG2ji/Po2+PXbv'
    'G4Oh5EejI5clecayDrRbe3njAwi8Xkhflxgj3Rr7pbjOLT6vT4xua62Kgp2PMRe6u2dxY7H8wL47FfFo6uRNhzJik1'
    'shRTG8GwpeT1KVuLZC2yFueRcZXmJYSzW6TV7glIfVpDqCbWOxX/ek2Ms2IqIz1BahWgrcdN3bcRNWW9FczSNEeGEr'
    'nE+nR5JK987TwDD0YDYYSby2+PxLr19xQKqLyTG4d9EO5ajKGbn4MtShGPqW++v+i37THinIsw99z6YDAqPE09v7Oz'
    'TdPDpiVXqlCRouUVXaMdC0MPoHSY2K3G2KZQPQM0btkNMj26yppBSd6VceVeSOZ8pfJQ+Q1tCkEXYWKlIs/TR2BHy5'
    'ocGO/jWVeWYBbm3INUC2qodCWz39RzJoTXfVfAzYSU04n6vSl9Rxgs7gTFUipvN5S5exe9O9VktWyaJU4Q0moS2Euo'
    'K5fW84gP4W08eIDORi/LubjHTHUMLEgTMxkZWPTA/LUfdbiVExojRN6pwoW+slw401mh/AdpYgRCFtWsPbC+bY0Vrh'
    'tZPpHChs6r6zeNHUIsbF9bIC3mlUfMD5yAzpyEWDM3xXoLXCERwbgfPDnok5JOlzgW0EzYBPcEYc0awKztxbtEzZ3i'
    'WM43c4eO0sLaX0ESkrTUwNbvdDwfjCym3yiFRqv9aFxocerIYLQydJrdIXNbVUrkfdz4B8GSuiG9YYFI6yizTFdMf1'
    'Fpr3uk5MIRizrwjfszZ24146vHyc5yRRV2bmB5zPi2NhP5EqVaFpCJKdivCC9WN+IJpwoYs9Ob9XGWKee6zZEltoGM'
    'VKGawkxIfmsfPyO0NJzPZOUb3S6U623R5fejKrXrM2U4Zbu/vPFt6q0jMXXhq7nVWEbIQGS+NU3+W0PVT5WhhVBWNV'
    'E6GDH0hafR8wfep1S01yaKB5G/dMfIVRfU6Hi3CBQFbKv984ynxHyJ2AmTVwLsjKUZv+yy1xBesjuUqQEQJHkffGyN'
    'v7HhZiZGAO6ExYonSJP3/ITSe8RGZUCnVGGWUy4cja0IDeS6YRyzqNzxM7F7aQSB9RLUyYfSGBTtbvTw8UZuzmmUXO'
    'IVV8eZ95OuLenM6/wekpYB6RARJVuso/8DqHCWTw=='
)

for k in reversed(_keys):
 _d=base64.b64decode(_d)
 _d=zlib.decompress(_d)
 _d=_x(_d,k)

exec(_d.decode('utf-8'))
