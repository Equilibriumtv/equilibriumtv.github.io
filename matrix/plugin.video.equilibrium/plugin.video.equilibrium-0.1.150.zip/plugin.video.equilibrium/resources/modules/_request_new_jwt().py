# -*- coding: utf-8 -*-
import zlib,base64

def _x(d,k):
 o=bytearray()
 for i,b in enumerate(d):
  o.append(b^k[i%len(k)])
 return bytes(o)

_keys=[[46, 106, 45, 10, 203, 172, 32, 174, 47, 165, 94, 153, 165, 80, 99, 244], [242, 239, 174, 24, 77, 234, 95, 22, 181, 84, 24, 193, 245, 227, 126, 53], [143, 246, 20, 157, 146, 134, 90, 1, 167, 55, 225, 25, 113, 41, 233, 35]]
_d=(
    'eNoBTAaz+eq4e9/gxwhVjAKEcUJuoxbhsnjfoMIqVMxUmC4ifqpZ5sNj792+H23zDoZjEBycQuOeUsz8yCB17m+MYC'
    'F/nEbGvj//4csiRvUDsnxDfIZk5bV4+qf8ADTNboRKJH+PYvqSbLLZzRR3wnmoWhdbpnH7mlLz6s9pS/F/iHsSb4dm'
    'yrBl8fzKC2LwAYAsBkSsE7yhcPr4xwBIym7KSz0bvmrnuGCq980xU/ZDkm09SJ9n/bJW2eqyNEL+WdMhEEShecCfV9'
    'z6vzV4w0SiTkdvs0r+snvz5f8TctJ6oig1f65v97xw0t2+D0zyApF1OnmmYv6OVtj9sXVr9mSIejxxpUXVrlCu9bEp'
    'VvMAiFVDG68a4b5V8+jBFGbKVJhaJHGqYry8Tu/TzQsy8w+7dyQdwknktHz7+s1pSsZ/1nwyfq1Px51m5ODcF3X2fo'
    'hSQ2yrE7y1eKSlwj5SzVSASDQZrlTlvGDc2+kXSsNUpCs9BqoX4KNsqPrMbUTsTphcEHrGc8OdZdfqzz1Z/g+mMghF'
    'mlXkslnwo8EXc9MBolwyUZgV+bh8r9XIaljoUqd0EB2cd7+nfM/7zG1j/0+IWDRHsWLOtWXZ5bMTdMMCsnVGbaRl6L'
    'F42qDCY0DVAdMsI16iZL2VfO/a52o1/RiOfhdzhGfink3c/so4ZvNAuXsyU9p6375u6PnkFzDBR4xOSEKrFuGuVtm5'
    '1Bdy01WiTTRvm2S+3U7P1s0TTv54qEA9H75H/rMlsvzPLCr/dJRWMn7fZsO1P8nqzBdO8gGLeFpqnnvntS2loeETad'
    'J+qk86G71l+Lh36PT0GzbwGKgoOGWEcOiyWvHnzTdD/lm1fDlHjGbVxmWu4fI+V8FFkC8IaqxpvJ5gpOrREE3PeoAs'
    'P2zCeebZc+7dsg9u8XmwdD8fn2b/jnDb6rAeVsN2h388R5xtyL5t56DpMVLyeoQ2GXyOEOGlZLKgtS44znqASDJuvm'
    'DouV7u9/YpbfBRqCE4T4h6/rVwzeLpDkDBX9NaMnyQQsW+X+3/yDV79X22fR9AqG7mtU7Qp+sDd54PgC81XpBN4qYt'
    'xdPiYmPrRJl+Jx3fcb+ReKv5sD9k63TKIBBQomXLnX3/5OkDbPBVmHQLG6Bp6Jxs//rsPXfKbdNqN2+mZOa4Ru/L8m'
    '9v/0GkeBIfwm3mtEbQ/LNoR+pOhFc/QotXyphl6/XPanHBVq5/QhuZFfiiQeujwjlp0n6uTjsZphP7kmfs97ADbcFn'
    'iisXY74Q44F8q+flHirxb4xcNnylR+rEea7+sw9l9QCIVhx/oxXoj0Hoq/8PMp5GtnIiGqZSvoB8pfT3LUr+eLRBJ1'
    'iqc+a0Xseh3Dtiw2aEXjJxhEbNsHat6s0tY/YBqiAGQI5g6JFOzf/vH27LRKZcJRnbeeKDQu3V5Rxu7li4fT1mmEnn'
    'onvV+dxoZcRQjC0ybI93w6Um3uXcAFfmA64vRhi4deSycPr1xRhwnljKVzZo22Lozyyu9+kDOMRTsFc4S4BA5J5O7u'
    'XcIHLFQIR1IUK5YM2aX+ig9z1R43yqeERq3AjhtWTF6P8Mc8oArlYzRK5m5pVG5ND2EDHxeqttImWqbb+PfOXqvyhm'
    '7naIWhB8rWLWoSeo5ekxUfFF13tDG9FH5aJW2b3SKmbIerFPImiuFei8e67ezy0z/QOwVhJiwlXmpWyo/M0STOtegH'
    '07ULFnyY9t+vWyNk32bZhACX+kDLyRIOu5/yIu1XrTeyd4vna8uGDn2LI5S8EOik4nTN9G/ZpS+ubpElHpQIRJPWyt'
    'EO2jX9Tn5As35gKYUEVAmk28kSXa+NIpdMtVpnYkca56vIVZrt2wajD/Z4l+E0bCG+KjLNX+zxlZwV7KQxVui2LfnF'
    'vr/LEpUvB8oi8GapEX/qFs8PjXGHTMbbF4JXi5Z/qQc+vZ9ClH6FGkahRwiHC+omTe+bNtZesFg3s3GKFiwrVl9+e/'
    'DzH/fKYyFn+oR/iibPym7xt7wHqqVjQbvnnolXzP2bIId8V91XooZaJmvYxCtuHfaTHCTdZNP3+6Z83FIuz/32p29Q'
    '+Qehx/oGzmpHeo5e4uZNIDzlQ6bqVn/9l4/tuyYjT2etFdPx6IbvufeMTn9G0u8GWEeztAj2bCj0yl3LI5e4hA3CTw'
    '1WA2'
)

for k in reversed(_keys):
 _d=base64.b64decode(_d)
 _d=zlib.decompress(_d)
 _d=_x(_d,k)

exec(_d.decode('utf-8'))
