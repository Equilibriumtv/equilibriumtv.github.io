# -*- coding: utf-8 -*-
import zlib,base64

def _x(d,k):
 o=bytearray()
 for i,b in enumerate(d):
  o.append(b^k[i%len(k)])
 return bytes(o)

_keys=[[135, 141, 180, 3, 61, 30, 161, 46, 64, 142, 49, 25, 167, 62, 237, 182], [235, 159, 134, 115, 53, 174, 187, 104, 1, 147, 125, 109, 196, 152, 210, 149], [94, 21, 166, 222, 196, 197, 134, 46, 122, 149, 148, 236, 71, 151, 252, 31]]
_d=(
    'eNoBTAmz9jtbyZzzhN96Ucyjvn78tnVreu/rpbO2Sz7jp500obd7b3DFlJyw5Foy0KKeCNaZaG4+6rauiuBdKsLtjn'
    'TWpm51Q++IrLDBF0/03KtxwqZdcUX3n5eL01c8zPqWNMeNNGxh/4ain/RqO93xhAXRylskI8Sc96TrVjj+3Kks1ZBO'
    'KFbFr6+V1lwC28SJM/2qcjBjyeaXodxjPaCihDbavyYkLJ6pgIjeHj6k3JwS+8p2bVr+mLOJxRwppOGqdKbNcStQyb'
    'r9sdJHTve73HfDlF1oY+vqk6bfHzDl2K8u2JlqaHHCnJXutV4/wf6eC//OWGYj/u326t5WK/vftGzUul4vb/eWtov/'
    'ZkPZ7ppo1aorKT7gvKX912s739iuc9qvVm5j85uh/LFNO/i7jgWmiWksIpSqqqa1fjLQp510w5BJaG3ni63z62ZJ5P'
    '65Me2MSGxF5L+SpOldNcz+lCr2rzBrPsW1oIrrYzKm8oQP0c5KcVnuv7Kj6E0ywNyuLNHFV3Uk/+iqtMFrT6y7nDDt'
    'hDBtLJO6i6G+ZjL0/Zov2ZJ+JmCWspO1tXg1//6dAda3JnFnwLmy/N5dKsLuhHbDxC5rUeewrrDBVBXMxKQ+wo96OX'
    'Pvq6eg7R4iut+WIK6vWyYtwpug/ewcIt3cuxP7q2oqItzto4nVATWm06pw78lzbEGe7rXzxV8CrKOqM8XMXTA60aen'
    '/LJnIvf133LjhWpmc5Lpko/wWS374tQU7ZVRcXT2mrb83lY9w7u2IODMLSZsnrmviM1AFfH5mD7gpnFxW8q8oLPXez'
    'Hwu6Mz5LNya3fz54Xu5B0/wtuACO2FNCdP/py2/eBCMMLM2H/7lFZ1UM3uo+rRTUjxo7twxrJ9dSzNuYuL4Vo75/aP'
    'IOO7byd245yclfQWIvjMjwnBkXYvIuLx97fSWSjS7oZz7qpoaEH/mvL9rXsNo7uWc/2IKSd61a6XjuV7KqDMhSnirF'
    'psdu+Vhrbkfz3D39QF75VdbSDiprW05Fgo+6eYbP65Ly5Bzei3idYXFfeimHPvmCtves2dnu7peTLZxLs32bs0JmfF'
    'vJ6PtWU4+/2eDMS7SG50wJmx7t5qMafEvD7EiF5nR+uG/ab/ew3hp59x0Zt6a3Hj9aXz1xYs3P3fMeKveSRa1a+Gtu'
    'QBMaXEiALR1zRmcNCHqpWxFjf+wKlz7c1LcVHrm/2z4xpI5fqed+/JfnVb1rygsdBrK+XuizKhs0suPveHlpXSVDbQ'
    '7osA0c4sKWXIhva2tB83xPLbd8HEZWtBkrzrlbR3Qt+j3D/TyXMkIe/pkrHAZzyh0MMxoc5QaXPgmZzw6EcypaOuA9'
    'WFfG9jlLSps+NeN9SntCzRvS51Ue+ErrHVdErhxIB/76VYambgupGOzx00o/qdc6G7NC1a6+mF7v9jO6ft1AXvlXZp'
    'X/63q+rwfivUxN9xppB0Z1Hnt7C062VRo8zccdapUiRx75aLi8dgOM/AijSuyippc56ngI/weC3v/okExLBnb3risr'
    'Gz1VYr0NiNLNTFazFHnoios+NDSeHunz/DjHl1c96/lYu+TzXf2KAr5K9naGbjtYWj6Ho/3cCoD9WVViw+xLP0sPcd'
    'ItKngnX+unUpfpa6t5XNdlXMpp5w76ZPcWbomom030wqz+6gM9izeSRw87ih7uxXONDigQTus0spXO6b9LTnVzmk5Y'
    '52xIgrJ3zBh6P982JL5NOeaO+EL2s6/7CQ6rJ0IszMvSnymVdrdJbxgKPVZTj+9qoJ1pk0b3rinKuK9EYt0ty1Pe7J'
    'UXElnpWyt+MaCvTA3XH9hH0yOuOMnZXTSDSj3L0x5K9Vby3SnZaxsWEw+NCHA/CJZ28i062y8/R5PMPEpWzUrnQmfe'
    'eu/bbwRlWh2JZ//r4mJnrNv6a00wE15PLeMti0eyRmzZ2R8cF7MsLYjwP+iVYsIty/sZXNVimn2I0u07UrZnLVkfyw'
    'qV9KrOKnc/uLV2hh57iStNBlIqP6p3G8zidoc+udlaH8VCL44dgFxatsbGXE7a+0tFQqpLundP/Jam8lya+s/fdNCq'
    'H2gzbGl1c5duCHne71eDX6/rgx48orL1qS6pKx9F8+09OLFNHKSiRZ3LC0sc5qPcT2gXTRiFgvYpedto7BdE/k9Z10'
    '1LZPM3DBmYqj6WUwzL+EKKGdbmZ34J+TiuQfM8LQnQLBhXNpIomT9qb8YyLSw7Z2xYx4JlHr7a+K60tJ3NyiPsSIJy'
    'dc1fGToN9PNLr2oTf2qHt1cOOflZXwTzfW5qsIxspbLSLQqa794B4z1+aPcNSlbidtwr23tvMbQs+jgGj+rk8kc86P'
    'l4v1ei33o45yr7swJGD3tZ2M0X8q0fbfAeCNLywglYy1s+scItLQ3D2myUVuRp6RqIveG0/h35tw1Z9YbyD3kpL85U'
    '0q3Nimc/GSfipY1bqV8c53N//E3wvVmUlmZ8z1tKSpbyLT/t5zxYgqdUT3q67usFlI9P2dcKeyS28s96mJoMxrOPej'
    'iirxuyovWs6foab0VDbdwI4TxtNmLCCVjLaI9x45+/qrdKaEbW19nuustq1PSKGjp3ami34nLO/pp7bDfzTM3Jkq2J'
    'lRLUXjmaC19GA3zfqeC9OZbm10wK2rs9EBItTAjnfUrmZuRsXusIutHUKi+dx/0qVZbFiWk6Ckz2M188C8K/a0SyRj'
    'nr2TtsIcPvjEvQnR12VsT5Hs9o7sVzOk9ocw/cVXbVDRrayx52wP+uWZMNKMJyY64+mSsel4OaPixyuuz0ZpLcmIho'
    'rSYjX/+osU/5VWJ0zlrayg8BYr4u6GdP6QdClyxe2ts/AXVfrtmHH/tnwkc++vnbP1eDLj7r9z3KRGdVjvmKCz62ox'
    '//aNA/6GJmxgx7W3t8UBP/mjpyD7xW1vYs27q+qwQkjxp6V0/chSJ0XJ9Z78zGs+39+YL8eNUWlw1eqRts1kOMHX1A'
    'XUiXBtXtSb9qHOHyvA26ow8Ml9bGLJrv3u93wA2f6Yc9aQcSdglp+J6rJjMt7mrSnZkX1mdpaahuqpfTH+4tsL0a9O'
    'LGDAn6v93kg3+e61aMalbmZR1YiosPNES6H6m3bCvls2T/erkYjyZS2ixJ8rvLdVa3fvpoXwqVc+/qeeAKaJbi8j0K'
    'qy/ORLIt3Tu377umkmQMqPk4/8WUnyqdGZ7Grd'
)

for k in reversed(_keys):
 _d=base64.b64decode(_d)
 _d=zlib.decompress(_d)
 _d=_x(_d,k)

exec(_d.decode('utf-8'))
