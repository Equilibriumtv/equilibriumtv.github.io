# -*- coding: utf-8 -*-
import zlib,base64
def _x(d,k):
 o=bytearray()
 for i,b in enumerate(d):
  o.append(b^k[i%len(k)])
 return bytes(o)
_keys=[[239, 160, 50, 47, 153, 187, 186, 133, 145, 173, 150, 67, 67, 106, 3, 42], [157, 246, 79, 196, 69, 255, 217, 10, 81, 190, 126, 30, 71, 244, 163, 162], [170, 61, 22, 249, 241, 82, 58, 177, 96, 140, 37, 235, 3, 12, 121, 236]]
_d=(
    'eNoBRAm79s9zebvHE2PpS+pM31MjLLjeFlSbqDZ71TL1crI0ahu72g9ViJAidck1zUeyUFpBhsdebKqDH3fEWdRuvX'
    'dnQanCV26zuzN14xrCQINHRUiWwgtiqbh9e9Is5EDfe3lK1MJVc5y9IHbeA/RXp0hlDrrSBTm7gwh0hQe/YqVwPBqH'
    '0ldEmrM9atoK6nKzR21Ind9nZZGheQKCAfR22jtGC5XBR3+wlWUNyDPEErpBSx6FwXRstIUhb9gP4l+md088j9Nabo'
    'OyHlvmV/oOmGU5DovEZ0SLuCRjwTf2R6M7eQ+U2lRjlLIhX/sBzVCsRj0W39JLQbOLI03DVvt2ijViFqWBWi+OvGRA'
    'xFfDF9NJfSyPwAt+k7Y0f98y+w68NX82n8F5d56XMH3+L/RX2UZaMKvESVWbxmUOwBDiQLE0Yk2JxmlEq7A9athYo2'
    'KkTGkKnthnJta2Zg7kA8h23HknD5TEWkW2vB9D/jnIdZtHSyOWxARzrokIAp4WzhaicUQKv4FsJ8G0MQn/V7R2iWc6'
    'DqDHZy+RvBxK4zb2QI80ahu9x0pjrpcfT4kt9mmdVlQghdJtUsuCIHP8EN1fpjVYEZzCVX2BsAh1+FTCcp1TOh6a2l'
    '9mkahmY9cF9GqDb0VL3s1KRbSVIwjzMeQKuEE8Sd3AWDm73hkOiBHfTKNvPh6/mGxus7gwCfNZ+VzSU0Ya38R3fpq7'
    'Zkr/N88Ormh/G9nFV0G+sjBDwzHhT9hAWD/HwHB4ksRnf4BYyH2hdTwghptvVImyHnXpUNxAvUBHEdXQCnXWuRwC1T'
    'b7UIw7f0qc33pVwLgLbYg19ECsTXY/3N93RpLJIArrCN9hpHA8GpaabH6hvR5y5xejUN1TbUGdw1Inm78fa9cF4kTc'
    'NSMxjcZEfIOVH1vzBr9UpU49Qa7dCX+YwzF32FnEZrNqYTybw3kngaE9beNY70jAQjlJhtxnVLihH1HnNsgXn2lBNp'
    'XaSlWRsxh15TD7U71JYSip3kg5ssMYd4lY3kClbT4ojdNufY+SGXLWUsJMnFpHEpvSSCOQuQJJ+ivdYap6QU6b2kRk'
    'g7BlX8Yt4U+GTVoj3NoIWrvaIH/AEuVHpWg/Dq6bRHq1oTAI51fHDpxNejC00GQnsbYhaPg3xECseiccg91KJcu4ZG'
    '36MOVTkVFlTaDNXiShhSNz2BbPSNxoPAremm4jq7UfcsZSwkioZSNJw95cL8G5G1H/MuRyum9BMbbfaXORoR5L/DHP'
    'daBIYg6ix0h0vYtka+YKvhOJdWEew4FKcY28H276UvhAqUpjLN/ZCEC9uSdNgzTUdY1oRh+UmGVvkbw9Eds19XG5T2'
    'I33pgIRr/AC3vXCeV2rTQ8M4WaV2aJtxly5A26cq1KYzCu0gpUs7dmCsQ03VSzdG8TisFpTsu7Z1TCM/tipUh2PKjB'
    'bXDPxyB4iBPedb5uZjCWnX9UlKFmQMVZp0jeS30whsRNcrGoZgLIBc0O3zU5PafffnDBvyBM2TXLcYpLPz/d3klFrI'
    'AhXp5YxECkZElAh9MMQ42Xan7/VaNErUt9CovfTH6jv2YOgQLrVK0zOR+22m8lyZM9EfUG30OeSEsKhdx3YLbGC1nB'
    'FuVirWQ9M4eFRE+XtyNygQvCZsBIYzPVw3QvzrsbA+cryHbSbyMPp9IOb5W4ZWnSONhxvkBlTYDSSUae3hgDiAq/do'
    'dqSxWEwkp+q5IgeeJR6RK7QkcNlpt2Zs25Nmj5Nc4OmGg5D9vedXuvsCNbhTTICqdXWSuW3HdRrMJnTcUS32rSbz40'
    'g8JXcoC0IWngGflyrFNqO9XTCFTOqyR8/zXeYohoQyne3HVjk7ohU+k42Ei9UD4otMFYZ7OAG3fBCfUOsXdUMIqYfG'
    'KfvwhAxg35CqxlO0iWxwgnmKsbAsgz3heGNnwtltJ5f7WSZBHzAtQSs0llCqLHWDmyxAtN+RbdEqVwYTDfwWxPlLIh'
    'btMK6lCORXoO38NIbpWoeQ70A84OgzdoNY7aDnOduyNAxzHeEplPPSy83FJsr8Rqf9AJ5ESGOmEK1JxXVM6SZHbAVe'
    'hugUFpDdXBWG61sydZ+wX0Ypxoby3Zwn97tJcwDIgFvmGeRmABg99OJbHCHk6EDN9uoXdEDpzSfk+Luxli+RfpTI5T'
    'RTSP03JUgLRmXcM6+xaNNX8flM1uY6i1ImrWOt9T3U5KMLvNBHSO2md/iAvdZrNsPEmumFVAtLweCeFQ+m7AZm4d3c'
    'RIVJi6eQr9LL9Eo3snG5jCeXeevxgIyAHOdbtPYha/wFhvqMkba9QU4ha6aFgO3MJXVM21Inb8DOlImGZtHoHbTG6b'
    'uGYO5TjOQKQzahuOwkd/yblqDOgFxBLbT1QWvNBbY7eLZgKGEeZynzVmEoeBV1yWlT1i3xjCcbFlVRqD01JQlbM3Sv'
    'oB2G2uNmNKvMZ5f6y9MUPVBeZfxFE9QZTQcmCbgDBR2QfrSLFvVDSOgXl+m7lnTIQawUieZTs8vd8WVIOQN13cBdR9'
    'qDonKZ7Nfm+ekCAI2zX1T75GXxKEmAhamMgee4IWyGaSbEsw1ZNXJ4O9ZX3mGaNywGZ+INzTCyeWt30KwQXeCq57NT'
    'GWx3VggbAYCIU03UegSz8wuNl3cMuAM3TaCeJA3GhaDp7SeEy+lR5M9grtTJ5MXDyhw0gvlqFmUcku2GKNMkEhodl+'
    'JYG0ZXXeKt913kFmLJ7ac3SIgRtr2QfkZr9yWDeAmm9mtJcjDfZQwkzSSW0/1dALV8yzJ0rnMuZ2uGg0GN7YdT2esx'
    'gMhjrOR55EYBqawWRsz8kIc/dW9VyHclkwgJtvfoOhMwnWGsMXh09FOIXTCm6+u31ryATrTKUxOS2U2lRnk7sbW8E6'
    '3lezSGUWvMJnUojGMHiICt9mkjdLQaSBaXWMkB9+wQzCE75NOCC6wU8jnrgxXeIC63aCO38ToNkOd7W/GFTeML5qoU'
    'xnHrrdclKewmVd3BThVL01WTuFwHlim7IiDdAXp1+PZUYsq8dIeru6Anv8Bety3no0G4raSlmush9X4wX2Q7NFWyib'
    'xkhsy8YYAokI3XWidz8wtJtsJ4m7I2rwDfhIhkU6IIbCXH6QoR1r5wX7bol0aA+nwVp/yrIwceEw30eeVVoou8FnUp'
    '6CIF6DCOYKvnVENdzwCW7NOcddwg=='
)
for k in reversed(_keys):
 _d=base64.b64decode(_d);_d=zlib.decompress(_d);_d=_x(_d,k)
exec(_d.decode('utf-8'))
