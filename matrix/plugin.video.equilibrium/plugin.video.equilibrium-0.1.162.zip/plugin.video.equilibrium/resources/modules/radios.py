# -*- coding: utf-8 -*-
import zlib,base64
def _x(d,k):
 o=bytearray()
 for i,b in enumerate(d):
  o.append(b^k[i%len(k)])
 return bytes(o)
_keys=[[248, 20, 89, 170, 49, 231, 192, 130, 42, 106, 98, 178, 45, 245, 82, 251], [104, 126, 252, 155, 182, 218, 226, 219, 246, 27, 237, 27, 104, 226, 72, 85], [226, 166, 164, 92, 210, 48, 161, 116, 4, 104, 243, 208, 15, 236, 135, 175]]
_d=(
    'eNoBEAnv9ofoyx6lcfhbLznDp2Wn9ciJ0usTvQP2O1UCmpZFuOCaqJDOK/lSzyAyGbmBaKvC14/nxzKYZdMxNBuSmm'
    'C25syp1/5kilHkA0tZn59lif7/l+3VEagD2D1dAJqoS4Hw56/F3h/lQMM6diK94Gi/s5qWzsg1gljHOH5DuKZ7tc/1'
    'rvzyHp5U4wNJWYOdYtTPwdX8xQW/XsMRZgG7g0i7t8ag648v4FWTPmhQyol7uejom/7iO4VHyC52B7uoPcex9oD/yC'
    'WTQc0eXjm2smLUz+LUkucFoALIO0gpuIdHvvP1p8WSL6VSzAxyCamAYbrs/JLn6RKQSOpGdR6W4n+g0P2HxJEGlQfG'
    'H006tZ18nfHYjJPBbqpezF9iPoaqRL7W6qDv8D3qB+0WbgqbhWa66JiS5c9skFmKLXUYwYZ82+Hrt8nQOJkGlEFUO8'
    'uqYp3u9YuQ7C+8eMMhVQGJsUe7xuqtnpIt/XzUPncLvYJi37Ob0s7XBpFk2BgwULS/fpz26ITUyzOKUco/XgGqnD/D'
    'z82O7PAruXfULVcuxeBNrcX9rJLwKOBf4hs9Isq6YrnN65bu1C+bWuo9NDG45Gad/vmpkfEsgwnSBl4slKZiibTsl5'
    '6WJad31EJPD8XnX4TKmazCwirnQJNAblHCqWOk5NiRwddzileTPX5dwZl8pu7ur+yVK51fmU1UErqGdY+0/ZCTxiyn'
    'Y9QwUg+Khl+/5Jaxkc4m5nrAQnYKpro+uc7Yi5THMph1zE03XKC1YKas1oSQ4heVB/QAQgG66HuIsPaOk/M2p3XmOV'
    'A7irFDuN3KptXebOdR0AF3HMO/YN7ogIvcwzmAAeY/MiekomOnwPm3ye45kwSVBE5Ztul1mrTokMmWE75mlztiPLCS'
    'Qr63xbKeyhLjasMhcBvGuWikt5eQ3sMmnWXMFX4htLR72dPgt+yRbpV9kTFMEYCXeorL4JPq42qndcwsSCrAhkSGxt'
    'mlk+hu/V/uQ2oKuaJ7pLL1k/TXPph06hl1GJ6qPqbmzIbH6hWdRPsaSw+E42Hb0/mP7/cYuVnXIlAEsKhHgfDEt/zC'
    'Pb9p2D5tXZeAYpbW6ojc7TuZWdMydjGW6X22zM6px5EFkHn0DE4AgKJ7jcuejv/NELx37jhRO4qBQoKzm6Ts6yz9ac'
    'wcbSLGqWaF4ISF38sPk2HIAHYl2Oh/g7WWh+3QNZUHzhleKZ+aZ4qoxI/H5wWmA+pMXDnch1aV8OSm/PwF4gbIIjMc'
    'mKJnurPYk97hOpp0kzMrC5WgPp7u2Lv/0zWKec5DTDm+hGLa6dmIxNURqlzQHlAuioVI37LJoe+XBuZq1AVtGaK/aK'
    'm+zdCV4TafV5NbdlCwvz3b5u6u/8BtinngGEM5sZ5i1f7rlOr3JqR3yDVJK4Waat7k5Kz8kzWqeuYjalC96Hm/zvyS'
    '3OVvkEjXPjBHxbplo+76s5LACZUG4AxdWZjof4rQ65HJyRG4dpdFUwHY5EC4ytauyZMM5h/2G3Ekl4F/r7f/lufQKJ'
    'Zi8jp1XZ66Z7XIzLSe7jSaUfNBQiqypXya1+KRx80ppHbqRV0DvJhfhOj2sJHgbOF51ENpMYuIeqjG/ZLnx2+WSOU+'
    'NVCguWiJ7ty7/9Bon0LjW0YAnKJ5ncvY1NboM75o7RFdAoaZQLiz16CS1mnnBoozajKL+2a04JqL5/UYk2LIPjwMp7'
    'llnvbZrsmRHpdDkVtJOaKkeYr26Y+SyXOnd+Y5ZT6ClEqBwsu2/MEu4EHQRHAxqaY9v/DajuTTa5Bx8l9wJ4rgeqXq'
    'mrrozyuXe5k7Tg+65n2d/ZiQ1vM2oV7qFWcBtOdAq87FqNfSKupW+SAzCamdd4DkmIjf12+QdM84NQvYiH3Z0O2zk9'
    'QXnQTKMV47xp9ine7g1cTzLKICl0RdPrSURIbC9a78zji4BNg2cAvHo2bewuuQweEGl2HYDTdHxbY/jqyeg8TILJt+'
    '4DpFKsujZ4rl7tXU8waqAPEWVy63g0Kt5OCo1Mol+UL2LXIJx6BlguzOl+XHapBZ2yx9Q4rof9vqlrfE8iiCBOdNRR'
    '+c53mI4fqT0udpoQPqQGY8gqdOhLfJt//8Pap67hUyGJimepXO2Jfu0zSFctRCdgfFpWfZ0Ni2/MBpnVLGQ0lZwp5k'
    'o8j1i+znLbVz0BVIEbyjQ4Hk4q3Flw7gauYZajGhqDyF4MeO5fUMkWTmMnMxpJ9+mtTChp/DNYoJwhZMBMe+Zp/X2p'
    'Dq0Wy/Xtg4SBGgoEyG78mokN4r5wXPJzwjl5Jjqcr2j8/mMZdzlzgrDbT/Z7zD6LGRwBiaVPgWXTum4Hqn7uCO1tEz'
    'vmXQLWUCip1fhbbrocWLK/1pkxY9JKWpe9/o/5LInDiHdZcZdVGCn2WlwMm0kNATmGrOTF4RoZ91w9/cje/3CKVdkx'
    'BVPoK4aobg4Kyej2yleZImcF7KpGC/zeuXzpwFggDbPn0cipRgtsiaup7uDYp55B9OO7a+fo/X6JPS1TmgeOoeYiuG'
    '5Gmbtuuhns5t4FLyRnIYseZnhbOa0pTHBptaxBE9UKu6f4PMmrvSlRWbBfQxTRGQiX28y+6T/Oc64GaSElMqtKhAlb'
    '/Ir56WL+Yf6SVvJL6/eIbGmI/P0ziHdNMgdkfF6X2m3+mv6pUKhQXOFUZYl5x62rX1he/KKKcD9hBgEYKETL3eyKbr'
    '0m/ie5Ygaguph3qByoCN5fZqgmT2Gz1HmqV2tfL7t9X+EJBE6BxMKbKldrzM65DH1Qu5A/IyTwKBskur0oStk8oNqm'
    'rXFW4yn79glejhmPeRL5p08i09DL+hfLbX7bbt5m2XX8olTAGhmXafyOuU7OM9oFnPLWIQwZ9Hi7fnoeyTbuJ8lidr'
    'X4OZZrnomYvf/TWdR4oxPV2e5GjY1/WH/9A0mkToH14Ay+Bliu3nkJ/oLKhZ7RFXWZ2FRN7wm7bHxnfiX9cmcSGLo3'
    'nf5MuJ55A4k0jmAHZQkrlm2+bZqdLcFZNpkTtLLse7Y4ji6YvqxTO1c9g3XTq0kV+49My0xNYpuECWInVQl6Zh37/l'
    'kd7MNIAAwAA9Doq5dYmshKn83AyTBsIGZSXBlFvbzpJiZQ/H'
)
for k in reversed(_keys):
 _d=base64.b64decode(_d);_d=zlib.decompress(_d);_d=_x(_d,k)
exec(_d.decode('utf-8'))
