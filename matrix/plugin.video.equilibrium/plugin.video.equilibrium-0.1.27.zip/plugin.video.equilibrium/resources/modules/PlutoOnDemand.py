# -*- coding: utf-8 -*-
import zlib,base64

def _x(d,k):
 o=bytearray()
 for i,b in enumerate(d):
  o.append(b^k[i%len(k)])
 return bytes(o)

_keys=[[64, 6, 155, 106, 200, 124, 141, 244, 149, 166, 8, 191, 38, 15, 56, 28], [110, 29, 135, 41, 220, 89, 89, 179, 77, 61, 212, 100, 240, 18, 164, 2], [182, 152, 51, 205, 167, 32, 234, 238, 74, 118, 87, 160, 250, 29, 143, 100]]
_d=(
    'eNoVl4s7E4r/x9swB5ltUim3r0urpzHH6qtvkZw4xaSSDiqnx9hQz+O4xEanjnJnrg1zWW5dJPEcTmlynWg3G7vioI'
    '1ZLjOS65j9/P6Cz/O8n/fzer0/fNGd/MWQCWIs3Ga1DytHbkr3dfTGV038dMiER0PS/Hjbt8t4mEki1ggzk31n/Zhs'
    'AVQ8F5YzeVTbRfwhatBfKYjN4OFrqSedDReTvVXnd5duZc0a59QbXEAtsMI1utOtHk1sWJnY9fSpjeKkTpSyGrgl8a'
    'l8bqAVzv0nagewPPeoaRjb0gnZjytkItmgTe6+eolPzdgRF9zWoD1TX9YcTym43J1OOO8oH77XZ6+hPXqlefCKBHQx'
    '4T+P6NVb4elq6KGZjTpmuE12jDpgd+zmliKwpnqfNpyUghTp8MWY+kIMpTHWGcUpxa7bCMUB5ZKE5A9HQaGCtofdMG'
    'UT9g0rgpiqa2GzSbQfcRRq3N8rfVtSjiCiikheGqC69dIL9gNe7kOnKFrePVWwWKzfPANLrTbXPSOtsOOAZCr0EwaE'
    '/MrS+tzqIPYLTLWML1b65HdqaSO53PCBG/y2yMbnt3JfujrrFGUniR2EvEflG9BXVabaRwobIkQ3ZYIkCiuhYPKwkb'
    'mIgVWh1GNm20oc9StAR2fzqf3E+R0Vtp0ZklvjBLCdp9wZsVK3JqrmfCbGjS+eEzREjpkoeIHkr6FNopMA6DILTQf+'
    'aIhOU6BHUi0vnCMLb88GDwkDqwrC0tJtLAHiot/pAIU4smsmvL/C3MV89O8oJogvxr3kGdcmWzjD+xjxnU7if73eTP'
    'vkfNDSRQ1wH8j0JNUxL7ixzeRET9uZ4ntiKyU98uMMoT37uKkjvdVvbL9QHEIZ9mn5cPQ0tLAvZl3v+wq+Q4LrTDXQ'
    'cZM9jZ7cp6AnprCDcjtD4Mj1ojC6mboN26GI62qAaFn1tvhxDPnDSW10SNMLU2edUTayD6YZ+itzFkL918Id/IWLbN'
    'MXVwOzhmFpFX9a4OTcy6qAb20e7Rr8aDpS2+VL95XZ/6z1YionsckVJ60xpVnodeQaS1u1kTCeBXYJZQhvjv0mbrrd'
    'zA54UpPoAFRQwnrsFG0hGRqf9oYT/wNutF7p91tRGTwX4SvHkfttivPs1x3Wpvwyl+JTe7XdzGV9N2lI4QI2h4FvrE'
    'o8D98gxizaf1ODXmmg/RVGiHAl2V/hKlXFvmbFN1WbwQEkzq3xk2vsXzOV0KoxXYROTrKDxGBq4VIq33uy1PqwGycb'
    'oTzwbTuRqMCTPwEvnhkie+zo8wUJn9gwYrOFEZjFRM4cEDC8MiTYZ+Mwl1OcEocJkKo6sZKDeSt2hboJS70+w3caL7'
    '2X4StrftK24Jfd3wFPvbv2hI7v7D4Bhs/l3F2DrY3dSl/EJacYnP2DzkZ2w2YWL5KYgTwiwdlwtDRm3p6/ELs7Fz7e'
    'f/xCuPDvE2OwmV2DbIExudMUoPOsL7oHJVz/q07im5Ji5OtYTHOgmYh3QlYZgc3PY8+fK8lLmkOIZxOo329lZiEgR5'
    'gdj2k20i3MDp3Q//SwnamQGbPuLGd55fThakb2H8AxaN4SK+nC3U+8gMmJv8DIocGr9J949PiUxQRyuYX7mf7O+7KT'
    'Q/O4p8M+lQ3GzmA2LYF6fVvze96sT0632SGT0mSkBCgUBMjF3s0UgjM0pzBM+ZtQ7fGPFJaacdwNNEq9MRCw0qyVx/'
    'dJ6TpsDijMQ65bfNe4/yP3qajbj4DzBh0459X0yBROHIUU52w6n4/vuf5NGKueDh0ps3Q/+J3qRzNamffI/4pOph63'
    'suXRrr44uLX0a2ZfTEG6tolJWYn3pr6kVb+9IC43Nc7WhpbpO2evXDDYXg5v6bJws5L9bafwk21pNQzhyckQKxd2zs'
    '2tgytM7awNwstUgws6xSVxO1d5qkeNPK+3Ew+dDedKH8jPS0WPsqaNWzqArsCysvufjslUHrVDhKYGXSPoWnK0+uDG'
    'UnD7HKSKCj4AKBEmfLIbqr5I4ceO9RJsbeScMLmfZDc+R46vfGJxKPRLd2L3edlWbPZX33aygzWqiBWnuqaZCiNJEm'
    'rLwb+YkNmXu22E1Zdqhr2zav/0DP1BDFMGyFrvNiz6ZlKAwY4y8vFvN4U09HMmrEV01NlkLdehJ3hjyatGCU1O3qeN'
    'WuWETR+bXgS9Z4ZlZT50QK5ywztv8nnA/A08+YPp2dCxrsdMP4ngXtZXQkGtgzlUTIxWQX5IQjNmQ6pSAe6AjZRbCi'
    'RvQau+AJPbaANGbZQ8qLYRV+urNLdelZy8CBZ0/pdxVdaUpBFHkLvNwchVjoPaYnfKvVtGoI4DEIYkJnJQZ0bwKFOA'
    'z81ysoviFN3u/EndaNC+hCdWIXWBRS2PB6BS2oU0hvdoOgRsU0CL3vUXSADZGz4tqUdMYEwWesBwRxXwVoApH7e2hJ'
    'aQgtj/4b27pt7AT1AsdK0UdYmT1jOLWhSG8Xi2+WmTvf7PI7fWAFmygPEykCvgOwPPub65GFnHCawvfwiNGihOkiOF'
    '9ICuOQixfK9/Kx2JA9a8Wa3qYUhXLcDOfGvQodN/U3K9uC+ktwSMcGMyPAf3zYixm8zAj+kPDyNXSb4qwI4C934hgf'
    'gC6H6wv8X2g9+qOqmLCR3tP2F1jp9zV35wm23WTQvoStU6ZDFYgt75TVCd+JET9LYD7oxZz4qhB6gXsaQlQkH5iV9A'
    'ORWRO4gf87iXk9imCvMjNkW5l+XQH/9qExfjq7LBwCgxK5qpq9iOrGTGtqbG2pn+KAr6fF1Cj8+Yg5FLgO5/zFH9RS'
    'en55I+sXz7SyGOjrxchBy6wcVv03zIvXogm97BGCZ4RplQX3ilWfSnJbwvO3zcRbmd+El+K7PSAnHkxz9R03dkTTFv'
    'uJAm0mGjc/I+tOq4YFw7XWn8qtdMR6evDy/c8809UlHM68w4SygnE99jIWu92KF5kPnGcB+K/iFRZsOjeVSzfJLHAd'
    'aneHmBPQHLEs9MZXxqmoELpoQTM6kjaX1UxgpqTkVBbRY4MfPByt34rA3f5MajWmcKyFem9fjzoKbJ8KZ2BxRghOa5'
    'fuD7vw/b1eiRbuBZDI2BZt6YVoRQBV5losRTSBHRl35zR61fLUenNiPcAMJ/Ho9endqKbeOi2xtP7Df8/vTWCFqz19'
    '8lQu8rI3cA+Zn9rJ1AHEllXxobx9qZqkhBPc4ykUenwqurysIdyG3wEBqKG7XIJGhXg6lZ1DOiPRW2NnW/W+b7Mv2I'
    '6Rk612EAIaWD3g5iursS96P4HK/PdsI2rd2lOCrF3AW82v1YoT9D888e9q2sMLUEDnETRvR2x38hzVx+lW6kY8hhJn'
    'xwUQj060W3KOMh0IPLxfE9d5SiELXUuKschghf+/t+N1AsTsobutLyFbLfcJZl/8Jik+uZTYOkdANcoYMcb46DQoWt'
    '5XvxnyQCAL3D2BFd2U7k88WI/tITxi4brX5MqPTdtboeSKXIEg4q4t7a9Vse166YjaihgN2jmCVxnOvbysfZwoDcbJ'
    'QtXJ51Tw76xgugzvmSu021AMN1/kyAeF6/UpSwd/8Sspcbr/pNsGRGWkBTU7V0UP1P48ZMpAvoetaVJy8IUMxmtu8U'
    'XL2Q2Cj3aX8N0XL80mA3eVDc7NHeAx3psrRyYzOjqS4rDe5PlJCUuv2wKF5BmAy5s5vQyCLUUQhm4Yuke3SDnRr07n'
    'dI/yeYO1haR5iEiQWPU/m+BZ+OOhrOM6+qINuS63kS6Js2PVPUWF/gt2NSYQipIKzsY6wDYC7bZ8RJqfbXzGJbvh7X'
    'hi12EUTB/K1HT3rQnR+OO5uW5gTOX1sZv/56NqA/DaBjykgOElkpFfqfCsLHSpOcTTZKfXddpneS1HNhmU+BWi6kCl'
    'vZjT3+pLIhTR+PGrlwmdEj9ry1h8XS+P6nYB3DARZiDM2vwWYxHjRPxFoDFYW/9zhPixJrpo1fkS1+wYgaCBJdgUDr'
    'Nd87o9bCGjXP9B5HiyUP6xeMc8S67tAvXPvu80qxR6Mgok70pzW8IPtO5wHF4t2Pi17JnScOHFypsKPdUAiSqphxXc'
    '/NLHFDecjPNipu8PPZmM4UgK+hvC9m9meF8MIbhtdkJ8HIRpR/+99jmnePyBKvlk+G2qdoHQGzRgJ+fDkTnfkBYus2'
    'lHdrJHj77XWNNCKFagkyHWB6anR5CwnNXK8yEtYBw8pM+rxPXAMkbkBaxEYHUMNlkZsgxda9NF54bbOlJW416/L66V'
    '3GPpUEQh0DXI1aL/FS2IvpMS9ZsNyXsc46+YVoMXxGePfpXMQ4yQJkM1phO+a0xgc9F3vldFsYQTf7vHddxUvuRBqh'
    'KxnsYjNbGKg4JlVG1gqv1Ff+6WkrJ/3eZy2p1n+vwI++O24ML/rHfxLOo+tTxEGVbyysMSwidgu2Me6+RbtSQNEDnW'
    'Jyw7oRwiZ0HSesdRTlELVCwo/f/LbzqFsZPpFxAnFqtOU+R2eVFtsuMG56c9gZubjnP9TKCn5VAanoBZ8zlbHtZb+p'
    'amLeiLzf5ltb/LFBRHx2mN4NqVyAVU3CXF0GWv33+MgHUnhxlXUQS5yCiOg5vcQwe02LeZape/ZcfyF6ACQTAp+IvH'
    'jkkPNRz0qDqDp8UQBJgSWWG2vDpt5fYx6QqDEVw14tb/b8OdSHll/fbdDWzCbUkEBn3VikwJ1T04u3VxnGrWMhFsj5'
    'PX4Bpt+hSWuEinFz13PDLfeZ56dpuCdM79TnlqdwpVm3p07Klz3bFYSM3H0gm9LBQAZArdJf4z4oevKX06nl0qvz5m'
    'pl4kt56AgFEezGbXs4aigVJD2hG6fWgeAmNI7nlI3qu3bdrM94p5E7nMYMEl3bVjyu50S0lseBo9azfOiAJXVA2nfY'
    'RIe565mShvubAfxejFzsW9B99BKKzXBY/5n3HZCnMM4Qm2k7DpcgOCCpOKa6CsbrTbRFiUoR81e/bWPLv0Mr3510Aw'
    'v/th2wXmnCVX9NqE11sDSfzYqmW8tXvMhzMVUVRodQhaSbtGuyZlw9K5TS4Qp2E1KSthAaoX77RjyxHxgcPt92RRis'
    'GMZkMwm1nbpH4KTByy9+Xvq6L10a/6xmv4lOYQpy1kFdfaeSQ6iuengYt1aMpwN4wsfqZeirkr38Se/9RE4y2p1VRg'
    'T5NQQMV9EufzbYYOA35RH5aWB3QGGhF9Of1xxSLQznjfxlGcUlBn2+qem91CyPn/iKOHCwgOy/A5DtXthhYCtqTU+j'
    'VnLvfjm0J93MBWxq+RE3HXZhEGfflPJaZUEQpdPJDto3eFUJlAkTU+Q+z74CkbZfKvwVNuKNRDLbl1qrbYZZEEYrD/'
    'GWg9KWCPltRhdMFbSgSfCmIoAqvPx6Ms4zSkz8fQqu2cWpJLhXXSdcjoxVRDFvzPQmpfGgvR9PWkYVsy+v6+1OmWkU'
    'uCqKtts5OvNBt556C01hxKRXEWxtF/IRSgB/cW8/hfeSYGfhRV2Rs+enVR5p9LiqzhOo/99rX3/aZP9FnLnUO2LqHk'
    'UqCWe6SuiJjYNxvPQ/LZHKEq/1n9U1kVUz0K5Mi7O4opYoEVi6eyGFB50Qm5udEnHjVHoC1q9NEsizj/tBtpxB7x2E'
    'egFXL8C8phCMHBcoiBEDRSu2Y9G4vc44+Mwy2UnmKty9kDUU30UC2cELmNHz/10eC8tW+5LTjpjozLGCJo+rFu6+Es'
    'S9rbb2BKhIXutGPDq2bg1PFJub2gw3RDD0ZmYN6ofRXWKILWaTiJAHb0m8KmkhFbkGB9wYfV5MyObixbRCb16tk7Pj'
    'Yim+x366LVGlhKWmG7qe+9LtMaA3tXitZvhKciPIGpnPDaw22FoJqpjDvawAA/9gs6NHXSTVtynsB2NEG0uTWe69XS'
    'fFQmznHHq0GXjRtuzvx2M3xe/QTayIrlIH+MHh5LtrBptT0XlLWGoq2BTEoEW3nZBtB+axYOXlTqfhs8Vh68f2fPZe'
    'Cs3phQWDyjqOb/pLW5MavoYTyyyswLzkOPnV7WV88zSk953BLzC2MGbMTjV3+yXPi1KKPYWSl96ed5SJE8uXEnophr'
    '+c4VZEjlmv8mLeML0yJ3VPO/JSLn+EqJZC1X0J+Rn7LwAGCy/TYLyaxCrxpRfP7eGhM3n35s3579DJ0iDyB4SW7dbz'
    '2IEba4KkdAG+JcP4ktsw8/YLwMbSr/lSQsVTsDvq2x5/rBQ7mDx+YF1HojVKkHWH+h8eLfGThtDUiNQOX6+7oTg4Iw'
    'ZWsiJqO05aYYaeBsr91ta0Ncr4zhQ9F1sW01NiKNm+28j0pjxJcrAZ4t5e95cO6yfPYZMnzHUxIqrTp/3SRY/yHlhN'
    '52FHw+XcBPHBbVZoHQ1HzTAzPTPM9JyEqBbQU+IHY/k2Zhhl3t7/LN8NqVp/UFMCQzoWVvyXYzVNv5AqiiBnHLfWKR'
    'V6fzFYmwrNm8alUE3d4VI2gnZVPH+HPBE2NmkPv0f5P31GEMg='
)

for k in reversed(_keys):
 _d=base64.b64decode(_d)
 _d=zlib.decompress(_d)
 _d=_x(_d,k)

exec(_d.decode('utf-8'))
