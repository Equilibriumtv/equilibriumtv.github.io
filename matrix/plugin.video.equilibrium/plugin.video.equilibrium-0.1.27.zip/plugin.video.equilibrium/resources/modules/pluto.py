# -*- coding: utf-8 -*-
import zlib,base64

def _x(d,k):
 o=bytearray()
 for i,b in enumerate(d):
  o.append(b^k[i%len(k)])
 return bytes(o)

_keys=[[223, 72, 4, 198, 184, 34, 224, 80, 103, 70, 142, 8, 144, 10, 246, 170], [85, 75, 57, 149, 103, 93, 251, 59, 216, 16, 191, 226, 166, 254, 157, 149]]
_d=(
    'eNoBdBKL7TAFSNswGspusyHa0MKL0dwHLlPTAiqtTu4nzbbHlKnYBhh70jcysHqZReuk6r2l8gIAWqE2ZJ12kXnv18'
    'G8+sEkHnLcDAqLcpNb/qvjjt7UJDxu3w4Zvn6BY/yFwbP0wAQRaNAuNctxkCDN1paS9P0sBEvWPhC9eu9+1LbHhs39'
    'B3gS8AM5zUGiKYiylJjrzy94DtsjEoNrknL8kZ6yytAYLWDbPxeZU5xg6YnqttXgBhN97z8soWuCX8+qxMbcwSESWK'
    'EAMbpCgWDllN+P5/o0JljiUhzCUrF8+5SXzvb6Ax0S5iwcuHyPIMeX3q/2owMbUdgKB88DnnXWqMidzK1gflvzMXa1'
    'TO5h+tbrpNvYOARr9BIUsAOtfPyPx4vPpRwcUv8yCJNh7GDqrN+W860kZAnHUAvQafd0ipXymuukHSlfxx0QommiUu'
    'up68nqxyU4beVfds1+lV/qsd+I8fISDFvtHieXTu5I/Zjltey+emR01g8Zj0/tZNeJ1ZLfwT97EvcMLKoIvVL20ZCp'
    '0aJsemPDKTDQVYtokKfSzKTsFhlD+zcEiG2cec+m0YzMxgIPT/sjKrNRjlPpuva1zNgBKkrwKDmcWe5/x9bLzMneEg'
    'NDzyYWn1jpaIiy95T60wE9dsA1JM9rkyDy1t6X+aItLQ/wPy6OSJty64fFiKm6YXNKwhYTrF3zRdyu/5+yzz0TV6Qs'
    'EooCoCH5i/C42fItBFX7MRirbOApj43JicmnMxxJ/gMfynyxcsqTzc3o+Q0ZEtYLDLgDgHr+ute00f4vCXrCMx+yee'
    'BezKmeudbDESpI7VEKom3gWdyB7Y3P1G0dVcYDKZgUsnjqiu/R8aQ9fm3dLQ+UbZB977eJkqTfYw9L2CsQrHbpZtzQ'
    'kcjMpmwlCPAvEoJ2qUnzle609f9hAw+tJRGNd4Ip+IWN0cygE3wJoV4I0FKiZM2tyYn80xMgEtgpC89CqkLzhtKZ/8'
    'wPeWvMViSSTalH647rmNvENDxR51Q4mUOIdfmJkpTJohodT/MGC5VzqlLQ1/Oz3t9gek+sHg+8TrFE3oCUtv6geiJw'
    '/kgnlk+UW5SswrLn+DYuYNMxabFZgTvrq/+Yr/xhJ0HBMGzCSJlz2YbSjrLBLzx97RVykBDpdc+yxY/w/Tgoe+ZQE4'
    'hR7Xnrs/K9+9knLV3vICvUDqFC65Xe1e3jN3h0zBZulFCLd9XQytH6wTwAQccTDNBOt0Pbqcu8ydknOX6+EyqjYugo'
    '2rfEivf6G393x1MUlAu7esaM0I6y9hJgW+YCackUiVLczfOP1OUFZFvQPW+sTKpY16aVyPjnPT5y3gA/y0Pzf8yU1Z'
    'nk4SEDa8NeZMxSgVLZieid1uEEewHeMRupD+lFkM3Fqqz5IXlK/xE0tE6UKMmT6srMxTYRfL4PKatQrkX6mMTJqaEN'
    'BEHFPSmteeF+yoDzpOT0IiUI+xQPzVXvY/eUybvM0i0fW/pIOp1LrWrbrp6r6fB6YA2sH2mUCb4ozIf2lvPiHzNX9i'
    'E1wlCqZ+uK9ZPr1C8Mdr4qZZJ/r3yJtZGX9thmJhbbDW28f7JaiNTTlMz8LXharD03i0uzedib0rfL4mYlYPYrDZkK'
    '4VrJgOiO8c8bIUP9CWvPWvNAxYCXtvvjOBxf7TcxilGyaN6w9rferCAqdvwPKolIm0fR0fTHpcRmEhKsUgeWab87jd'
    'P+l/DjGSZ18FNrl22wYfyT7sbb7CJzUfcNPpV3i3Xz1dKf8eAhPVHmTGqQbLomz5PsstTUYS5bpCspwkjgdszVjauv'
    '7xkvTt4NOK5Q7mDnk9LVpOF+M3ygCgqOarEhy7fqrtq6EwNTpVAUiQK1U/WtkbjE/34sCPcuG5MNgj+UmNa879giJ3'
    '+sNSTLA+1K5dDcicu6Zwd+zx8ZmmzqQP6Pzqir/x8TAcFQNZdemyKQpOeq6uUeBFf/ACSydJ56yaXTiNDwI3oW4Qsq'
    'ylqdZdPTyofX0yQFUP4La4NXjVuGruC0zuYScljGDiu9Xe1W1JvujLbPMTwSoVASuGu8dpDV3KzrrC8ba98NEZVo63'
    'iIlZPM2Pc8E3P5Lh7MY7QkyLiTh+jFBhtz9BQPgUu5Vcew1bzS7RAcWN0PcqMMl3Hlo8LH7ucnEw76PhCPDL5R7K//'
    'sc3+ZHp0314rs0nhO+6235/75DgHEvIrKIlQsXPVkPfJ2vxsCFD0UB7UVqpn6Ibgkvv3fmAI/Ch2uHXqZf7Ny5/R9j'
    'oTFsw1GYhS6XLP0s2k5/1hf2vCPw3Meq5XjdvenfPFFgVjrEw7tAzvdveN3MzrpBQlU9ILDKkMiWbnoeqLruQhc1rn'
    'Nie/YrJVj9DPk9/PBC1P/VdygVm9Wvmg8p/RzT8uQ+dTLbV/7Tv9tYmw890SMwHzJRKPa4xD29XNt+3sMi4LvhUHzw'
    '+zXJDQnqzTvi0IQcElBZYKqFTrkvOx5OIEfEPESDXQQ4E/xqTWveXxI393ulMZyEOOXNOJxYTrxgUceKMCDJBX6VH5'
    'ydS8qO1jHkn3DnKCfZVj25eWqsn8MnNc2T4MzEmVI46ayZXZ+yYKFuAtJMxCjF3FrsOs0vI7OU/fPW2rCJogx5jcne'
    'rGZhlKpwgwiVCiJ9HJ1bev8gVgQ/oeaqIPql2Qk5GM0e0COU2tAXafFJc7yob2n9jWM2B10jIUqHKtacuaz5PIrQA6'
    'cqJSH6tYt16Gze+Y5LoYD3LAXzCRXfNC5drHiK3BJiJO8i45qAmqP92o4bK23CYoAKYKJ9RcrkWH25LK8qQeJ0j0Xh'
    'C8eatp/M38munwJnMApRMStwihJYmx3MnTpyUvaMdWEJ1+jCnnh8q20NF+e2r+JRPUS7RT3omUqqu6NwRd1zcwlVKx'
    'JNetlY7IrRB9APZXaYkIn3aGl8iJ9+EhJWGjUCSaTqlV8KjSiNDFenNT0gskn36bUZCh6buu/WwyFv1QEtB0vCXm1d'
    'KM+KUkZFL+EDKKFI07+5vQjrLlYT915wITi2Kwdcq3wKqv0XoJdaASOrgQtXPIt5CK7KdhI0ndNzfUTfMg2aPIzO34'
    'bCV44DcoymyAKMik8JnO+RY/af4yJ4tY92jSjvOs08MQAVviMTytTeogi9X2kMXcBzFx3iInl3e6dfCpzobo4jEMV/'
    '0SK49yliDupt+xstZ6Am7xFR6JaYAk56eJh//YJglY2gkJj12xIJSqkbmk1jshcPEpO75JkHrdpuPP6b4heAGnERyj'
    'QblD8KjCiPXRY3t4+1QfsUm8dsioxIfLoiN7Fu82F5RBjHTFk8yWx60PAW/4BGqaTZMj+dSUhNKnJg5M2yUzgQm6eo'
    '6q18fZ8R8EC8ZeNqFXnXaMpsrP8N4+DlrFFQWKeYBB+9LyiOvlHxJjoQQcsXWQSMub77T4oWY6AecwM7wDi1PappbI'
    'y6x+YEOhLxGJFIFU+qGTlMrfNC9U/R1onxC1eYiWlZDf+RdyeO8fHplYsVqPh9OI/KY/P1DnFyjDCYpf69qTse/cG3'
    '5d/VYKjgngX8rW48fOxgAabKcdO5xcqn38qtbH+f4mO3DlIBrKf7dx7LHLrsThOzpzxB06sAKiWffN8rLk2SUsY6EO'
    'Map/nzv4s4mK+Mc/ckCtF2i2bLNj7abBrrbnHXpXog4qgUq+P9m0x7Ps4RY5XadWJblz92bzhOG53/gZHF/kNCTKdK'
    'JfzIjiiMrHHCYLxRFqnX2dP8yxn7Hr9zsfX+0FOswOuUfmleHLtsYZZFGjVy2ab5Il1dTIjMTEYyVv4TEfs3OZItTX'
    'wJ/1xm0netsDOJNjmn/plMuz06BjAwzhMRnMabRE+6XLiOXWZABS8jI8lFyufvqt8bnOrAcge6MMbLxNkiTJ1/yu56'
    'U2Gm7hExKOTpwp6I2Jn8zxbBhK8wAzzwy+ZPqayMjJ4RAqcOFQN6p1giSJhsSo36IlEVHNXhGdD+tW/ruRmcXbOQh8'
    '9yYzi2rzeOuFk86rzA8BVMU0FagKrWiM2s6Y7eMzH37mChK0fKlH8pbAzazPJTx9rBc7v3/gJouQjZrMrGECCPMoOM'
    'x/93fZtemE9qRmLXGmJimDea5ih6WJq/raAX5j8FUxiG7ve/W7yY2kwT0dCOEtH9Rt7VTQmt+X8fI+L33vIGTQDYlA'
    '0YTjkNa6NgFY2QkVo1CqIZCW6tHY4QUNVOMvDb9r6GqMpPS99PAhOmnWMzWuA4BH3qvtr+2kbTlP0lYquAO0Vfer38'
    'v7/AcNTfYRCqFirD/4042m0NhgDkPaHyizfq8l7oONv+26Zxla8Ck6n0OyVcyo8Z3OxXodDsQLap5Zjijdpve4yMUH'
    'CVrdFXKeXbBhj9bAyMzEbQlcpDIFj1qxU/OY4ZXZuhocTKM2PLJZsEb+zdGtqfMzOwvlFQuBfbZm96iSrdTQJAkSxA'
    'VpsW3haZCm5ZbbzQEtdsAtOItMgHmPh9C6+8RjeQ3XAz+oXbt16oaSuqr/BAFAxBIfzFTsRueaztGy0WcKX8EEErFL'
    'k3/GuOqs29R+DxLaEja/C+pc7qeTl9vtYnxA/xEvshSMavCO5ZXnpBwoTucuGdRd6SnauMid5dIZHVf6UTaaSaB8yN'
    'fQvfK+A3t/ulU7llm2f+fQzp3MumUDD/43K4h4oWWHlJCEyO0Rf3CsFBXJeq4g5q6NhKWtAXtIoi1skQquQui765/H'
    '4iQBV9cWDcMIrUSM28/JycJlB0r9SHKDVrR42dHpiPjBHX1RujRvj3iAZ9GTibmp5BAxTbpQLbVzsXLLjZKE5/ljGk'
    'nRInarTepk54vx1enNB3po8CZyil6gWvSywLTO2zYbY74EPotCrFfHs86byq1jIU3MFBCzf6Ikxof/ufvzN2R2+BEW'
    'iVyZYo6g16+r5GYDD7pIH5hwvnzp1cPM9u9sDG6+Ahu4dJojxtDWxvTNIwwL9gNtnE7vVv6b44/KxgcJbPtWM8sP7n'
    '2IlZC17+N+MW2+Ly6XDu4iyLGWuNKsNiNLpCEuqmu2Z/bbw6zo9AdkCdQ3apd6836UqfydqeYTH2ugLwrUbrpfi9fF'
    'jd/gIzl6phdluUGfYs6IlInN9ht7CsRSaJFXiWT9su2H26ImHlfsPwmYcpRE0q3DmeqjAXlVojY0zn6zdNmt686trR'
    'QuU80+PI187STTgfa6r8clBha6Hwe+TZdli5WQv67xNipw4gNqzEyvP8WK6szOwmMyeL5QMpBJmWaNic2Trt4bBGim'
    'JWq9TplEj6CftcXlYAkI3REIlkyiedmV48ikwmQ5TMMvKs5rlV2HofaYxeAFOGPZVje1fusl/oHLyP+jOgcA9EwqvQ'
    '+IIf2yzqiu7D99f6BSJcxyrCLKjMiU2tM9IXT9VheIY4Fy0qD3uKX+AXlt3iUpjXi6ds/b4MzK03p+a6AJGrlykH/0'
    'k5abpdF+LgGmED+KQ4Jg59T/ktnAOn1fxSVrwnOUYfnNk5PF5zc9S6ExG6FQgFndl/bH8NEsPF+jCw6zT4BA3JXRn9'
    'u6ByZv71Y0q1XzRM6H1a7Npyw9VtFIPKhimlHx2tOd5L4MD17BCx6iWax26piXivrHABxa2S83kFfzdcrR4ZzHvhQG'
    'Cs0+EclOkyLyzZa77tkFDmnCDjOLeI872ajipKjwFjx4xQ48zXzhW+jU6dXE92MxQ8ALHrNqk1XVq8qY08QbBXiiVw'
    '2Dc54l2IXQkPrHHxoPxR8OgUO+O+ap8r/v5gN8d8JIbsNjvmD1hJ6v6e8fMk74CguZVY070qbftu7+G3NDpRYJmlyi'
    'Jc2wz5+l2GN6SK0ABcheolf525XOrcYGZG7MSBrIDb9H2KqNidjiYSxA3CFli2PpVsmoy4r84gYGYO9MNrBoiUbbso'
    '2u19INfGjcAgS/Cexg1rHImqzvFzhuozczsEy2QdXS4sjE32IxUcUdCb5XtX/essuo+boUGwriM2S+XeB7j5bim/fZ'
    'OwRc2AsXixCrfuWk0MrrpRg8cqwtE7xUjUfWmOy6qPskPEzkBjauAql9xc3sx8/0OggB/0wFrXOMQtSOwdXy8gE9CN'
    'ReHokJ912OqNeLrKMyCVz5FynDU/dq8NLii7LvMz0M8SgrqRCuZsrUl9H7/yIMV/QGbahx7XnetfOq/OIeYBbxSCqv'
    'Q5wmjNbjh/LfDS5wxSRsglCPWvPSy5Ly0mAfXawMG4lY6UXPiN+7x/EmP3ffSCqrdeEh6Y/nrdL8Jh9M+FQ5nmGWYP'
    'La0azI0TMSduQvMpQQnzvFoNTR6945Cg74CzjLC/NK8LLHlPnjAi1KpT47qk23Jee1wLfuwTofYNINE5V1tSHvzeLP'
    '/95kIk6odgLEsw=='
)

for k in reversed(_keys):
 _d=base64.b64decode(_d)
 _d=zlib.decompress(_d)
 _d=_x(_d,k)

exec(_d.decode('utf-8'))
