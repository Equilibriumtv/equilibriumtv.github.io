# -*- coding: utf-8 -*-
import xbmc # type: ignore
import xbmcaddon # type: ignore
addon       = xbmcaddon.Addon()
addon_name  = addon.getAddonInfo('name')
addon_id    = addon.getAddonInfo('id')
addon_ver   = addon.getAddonInfo('version')
xbmc.log(f"[{addon_name}] Serviço iniciado (ID: {addon_id}, Versão: {addon_ver})", xbmc.LOGINFO)
xbmc.log(f"[{addon_name}] Proxy ativo em segundo plano.", xbmc.LOGINFO)
monitor = xbmc.Monitor()
monitor.waitForAbort()

xbmc.log(f"[{addon_name}] Serviço finalizado.", xbmc.LOGINFO)
