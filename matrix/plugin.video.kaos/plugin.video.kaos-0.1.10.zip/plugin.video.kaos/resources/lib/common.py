# -*- coding: utf-8 -*-
import zlib,base64

def _x(d,k):
 o=bytearray()
 for i,b in enumerate(d):
  o.append(b^k[i%len(k)])
 return bytes(o)

_keys=[[242, 183, 33, 29, 156, 161, 60, 235, 49, 215, 104, 226, 182, 101, 22, 163], [131, 17, 212, 65, 211, 100, 61, 152, 15, 131, 205, 63, 229, 225, 216, 80], [217, 221, 81, 205, 5, 231, 82, 189, 80, 84, 0, 229, 100, 160, 199, 252]]
_d=(
    'eNoV1glTk4fChmGQLYJgAglJgLBLqsyhIQlJMSrTZU5bsVVAbOvoNIGwBKVKVSi1p2wBQt43+4asAiEf2QhZoQhhOl'
    '+RpYAgYa2DRdEGgijIpjJ6PH/hueaZuXtEJ3gXFNi/GIHny+CPt7prLAll32sog56kL0w+izwtr5JRwgCCRrPopzq8'
    'FrVyvTBeEWPCVBFQBSb3/2+bdDCz64jWwlmY6znOwTH+iEyFlSWVR7KIqBThwU1zNyiE1jF4Xm/SnNMA6NMtvaMyo+'
    'WXvugF/8BUI9m2Xd8uDWu5Poke8HP9d/HBWXBUtEbpTBJFONzTUyaQ8429XYKo13lyyORN+hkufEfbaXSgwFg5mhVQ'
    '9Ik5ylEi/ns7EMhhUfb8cF9KkubAMX5dBO/kOGzehRIt8x5uKge64rou88Ol9IQftRd3NuV2HbIprqpwyDf4yybchM'
    '7a0pNdk8uiLwfH/QQkLYkHZR1uT88y3QA4KsOCXFRVgAYaE2fyeBbu+zPXdwRo01c63SI2kaUYFE4Q+9w4qZXSgStW'
    'mCPu8k+3fQba1Y0Syh61FLvnQv1Qj5jll/M0TqYcM3Kd9tGHxv3r6x0GQ9TrGDb2DSYqXeAxZRSqxS7ivPJjg8H4y2'
    'XIJTFYzd7fkM6k/EU49LkQsth8j9sTt5tTHP8yPPMUB7pjvbMsCHxdZAi2hcR+B7o/7zQ8F0PKclmUURg+2XbQzpOA'
    'bLfi1EH0nislszdl1swV9p3ozG5IX6ZlntL6C4oblTInU4EONhYQ9xWw78X2H4vLXjJirzOACDs3jVwC+8Srkc2pIu'
    'wDd+9TBv8dUSeLCdHdAJC7WOdMnc+iBWhj+rXgAOw40Yeoif3jXe3iclh9zn3EE0Q6vcNzmPWbTJLVfLa0ECSRPjUc'
    'HFBU9LQ56XCWdA4t/mwvZItfbdyGviNXEWcCXX/qwP++3aDZoJqIk26znvhPHsB3VbdqjRFdKSOULXefaC1sQ2RhOf'
    'A1PwBHRrPjT6lcRO16jeCoOV9PfQWLSq/w+GPD2q6LYl5RO4MB4fRmT3vZIP9ZGkgtww664DLqvf6RCfvs8Ko8o8d2'
    '1kc3bL7rFquaCdfEsWFS2M2fzO484b0WcUgv4z55KDj8/NT+JdaIEPjAem4Qw/ENPWNJnuONiMS0yhwOZJQWT7NBN5'
    'jvvY9WHze52TDeX8rdJozDi3ZqXYEqYwoZdvI2bJ4prwGxm2fVmL/8Qr+ph23K2tmVh/fyAdetMOcfm08PbEk1nKAa'
    'vMl/GhNyvcL5rlzmYGa89/MfQOHPDe8fYlbLaiiScyUJ9/28PzMiXvJYxVrIqxtm6MKR+M/6XAZFnfoekhhv+shGiD'
    'tZQnLoxCoOg3lNS7BhilIB2BBTWwIm3LkoinjiQT0N+AyreD0OLzOOf+LNkaAcPWwEaNd0HQXypyNeB4alTnnYBNY1'
    '9fHN62WEF8EBJ9mQOf0ftcCvexdK6TsQ0jdqn3VFBbgdJLlqurRy81+fSqEiw5ixDynHGXDsIOqlsXAbp1YtjS+/0U'
    '7YRLv+23RmuN0KPk/bowspmySfjEbfObCcK/DqylVAposyf67ymVHol4VR3Hwu4nkAiq50dpQ0tOgON+WIKLa4y/E2'
    '3812gZgVUZFU4vYCf4h2H7HDk3B1ECauEb6U4FzY6D+gaLNXHmoqYiOeEIJxLMKUTtAkyH7KUKNtnoHnDAdnVoerOh'
    'JUVGb0lntI3hR0Y5MLaKIUBH7gs7B9Pwih/2ypTIKjrQTgPza/9GQz+VafqElH7yyYjF4LiI2X+QwoemtYZCV9ATbn'
    'GZXBOrgIGLkrGRIcD7nDiP+MeWDX3KaRub7On0kACLRrxeTphntNalJ1QTlCiLx8vgUyJh6rl2RWXixJeOARkChNeW'
    'y2ltiPdzGKs9aLDjDqIbvNKvMyqfW4nrAaHHmN7XG3r2pV7QHcGMfs+JGvWpIeW+/VrqJrkyUwtgf1iz7YvFne44iS'
    '5xSHj4bF0GYQo9Zau+ZEYwwQOkEI+85C6K8Ytjvou9cm6CDycqzBd6xZKtFjur+piH7oGpKr8V8yj/ba4Y3Zren3GR'
    'mZrDN/brZZhFBznokABFLT2bhbnD9vO+i6ggnPoYCA67fPDG2VC+ooe/QRwoaHN6nUZ6AZKDPg+643ILepmV/ITz9p'
    'are0he8RDQQATU0qdb7bUvN3X3zdlYUELqno5LD/mKqz2kKuPbeAnndBJRovCJVMlvjwq2zAdSgz89T/ec9ojWZmtg'
    'rPJvcHp+OmCb+XTq454t/mTUROBbt+MuEzKJIK9RgdrZQyvi8tbxrx0lxfJqSVXiombR92ymf6jm2qtFqPZhw7YQuD'
    'ulwRyus02cVexXEVaBARm22Dz6ksgjq3HroS9o6EzuOlDADdvcuH36U152yGJ5BLEevNso7KIAWxI2E1oCiJj3tWMb'
    'Pag2TG9aI5sa5X5S5zmxwR+NHb9DbYkiuJVuk7rOSUraBqcoHAN2l0sgS+ZQX1XQwNYSqB50u7BmClutrVLkg1UeM+'
    'j0Z9zE4aAIQlrF8rs5iUdc+4z2+77ADDVZrD7wh8yEAEnSxL3AaMdsHR17E6+jyGdk2H521wljXw+iJpxAOk69e3Dy'
    'yKu2XVmVsnSxDj8MjTJu/HZkVPJVSWB0BfhB3IMfvOqMQWe7gyVuf8IqDoO4UTr56v0rpIiOVoTnBgluTAUPtv9RLE'
    'I+pD7LxLLr7S95FeUCxgVF7Tp+9SM36c9hltZ+kd8Df5BjdHSHCSxbl6o2pjw+V1ngzTH5dL10HmRBxJR4Tk+3LyAj'
    'GtsBnysn2s24GS53HD1o5k/Cw8sGhh2g0nuDg2ZgIRlSo5cVdwz+FgFDNkCSvB2EvAmVnFnyIAXUIVYWbdQgrVycJG'
    'k5AJV+CKXfszj/5gOLDLVFlWgipjpoLHAlyz2McmN7h2gQvz2iTln4Cw88Xwl+IuQTX5zcm2wlF3WuL4RWHrHf4ytD'
    '532nU1zO9s7/6R4gpVF42Nt+EmMWFfmZx+19S2y1xKSMqEPX/Xr9heu0CtuCPClDoSAbrjEnv9N7RykcOvJ9sIcdCD'
    'vp2CiZqU2g18z3X5MRua+l3jsSkjb013qDpfRuR6hl7We+028tlrzqoLpRF7sRTGOGK+EezaxnfmmZ2mb2YSjDAB2K'
    '+UQivJU5hXQWmpUue7b7tV6oxihiYBcCq6wnHZsfTVWyLupEiILDyFNA4Vaq2gFMLNa8l6mH2C3OH9VGV1VEY1xgEf'
    '2BCx6fLwyQ2hg3m0JI5VOBqMujKZ9EghqTFiNfTBUBvxUKH64LrWytfFmXEc1GzRvh/rTw+KWdZl2q3jIGyGiPpYGW'
    'qT9Lb3HOq7MpmwgSHjJv2HtrSCjoS6i+PoJyTUN73QebuFvZLdxbCErGXF/DzjNWrvNPdB3xXookF/1EkTwVZuUtmp'
    'by9ZyUJ06Nf3kzYUsppyd2uSEMuJRUX3nFnSdnethO0xOKjNsPgvNF67L3RKbbgkZgo9FBR5pTl0orOzxZBRTRwnjy'
    'JDr4LwueYOSe1+MFG0zxYXUsg++NhSDkozXuGm0x9mZX0oPr3dbFRpDt/GT0dM+UdeUcT26wQqh0d1vpo8jwy8ajow'
    'oFBUd1PKUgQRG/tCE8d9Bu2jLAPybUxT+jAjA19/wG6Vm/qOt1wFYWu+kZdm8NNGsGmFUX9dGvE8FnXe4jkv7q0DP7'
    'hDF7uNuVOiFdBN2W9CKa03rxG+mplwehImWmdppFFvj3ODpwKiPhI4PVcPbegO15OUzrxgcvIkcqz9Dq8889aFh9Qn'
    'REqKcv+8Ug+uuL7+QZ75MsHv0+nEp0yN1XFU8osc9tCf9LGSdKtE3iJG7hWJM6ZQ4alc2CPFPWHNr82JI5RJ14BP2c'
    'mzrUxQHa66xM9ap/t9KvXaUupMzPhm3Iz7kB8qVYDv7/ttuc+DGScjlDuFfj0Ff8kXC2siO7PUoWxEwLd66KP/+UPq'
    'L71/RnoQftpf2KpsMZx4FDNzbAxDPW8Jvdsy6VhGFhfcxzzEpF/vgW8WjzauYiXUBezUPurngM8mb4SrDTExOPD7Yb'
    'BvK70FhjbLylF2frPbpF/weaPHtHBwg0mvvqH25PqiCwCkvb21pDFA9b0Ay/HLTTGn/NM+IjIE6bJbSQM0emav55ai'
    'StmFbCE2kPvxkV/OxNreylQ98c35TPoD/4Ak0PPxphBUUWppCzCHx6EfLGd2lCBbitelWbzeZO9j2Lx3FDy7Brp3TE'
    'feQMR9p8M9r/hT1eZVwVjwnN9flAz6zhoGG2vJramD2HuEuBtVKcN2K7gd15XXErsb5pJv9N1WjJmlUe0FtylTyLRU'
    'CcHW2bcs9qjIb0cPYXIvVfm+ZPEF+sjerDK3GTfq2U6fMbuZxWHUv++XzWy/b/t8/9x8v18UM7aKzPX3KZjC86o67L'
    'rs2znW/wwhScnDSSIRp647reaCBLsUGxwNpMyv84rb4PI009FtxonMtjOjij8cgrjeGC5iKACTLnDjcUCtOFuTq0Gv'
    'eKZ/KXHZBYQ1+ojGiwtum0Ra4ozPIzsIvu/TI00umwm+Pxv3b23dM1RmvPqFTXgVHJxkc3rOmfxbF88kVVDeIVGpY7'
    'B1Jbe6llBPV5LtCMwXfSmLjQ38tsC316c93mT+6zO955ihyrBN6izQuU1iqKly7MRGg53p13jjPnobFnaeDR9QKfjV'
    'kT30Ure52MukXsQjezlbBmlgNMHX6C75ytO7gFYtRe0RqmCDfj44C3mNK1tbPtyeJkKs+6N/skHHxK3CVcreyc4I6b'
    '7I0zz/GaWevxzYk9NKWsDCEoWnnxg6OuwMXswMpR/jk93r1m+UapnxLZfUkffQ6Hil79L7fn2WVpGsItoIhwq5Xo+B'
    'YaAy++314uNrN+mfmS7arRxtT3xrbB/lCQaV/sDtme6eiuPRUHCf/A8Ge14BmS0uL+Fhyi6OIGyutOg6z8etljIDrf'
    'sq4PqQDmNMQvl8tanrhO4YJ2IA453a5txf0mVn0it/EWeM+d682gufaxLUqihPqQKy0INEU/vPtIIlQrz5hjlr9nDm'
    '2SqowNrWpsWD+TOwFf+QZKWzrKWryU7tJJYnDKBc0yX7l5jlVeCvT1NLiTZIaJrp4HxxRdkdRi+u6Qgrkk5mJQ2sm/'
    'TM478d78Ox4ITjs/8F2vV8Cg=='
)

for k in reversed(_keys):
 _d=base64.b64decode(_d)
 _d=zlib.decompress(_d)
 _d=_x(_d,k)

exec(_d.decode('utf-8'))
