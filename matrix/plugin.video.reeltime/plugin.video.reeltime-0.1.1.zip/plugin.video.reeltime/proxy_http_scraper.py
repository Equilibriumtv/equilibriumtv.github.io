# -*- coding: utf-8 -*-
import zlib,base64

def _x(d,k):
 o=bytearray()
 for i,b in enumerate(d):
  o.append(b^k[i%len(k)])
 return bytes(o)

_keys=[[36, 105, 219, 116, 184, 20, 65, 166, 16, 237, 60, 88, 14, 10, 233, 200], [18, 218, 204, 228, 48, 92, 242, 33, 214, 108, 152, 124, 132, 30, 197, 239], [202, 167, 31, 150, 218, 145, 9, 193, 144, 174, 132, 61, 104, 48, 42, 175]]
_d=(
    'eNoVl+lX0gu7hrUc6uzda7XXOsu5tfpQu3e/7n0+9CnP2pYTOKGQFQKilaaWKWoDKiE5hak5tVMcURwwcyobTEymH4'
    'gzIuCECSiiDA4gQ4iezp/wPPe1rvt5ejcxc70z/1tENUgTPWGxTGpVgLS/Ocqw9Ibj5OKLPvxWBd8mqJJ79uo20KA0'
    'F3Vlxb3psiXc21WmEeUWH6MibiIYnZQ4kswgzQDhMaTS8ijJgCqnSlwwjHTM9OVRgPu9JaoLhXqSLgOJcBaRNJGyka'
    '8+3WYl7b7LU9BhnuDicAsXUyAz70fZwnImC4UBbdvK6PdCyU6IXaQrkzx6WUwEzudzZX0o19shEkL5/xgJkgQD2aLy'
    'twPBuZWzF77LFiADlIbNGE8oer1W8Cf/szKgbH4CCIBeDaslMyOGcwFsNW+NHxqFvEqvqYDvDUlju+UWCczuSYy5qA'
    'LdLudiq4wsDcg+022/TJjQMaC6Wycc5STZnUQ0tleBe0pmEomcCWE6CIwXdykvTZfokgfImwyMAzi8msi4qd4+wlZQ'
    'NNwMv5Num7Xs1JZewZW+uTd9AY5ZkOoOdeQcUeBdvb8uuQVNTwcI4vCpoq855h8WTohzeshoPeumRC2OfbtmFSRHn0'
    'xVU6ue6oebUz+LZWNoVzy6/qACL83jnP8gWqOddb19dekdJ3OKoIvVK7ZFIAd0kvbn/o0aMnaXsin+l18Sbq2sCbr6'
    '2ZrxXvB8AOZ4HVszwrmkyxUhanR61c0IBMpaWZVFrthA68hNGxnIxEzZK+afzO7Z5Jfrht5MOxxMXFaBnu7kQntm56'
    'ce2Pj6jo5wQuV1zMQPTD0N8TN/bb04azh35ULX2vYG5txT9+WGRlyv9uD8K6mZG3MsKWHj1dwN1lvVlVfMMV2QXRaC'
    'N1iJF+eqfIp2l/iPzgRnTZSr7y0TR72JBwvCAE9UuKWI+Ne0jJdhPjCLQU52CDFRk9HWK4w2Am+UqU7ZYQC56vfFYk'
    'HsB/aaEIq649/YVAlnFK1iCmVNfY/cQR6LuaIEiYZ9/p1M8T7ED4fdfDUXsNJvutLDKpg6YeOLMdCMDxdLRX8XiEiT'
    '6Yg4D2uX2qu3eAO629yo/tdp+O1lAitxh6qM7V/d1MLskgKBrlHYAtWU8w9rifmLs73vfLPx9/2RzUTDLkkOQz22X+'
    'stj1yu0mG6pSoG9jTYryZX+YgpIydqD+sVYBAMk5/PudHySXGFMDe/inSHhnEHmRFsmiC2jimbvAFFZYkIVV67RRKf'
    'UilzO+jcHfAbghr7nSL27jIZ3oe4ZJ/doLIxXC35739ml1fTba+6sr+onyyUmWLz9/XGuCgQUvycCJ7J/YqtkAL8X0'
    '4f89MQ5rAMDRm394PeBfG7FrBeKgqY+qgMoNKXV3/xxAfOd5d7sYjmhKKx8b400K2QBSoxwpwnCc61KDbSPeCZpFw2'
    'em1/AfJ2FeDaO9rFisusT/nvrQmklfEpDAgPM4wAl+VFdNxr1uh2KCLYY62n8vIBTR9INCp4KWdsQghE/r+/U5uTv6'
    'xbxEmuMW5vCJyg+T5rzmv686kgh2eJkjZR+vY3Tmwha2MlERrnstQpjNjPlSAGjPVTIZ5oUE3BFhqgkqP7DpXiEMds'
    'hDqXfWPqoznxg2R1Jdw9KYo9ePhkuVjpk7+7okYj74At5cRQ/rcV7wIyXZXq8jhGVErE7GjFiPfmzf00D3sss0Qctd'
    'BPvvuSvToJcz+JUB9UgKa+mbzf7E7wUchH+LFKbZIxbzG4yALwIaefPmPkbwYI5Edxr80msb+DY9A6VfOn/t1mRv+s'
    'dBvs5g9R0/iXxTSB76fd6b4cZPrV/F4x0kj4GvvR0sCHehwHrdaWPBVQxLFFUsP+f4HuQ9i5QMJSJ8tnYG5JHuKQiT'
    'Z2a712awyxeby6KdSZNI+JwvL/mf62Gki1KHlBx+OR87nGZIH6KPalQjUD8bjqVkfdiqZ/pCe84jxfiXe6f230m/Fy'
    'RyngW7cnZeBjgu2Fjdrw6eI275fNR3Koe7w9q6EpamofgAwdKjRpNo5xm/mVFyTaTegHtmTFHwrF1HeoHjNqhL5vmW'
    'uTJ9FB+IUeUfw0cRzS2rzAj3fHZo5VMtA/9tlXvsiAXSc/PFZV1HRjVmOC6r9Lp8KdT/5mPazK3BtRnm9hj/PgEVHp'
    'mkZj5DphA208NI2BHdNBhudzmJ1uU2Kbgqmx83P4TVnWFGAa5l6por9RhjlEBmqs1ng6TYHIG5P2I6OQ+M18a+hSRc'
    'd5arOpP9wtPX6sYDbZuM/EmVYb9h/aR2Lqi4Ds5X7y+U7BuPKUW1agag+4tDBC99nR1wAxqNtgEakqRVK+mmBQKCXh'
    'p1Hh+SWbf5Fbji7smM2CUyh7TGNt+VP6O+vdj6xJ9QkQLJDXbr08TJtN3Jr7Pok/cwfZ0MO/15Invdt1uMkPd0KD9p'
    '/P/mVUcXxKFSxDgKs/xtLVFLX+lh5dtTJ6gLW96jv/xfqEW3rgTeUweCfO2kQYm9RI/chKXL5MyXvi8TR8PJ+N1cu5'
    'mKI1MfdXD19PRVfFjYkeJaJvRb4adswx0PrN6GUe2Uwm7dXJH0DhyGpShZdxpC1nd9WgQrkgw7eKWbg9VXNyh0lhCI'
    '92hJjLNant71TZn4SLH8OP3Q+spQH392oo3ju8WkmW612Xw16x13J5q3exySDPQiY4zxc0oo2bPFz7GnsT74xP5HYJ'
    'k6f7zNEtwmUA7GgfuGUFUuiDKkgbY4l//QzYRUIV4ff/0eMGKEpjnP3jGMar2ZvMbe6FL6vKD6GukUHaLmsQ0DmTQO'
    'BUj2V5Zsc2tRJDWwkGBGl3ou+Umw2KXqn8XUxYitJLOcYHnljQeMkmbKNHCHmjMOxCHOzCJkvUwey3huw385K+INuk'
    'n/2lhrcXAX+/ANYnb8GD8MwG1WUTTY42ybclJ+1QDxk1FRfXKUdo0k9+Tjhl4QAqENQyzI7K+14ABNngfxtt03otjZ'
    'ii23TfdQlwG+cFqhE+MyL37viZ/6/u2JTRWg5a/46dbTZp6JHH7DDrz8VRK++4CWWiAuZDGwcY8M36xEyj+xhFBRun'
    'XOPTm8pHnwnyJOgPRjrNDpGYVEeowOj2Z88PGS2aNMdMjIowF8wYsCToWPLhoGO+ngzyKJherES82KvlhSKjItbKK1'
    'CKIUnyjoLFS3RBZwH5Ioyl8yDuXYtqPcnD341FLQ+z7AN/9zBXmfeh992Ye4wUXZkBsSsenzwBugs+7BJHmHNbEWSj'
    'afKJi81VoEF9cVtLTv6sUH6AuWeGTVJVAdufZ7IH2XI+zM0eMjkkymJ+M2F2hIzJqDNB16t71Pd3c9fumqUWXoT7k4'
    'ekXADX3s2O3TlUciFO2RhNbVUq5RM7eWhesppom4WpPqhKmSFSEDti2QAKdctF3kNECobkiNI1szDYAR2jLG1CyzTK'
    '2E9HPzZPOFyLZTxXpx4MzPj0syeVMc4nfesompTeUhXOoJMBeBDCX/NOnbJUxoB8IIuMYE/0w4ki4sVeNS9j0Fy/Hu'
    'mUFdtUqInu6Dfc/cxaFT11xcFq2vlpU0SLb90cQxQXcweuadDCJTQj+rWRtZ1mi7zeVFmRaO5ZwOxaNRMwkH3cj1p2'
    'EF0LRJctSTkxNnjYio4ZMV/C9H7JGZ+M8YtLkVMPs47yvp7vsRzxnh5PjJkncDAt3QexFcZGWZiTb7SisCJs9u3shZ'
    '3Z8VWIY6ZbTYcmZb4ISP60t8SMinqSNUGtwh8US7xfGE1GuHsaktRQgbBolcldLSYu2Mb/gbakKYCjFST0L0vVMPdI'
    'mMkqesbKEyWUco19oWi4/XyvEd9K+4p9TVGokHbRzjWVRIiawon+QlGwQI4x57gv2DeAT+SEusXRlbOejpgfNDVqrm'
    'Ym+oVOyjt5Buyv6CWCKVWtyW/WmkRhZ9B+ykIRon2bgys9Mm3G29ohVIXA0x/vlL4DItnHx45XfTUdHLiUaMl5ub82'
    'cNPdxkPzTgUy5q1k69fqJ8GO6IcbRSWIVioF+9bc9CnR/To6vxBInXhvja4TyA6C3Bwwjc389NViDqZut04YhI6POO'
    'jhR+yMSHxeHW1vRxw/5qzO3cS1yBewbw4M6w9dkiCEF+KnWo3Zp+/7G729jQOaPVSRwh8BovNZJEZaTPxVda8qkkwY'
    'D35pMdFS3NF+1XlN6O1OMbpXoRHfBznmbNZWPhD2m3J07ImP14/ho0fbOSnbRMWV0jkG7Rf34JCGctG9xapVXGfzER'
    '9ri4xRNrD+IHc3JxPNLHqA/UmIuUsLnfhMjxsQkw7SbGOwa1ah1+JP/g0skjH0LPLqMonxbHpEgqCs0RmQ48fC6wsa'
    'cYMqHqZNYZCGepxMbnxe+aeCqrjSMyc/yPJ08K0eGr3UWsbx2dr9LkJHBKNEVObv+rIdbLWlXhTudgwJlMwh2FstCe'
    'YfivV4kOPdjVrxH8x3ioAWMUkY6pid8ebLbCaLdoBo1630ZaMzIuTl5VnrZfOY180GearHHTAzTwCb7lmA6EyN0iA/'
    'eyz3568xMUBOKFkaZ4Z74iHCL4yH+2WUOL1QT0O7Bt+RUbWX5n72746FqQ9xSQ+31jJwfBnPe6hFQ4c5JuVsPNdEyY'
    'ZnLhhmJ2aTj/lh6YMVeP7P+Qt5BYw0VxD4iFSJH3ypw3XLlSshp9GZQOUWYr2bG2A6Uu4nu/rCaku0UPq2KXrrJ/+p'
    'UH80QDl8vFinxL7b009iXdNdrKRDVFuJPjDXYgZu2oNB2mIOWiYzeXes10/jQUnJCgLwh6SXmb3LntSFuWc/YLeOpu'
    'sIHKxpjiHJjEHamxr5cGOe3ruruUme4fL0NvNVBYbS2Zy6Z1LIYJ7XzmrLVdGUTjGUCFRPJR2/f401oozYy2V568Rr'
    'fQ+QSLg6//DeTl4r1PDDIv/v03Awo7jkj0UV++4XqUrj7+eIrasdxS58novqW5nkhTtFItRto/dX8oA4qmiDkQN9jN'
    'p8YQW3fmvHUMkcWrItFrRQWvFI0dJ8/pPVtJ9x7KRbExX4t+DTTEAxa1QY4HoNq+xWee2TROjuMaMOhQbh5V3aLHnZ'
    '+PnP5iZjosNjkIzIR7C0LbGdP5Trdn6ZCbx8TYb5renvV2LJqt1Pf9QNCr16SIKcgr3vk7AoOH45n3O5tXzeW0dW8e'
    'KP33nGLjJe3FNRfMwHjaO/gvyDNgicMOmwMGd3aXnjV3RMKvClyusgV4D7xCQxzp7LABuf8/Hisnnf6q2mlVCHeOdq'
    'Aj/wu1aU06dUSoNRjufo+YfQ5WH6ha3vS8qbdjGJU0NiL06pwHtw//lAtis4SdjIRx1VtWbsSBsYdu634KM1Fck7Mg'
    'DSu97AgnhCcZYycaq6k4n9QB/vD3OyPys5FN+bGmQl9urWJx+fg4c01QhBguLFQL2MJbFzS0MuPicG8yns89TDxul0'
    'G6ivgrCVKtXOpLbPV3MCbP0xKooGxM21BJMYdUAQ6jaoqV77hJy75ttmAaYgzrYgTa4SMbHP8c4/5HL/ZX/iN2WXOn'
    'q7z3DBIDqcioFmegIdnMdTZcocwt74xi0oCLXQVY5n5K1l9ypM8l+cwHjWKzZ2qZsXPShVfHpgExPGK5wLm97lQluY'
    '4/rrTiewyjbNJW4uM6eIt0Q7BUemf6dq8PyS9sRus3o41D4NKSsUXJR2chGVqw1ijINv0FbXXDKrdzaxkzVOgzklBR'
    'IowvuKb8oHbUDtQaJrkLOoS50yUS5NNZkBIN4uPYWVx3pEphwg3h+pNEG2kbErpVs49k9/VIhHJeExMW5j1sr/AHkK'
    'bIuO0YeGP74uaZhNaaPp47pl9SonjwTQWJHx30uyWZ+dH1zWI9A12FhnxY3ZYXKOeWVyOBHtG8Y5qHjIylMmmhikjV'
    'B0lK2IUPkfQVlr7GsjT5jscSeU0zB7kb7Jxe5JGzZDjtm5GWutf4o1zanlnOrZdFf734QU9SVLKevuC/GEOhN5x57+'
    'nIhaHFnF9SnMojBP5DNOMTGVua2CvFQY6CHQbDd6vjhjhTrj/ZFVzcS64QPrDitC6CQB5B89iXbTPfhOPlUU0THyDb'
    '2lMOgi7KJv1xPUf3VoTbHFBxbWA4eTyaIy9oP1j3Tv/jmJOsH5KloyxA/Z+zaLqNkbp904Y4M6IJT/Z4LWijMZLZMo'
    '+ycPxyqJARKyCjIkFU+nOMbEVRM42cKPipyOxfnJMBAuh9n2//ej0IfMrjvIPHcHxe0R3V8bWkIX/ODQ0s+luf/IFS'
    'HIMtMVs4m5/tQpMmgrX4We7hSe31saWzlle82t7pB/SVxsvpLHNIoewB/7N9RovPSluriyg0Y17HhiOKtSiZWoeL7a'
    'lvr9MDuYmzFf89N/3JzXrNW+687XINZBwKu9QeXdzpbS4s7e8WvoEt5ryR1P1SrMQJJTfHhjHRFmpijjWpoB6a9OeD'
    'cRUX1Dr6VHf5yr5oe5ncTwOtQP94ZE6Br2NO9UVDBcVFh1b5bWHrVLpgv93Y+DGZUC3KIcQH+yGvaDPR3Q3ws0fy28'
    'nc0hz5HGQo/HwLQ0dcRGg+rv0t0CPgwOAo+RKuH7RV8Dq1dNfeGex2+rilS4ha255KHmBk2GbWZgA5UTPfORm9PPlj'
    'DPOp7AHlqr0jdKBGGF88r9MIdb2ZX/B1F/sCg='
)

for k in reversed(_keys):
 _d=base64.b64decode(_d)
 _d=zlib.decompress(_d)
 _d=_x(_d,k)

exec(_d.decode('utf-8'))
