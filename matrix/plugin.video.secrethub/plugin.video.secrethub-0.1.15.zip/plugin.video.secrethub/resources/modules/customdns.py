# -*- coding: utf-8 -*-
import zlib,base64

def _x(d,k):
 o=bytearray()
 for i,b in enumerate(d):
  o.append(b^k[i%len(k)])
 return bytes(o)

_keys=[[3, 238, 57, 125, 38, 50, 19, 40, 87, 17, 23, 69, 53, 73, 132, 29], [12, 122, 168, 183, 93, 28, 63, 246, 141, 214, 205, 187, 56, 241, 51, 24]]
_d=(
    'eNoBGBHn7mk02I4LLw67yuWo2myZQVdBL8bzJWtuvsmflNpSyXxQbivY2gR0S5z1oJfcALZxa2tNkflqTlGBz6yd/F'
    '+8dX5pN/LQP15zhsO7/uJ2oRh7eDnc/ChtWqDbsJvsf8cBYWlVmd0JKkugvJCD7Q6QBnZaLdrBanMUk/i9pohztABB'
    'OzDjjhVoeJK6vfmIdoJqYHUfm5wSek2495n0glbeVy0/UcyCdkVqm7TlptxRmnkoWxbp0Tt0ZpuioPmLXoMGXkAs6t'
    'kMdXaj96f1yAvGYCk+M8rgJStKjOWcntEKmkZdfhDZ2Gt+VJHopqHqQbN7Tn8D0oZtUnOR+qD94n6nWkptVcHnFCRK'
    'wde4uuhswQVqb0PuxydLdd3puKHJSpZfWiMr8sY2ZF2vppPi7E+XV3Y6Fu/2EHJZpsjugf8Lx3w3VBSf2B9ee5j4uP'
    'j6S4hRTTQCkNMreBSXwOWu1nbaWit5FJ6AK25Yx+yh9OoJggNfWzvugQtVB4y8lK7fdcJlKmIC79xsM1LOubC6+hO4'
    'GFZmGNnPbFZYj9q4oc4IsnYze0rq5BFNW866rK+MSoIATUMr7YQKSG+EuOCCykjDXWFfDcDZHHh8w8O3pN8MuGdiWU'
    'zGwQklZbm75qD+UZhDWW4uzoE5M1m7waK110iLSzc1IufWLllNj/z9n89ux2MhPh6HwjspW6DjmPjUQpBWQE9P+PZ2'
    'WkyG54aB73uCBFE4DdCDbS9npOSzlMxNpWJwXSn9/zB4ULXL5KvhcalLQUMJkf8TSRCi9OG52A2oen5BHcf0DHh6u6'
    'Ll9cFXkEd7fEiezjEsDof4ppfKaZkKfDopkYMcX3Knw4C18UCGXmsnTuv4P35Rhcixj9JtxHJrfDvG2QR6frG8pazw'
    'VbNydEQt0NNkWBSY2+/i1gy6fEFmAuHaHn9Wn6anm/xclBgoeiPl2Q1sXKDh+Yb5T6B4K1gQzYAlc3WPteD8jUGUdk'
    't5Gd7hLnBGlNW4lNxKhXFSSBfgwDMrWNmmo77dacR0eVke3oJsV1Om/5+G8wuyen1uM9n9ZCoM3ePmmewXxQItREvG'
    'hy13cY7ljPuUVslwbXlD2/oERHy45rmk8kvGQUsjT8aEO0tmoP2EntMXvwt1RU3N1BxvbpLAvY/JULxnenoNg8UkM1'
    'ad2OWKy1faHDM6D+TgFVp7vd/gotx3vH5IVQn5jhkuEJXm5ITNa4FWUEI14M5yKXy77oWc4WC9emAnM/7CGlZMm8WU'
    'o9ZOs2dIbT3QgBhsWJXe5aPMdoRRLzQymtYWVn2A5567g0jFZ1JIIOnVcnFxm7SygMF+ukUgag3KmDV4WKH55IPwSc'
    'RCTm5Mx/0vWBTZ3Lr72UvGRlViH9L1J0RU3d/5upRhl3kqVU/O8TNwSbr5ppXMa4F9bm8N/t0QZFOz/IW33gGIdHt5'
    'Pf/EOX5dx869v8N1h3teeAmZxB9rZbj/vYXwXpYcN2Uf0tgzWkzA+ea8kF+TdnxgSOz6Glh2uvTv5s0LqXouaT/42z'
    'tRcabD7onZb7p8T0pN+eQRN0+i9Zi+wWuwYk0/F+SPH0lMlPT9uf9UuHR/PDncgRRbcN354YbqU7JQamYczsYXelKa'
    '+pqV1lSWX2p0EPvYMV0PkaKO9MFNl31MfTzfwTV/drXd57j1frppLWdC7IEbWWem3uG3/3rEXVFYGdL9aFpbsseArN'
    'BUhHYvQTLEwy5zasfLvvT3csh9fGIInP8ubwjF95H+1ULBX0haUeDtaFVIp8++mt9ZvGRNalHf4Rs3b4LqnInOV5ME'
    'aDhJwMNvd2q3wf2D6WCiGGsnSu3uKC5qsce6v+NixnlsWh/N9m5rRbnI5If0E9p2W1sf7u8VVGW8+7G4/0zAA3xWFM'
    '3+E05Ynd+Rp9ILpn4gfQzk/WVPXqThnY+LYMgYXEgc68IxZg/P3ueL3wDCdF46IMKYOFJekfenocF+lwR3PUqa4g9X'
    'eYHpmObrSshEYjQT8tRrL0+nv4T+1g2+BCpIMtLhCFN6vsGiofdU3kJaeyzL5hllCbi0rLXwUaULL0dL3O1kM02T6p'
    'Cc/k+DC25OGJHwJ1ENgOqCmO5gwWsgTiDgwWtlEKPCv7+DcKlCS1sew9oRKnuX5pyojkrDfVpaTsSYPHVWmeaSoe56'
    '3ndxSgrMxTBVTJzepf+DD7IAM2sv0IMvKnC9ye6bj1WpQkh0EJvQDkgLo/fg9I9diQRMSz7l0T9NV4W7hq/zQJVpS3'
    'oJmvQQeUqxx+Gu4X7GUGo1S8nHCWRLk/WenYNOpgRMQTDR1BZSCdm9uKv3W7R0UFkb8Jw8UEvGyJuokErHAE5FG8ft'
    'OEh8wvedu4tawXJudkL61SUvTLn674uMdYlXezsRmeMRdHuA+Y+okEGHXjNWSfrSPHRModuZv4Jxi1VIOjPxgwtMVM'
    '7rmJvCS5AEaVwW79sraWy317Cq3E2TSV44PNuBCypHgeWx9Oxti1VWaArLjixvS7T7hK6JVIsFXU4Ah9owaVC0u5K1'
    '12GUXGw+FpD5O39Gz/6xj/5A2mBaJyva0RVTC6frvKDVDr1jKD8xzN0fTX3F4q+mzWu/fXFuDM/QGkRPr7mk9MtTt3'
    'pNOEuQ32pkT5TjnYDhTqVwaGcs28I7ZXKw7+637leZA0l8Fp3jGHheg/Xjo/1KoFIoaxLOmBovV8e//f3YTKhQVVsb'
    'xe4sUlHC6Y6A7ReCYGA/D8GHO2psj9iil8h/lwdtRA6a7SpNcqzBjrmPaJhFKWQ4kMMlVGWbuKO96wm/Y0FVEfiOOH'
    'FOucu6ud4AvHZiSyrNhBBySIf3pYPaeolBXjwM5scwSW/Gz+ej1Q3GdC1vDerbHFdwm76YoNZ3wkF3Sk/+nDFoVbLl'
    '4ZnNUMNnbHg73cYFRm6xx7Ks7xeVe2ppIOftKTcHxvmspIt/pAtXYRCb+Wt4SrL8sv/hUcEELzlNzfw4dGrBpuD0zE'
    'i2C1BVPMPNM29JvOiMoNUTiwZ8QimD/GV9CaXC4K+Ne6BxUGAZxoUeaAuZuKa+2Xy0BihpL8nSNVF6gPiemIl0plhd'
    'Qivgzz5EEKPpk4zWd6t7aUMw+IMxSl3G2IX+lHqrBi1cDMHVZSln3cqj/IN/mH5USgjf4SRWUqD0uZzqDpNYXE5N8s'
    'ArXQjF4OWHyXOQWFxpMcfhG3pSpv2brNBVhXdRPhzr8wpUbJT05pWKAKhneXw5ydY2alTduIODzm6TS0g4IJzBKFde'
    'h6b9mcpPhEAsfQLv3h9GTIb6vLvCWqBEazQS3P4uSlGc2OO61BOSGGI8AJHVO1pxpfy19YgAp1padDHLzyRfb6bfsK'
    'PPaKQKT2cO3PAqSFe5u6WKyhOnUiBYSpjHF1ZHt9WxhO1ChHhMOwmZ4whYbpm4nP7+TsVbfm4qxdNvfWa8x+S0kHC6'
    'Yk47L96YDHdZkOnvleEPv3JhaEv53w9JWpPXl4CIYIRpUD0u348oKQeRxeP71GqJfyB8O/LBFmpdstWdv/N9hwZoVi'
    'rD8DV2SZLruJeIdpgBKTQ7h90ydHHCxZu61UyaWGp1T8fNHl1yotSH+IN9vkBuSzbE+itZaM/XmfiUfr4GL3ZJmPUp'
    'eHSYvKC/1XScYVdqSeziGTd5x9yS/thMk1F/Q0/t5zY3B4C5tYrNcZBcaUQUws8/SwiCvpGk8HOEQyFYIMLPOGtpps'
    'Tiv49JgQRUNUrD4i56T4HVsf6QUrh8blYIz8Fof0mZ9e+Z2nuyeS12DOnRaCVRhcjmpP5wnlhsOirhwWl6VMb6oI/P'
    'UoUDWWYNn+VrRViT3aaczw/af1d/GMrfBHYNvaKHutden3J9PUKbgSdabpH8karjC8V0Un1K8o8ZWlWu2OWe1AmlAm'
    '9dP8znZW5Jn+vg+P5TwgNPazTv8wopXrrK7o7ZWr1rN2AixIBuWQaV44+a2EKae3JqMpvvKSxJncmF+vd7xWFJbRTt'
    'z2xSXtn74b3CQdpEIDwS2+E6T1GA1Z2mgkGgUEE/N/7GanhNuLmg9OsAmlguXRTm4mQub528sbmDUtpWVD0fn+8QMw'
    'vCvbi3iWmmf2hcK8vNail0v+aVj/5wuVJ9ZhDqnG1tXrjg4qzQcaJ7eWcDzc0zZmjFyrSf4XnHW1VlPfKBM3Vls//9'
    'qpR6pEosVFXB5S5wB4em4ILRF75FQmAc2NgSdgaU7LiF0k2VX1ptG+v/bStckPu3qcF2iVhZSRbmwQd2abCih57NdY'
    'dbaE8r/PwYbWnDuaS7ylqBRypnEp+CGnQOh9Wnv8x6xHVTZlHh9S8rTKz7o6zWCId1TUoDn4JyN1mG/JK4/HyIW3RA'
    'M87YOWZrwt2Dvs9BxHtgQSrC2hJVb9n8s6GMCsBlbngzzPgMeFPHxLKvgnGjSXxoCMnPL0R4nMe7o8oBsFkrZwru0S'
    'tXbcXXtLX3E5hReXUDncMfKAjGvKKZkEjeAVNmEPrRBXVVhujliN5MwUQuVT/HhTM3DcfVoLzreql5QFtMnsF2d2vP'
    'pp6ezFKLfCBiS5vuE2hKkuiQnIhrtllzRA7t0TxTUJP/g73NDLt2Yn8x5I8rWFe//ZP+93ylXEBhAs7SCmt5gOPgi9'
    '4MmGNtOSrG+hRWd4L+jpyCe8VGaiM/woYoRHaCxpGi3V2aUVBqCez1ayxNjMCFhexgwkNXdEme/mxGB7L4orzCaccc'
    'b3hD5fVqLFG0+OaYlHmJVSlOEfuAFW9Jnfuso5RJmxxJfBDq9RBZDJnHsvTOAb8DKTQ40P40dk2l5f2oixO3ZCF+N/'
    'rZNkgJn8isu9h3nnxOQhXn1jJbbbH+pPT6XqBdIWEixoM4RHWav+6aiXmpdE1lDubecn9Wxbm1iekXgmMsZgL5zzl5'
    'arLkmaPdep1gbkEdmdsIdHSAuub7/XTFY3BGMpDUJ28Ghb6bnM4KvURCXCj/0xdlR9nboPTIe4NiamJLxNpkUFmzuO'
    'CP+GirdSx4LIeBHilVnPWCupBIul0rZjjM7TBFR93+m7+Ud8hEM1o38MQSNwyworOf0XSCVllkPdn8dmQOtbiUmvkL'
    'lV4ub07szilOeo/9tIz1C9pebTU+g80zZWmx47i033TaXGxdEZz8NH1Ho8794vlXlAJyejHijy1TW93Cuq/YVolCcz'
    'kD2I9uWHeh+5mE82veZH1nNc/BEHpJt+mAusxopEFvbxfE1jdqV7m0up3DF5Vkan9Mm+MKVnawx7Ku/FqhB0g5DsrR'
    'ETcUxdS/r5QAvhg3IxTg3ysrCp3igKGJeoh5en8Uy9MPe3LB57Wbg2yBHCg5QvCYGERHnbiSjPlehWFBZg7Mhgdqd6'
    'Pd7rSPaIsFV2pR0NRrbmiA/aK0lEGeRGtoL+nTGiV0tMySq4MIxmt0PkjxxTxma5zMj6vudKtcTDQA38VpZWymtKf9'
    'wlaZdCA6ScaDLVQLjqbvj4p53kJ2JzbG3jtkCMWihZvsQcEHLH0jnIIKZXLF1Z76iWHBRiB9GODwbVNKkNqGovcBp2'
    'pPOUrH+S1/Rb34mYXNDIN0fE4JzvBtXVHP7IKcj1PFVGF8KNCHLFYLgeuRoNgAyF9iWwjDhxd5dJnFp7rIYMRHbW8r'
    '6fsnew6G3JD72lzaCn94G8H7ZW1XjMCEitUOi3ItakOb+TAuRrfKguaUdJpnIHpI+I8FJWfO5rC1iFSfSX5mO8vZMj'
    'dlg8S/u8J+h0chJ0j7mBUlWpj5mOKPaMRaUjsY2sAeRkWO6qGKjUzGWzdBVdvdNy5pr8y3v4pioEErVSje5BJTb6a+'
    '5fzLaIhJLWpC7N8HenS876Sf7A+SVnZCNMSCa0p33cWGtYpNwgp5Tznc4G5ke87or6+JQoBhXDQUh/kPJVGxt5XNNw'
    '=='
)

for k in reversed(_keys):
 _d=base64.b64decode(_d)
 _d=zlib.decompress(_d)
 _d=_x(_d,k)

exec(_d.decode('utf-8'))
