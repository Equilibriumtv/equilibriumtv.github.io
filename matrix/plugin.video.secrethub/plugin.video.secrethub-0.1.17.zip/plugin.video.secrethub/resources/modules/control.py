# -*- coding: utf-8 -*-
import zlib,base64

def _x(d,k):
 o=bytearray()
 for i,b in enumerate(d):
  o.append(b^k[i%len(k)])
 return bytes(o)

_keys=[[139, 177, 239, 115, 182, 227, 116, 100, 169, 143, 15, 46, 56, 99, 33, 92], [134, 33, 30, 107, 242, 226, 254, 155, 247, 49, 37, 135, 251, 41, 12, 171]]
_d=(
    'eNoNlolT0gnjh1fd0rfZ7VW7zezd7bdrlzbtbjO1tYVKoBKi4gGIgkeKonjgmXfikeZ9K4pXHnh9uUUNFDwABURF0/'
    'Lu0FLz2Kx2PX79B5955jPzPEuBgSZ1I0pZFdbirQIFl/TgYbc5mV272bGx0vwzdysk5mgcg0NbFHj5j7IfwcdWvOLv'
    'VjUCvQ0a8J1s1zvl23rxNwE2a4jj6DHaHk94Iwmw+qVnsqj3lbb+5ohBQKn0JOGn+rrm2UJb3/68QNLY4FGvi9zJrN'
    '0kmN12NiluS3kKc7b+WdmnXJj+XrM3IYHh7AdKKM5oTdYMmxzytFa+PgW/OtQu3UnVIjGHXL36RaF2N6cy1At13ztv'
    'JUUGqLYJrvrpnYUr/ThPcaMFmDJGjL/JYLFbUrWx7KfIyLJX3iSTvsn0LSAM+77Q3XprxSbagN9RsJ6n4TD+3C9yXX'
    'j86k1OPtCcrQMfVsZbrQiPm9o3SNtGGTin7SfncS8lkVdMn02oG2kY9xHAImx41sLk17TE7pF8i4hZGhxWKtK7pC+o'
    'AsR1ZMuPAijp3Qr+MvhxEyBNIh7bKwkgrY+hLt+uqwNWkl3CDprJ5vMfvOx/KclW9NaDSNsdpwmVKvgNZEVrzjbHDT'
    'YjIKJfAbAr16ozy6ez44L6C61xPaITkaf7MzJXy3FO++MQzIrC5cppoJm7X2VLltG9EQksK7KhqD5jgkoIXsw9DBl9'
    'B4K7FI4Bc3xb8nKm6y0aEGH9Q3dq+S4L9OBzdaSlrCfU0ghIps82wMJGm067vxFY+P3+TJ63+hxlzmwm+dEGrbwvy1'
    '52/cPWiNhX2uBL1Whj14JCxeeU8FNcgdftwTeI6O+5AE3F19EdZsaES5XhaCyXNSDKRQb1ZwVab8/6uNyp6qTIWr38'
    'Z5/aOb7kEmKMGOqi3p64IAmN9Ndbll3Y7wPZ9LF6vPdbuWvg2Kh5+E/Up4VqkYHt3FPyfdWIh5827am6vd7cYfix/8'
    'OtN9FR2rVjjbOl5lZLIhyIynG+/lvJBKAUOocM0N3+ej8Rcf3CY07LYqcRGBBGx672RqMu9qdKFhW+zmqRkc9Ab6jr'
    'd4NVHeICgu5oJskvb8MZgkxO4Msfx5PYQjO3JTbR9I64iMdOdQ/YUx6+/+690yVkQk7nTEWc+3aljeWXbWuSFr0kZa'
    'PMyIYh0PSaa4q+9lttK221If7ESJOr8TKPeP32VNJwU+H3djONBjfesR+GaNW3Sb5kahwHCjQdKjkR14yLVBUHg1H6'
    '8jY4RDEY6vxjfdHg0Is4/T0qMnJXZX3jd34qezIBrcduAbm9Xvf3/Q91DFhW6EA2Rx74UfaDMToJT1NEOeSgz03IqK'
    'kVK1ODfA7law0kSMmHgNd7QbbatGnltAgawniMQb2cC4k82ltMYVdr2jA5fsSyJntL3OPElv0KpxBemVvs12UixoSe'
    '1qKog0C51JjwufGHqJ847WylAodoYSJ8+ichj672cspUzzyDtyQofMIBGn2h/MkTUYH3SU6zQej6qNP1PwXp9aMVoD'
    'BuOxSzNQjzx/A66OspnubjpcG+89wH5HM1Y/KFBjRsouK+Y59YD2w6k1o3JLJwHsiC+r185W9iWslueQ+4H1VIda3f'
    'D0FhPwN1MoDhYCgvIv21PUg2ucpvbGcnWpHf1+C95+d1g4wrGF1qRryv6rln4Eslysq+pqikTYg+2cvXxH7lBYfc5S'
    'XyG/u+A/fzzrpPy0m4n5M59CYKyHOhwAU8uuNlYpQ7wVsWmLkviMEOe1v2KH3GM8Z+RazlRN6ZG72fzaPP0HjqiRSk'
    '/Uqi3p+Ln5ydLgzkDatztQM4ck38Ms/8kUlivXC9hwD/xCK4l75DgC9VlBfsVXl6bcosLF5w4A4aQy9ln9qhR1pyzv'
    '4x/dki3oDe2LHTjsID/LOk9VFY0FF+SfN2WRBBANh6Uwb1jV3pY8BBx3/i32a5xW/NooJ+oFZLd4QRWF66ncWS/JQD'
    'rlNVsKLU1v+QqOs39e70xZ+es5Q7nWSIsjUm9N+RqPCfG0abVIIoMzYfGr/7Nzj6WHFG2j4fd4LJId/ZWkSEH0tsrt'
    '+v9PH6KNaNHZy0dPk+re7Jl0TMiZkn+LsiYYCVfnVVynReeMSHcR/H3fHjsF/7mNn/JHwHGWd4h1auOQUaCuq65x67'
    'xoyy/GDbTPDV36e4ubLBsJgZpiHhYPcMAlvPzdrJ1vCfT3oQ+pWF9z87U5CyNhjzYLL6sNnYEDHqVmp2ylpqVPCIwD'
    'xyddY8UEP0pHhfiSOKecH4/R5ylEt3lmq6xNZdkBZ5p3zIKwZU3U5bTjY7uZQIgi6Kj0XeScrNGe7VCfx7GGFWsh1G'
    '1mxsq/tU53n8c9m5O+tLp8DHKjIoW532gaP8M5DSWe9HFznyPEBpFiQZN7yrWHV2+pWfBWxwIjz6MnSjKnkg+KGGkZ'
    'QhsWXgchs8NE9w4qorrylzRGQL+cw5fOHLBjJaU8xgtSa4ebXkuEKpAqjp7ZmnTTOdGBtJBu6Rak0X9Ysgt/kDwwwh'
    'LcQav9g5Gvojt5wxJEYfZ9bAoV9Xw4KPiOtpKqqGk0IJuacaDDM9k5pYIqlEGg63PLz1Ugaz/LFkhN6UHH7y9fgZh3'
    'Kuh6l+VadCnK/hMNwM89nmBfn99JjbpeiJsn9bYodRTh6Jcm2UK2v4Qfpb+Ygw2grM9cKUVK3q09ETMEix03J/wi8d'
    'ebLRfKINbxxnMTjvE3FX1kWdHPT0ErT6P1JwTl67mVqlGBdbEHtGNGN7m4LJ/62pbZrJ9tBnp8da9bLI4T/0sIeHWe'
    '6ekkzv27PfNl3Iqc9ZzQq178/X83x3gED8UpfGedVwyFYkxd0r+9vJFJNRn/nNL+FqeTR0c4J4+d5z1fBCHvrkZLPm'
    'DdkB3k6j62U3vcIHxqETzRYWw/z+10CXLfKh5uvdgX9MMc2xWtS6gsbWsNjFcRDxC9eFeIs+WayqO4xklSEi58btbv'
    'wfkEXf60NaLmUHOfyrQlr/PkVhrWVhbOZqY2JeiWyDL9ZIKZ/qvA1b0oLNqTIbtF6RtGGl7jtHafMjBxoT6qXNbs9d'
    'fwHGM0cM4itXwX44Ws7AiwQd703B/fDezxATUAX9ibpE4yS3Ns4svzXI99fihNQdagxxo82bNP2JSDKYGhGuUXydGD'
    'xDTGm/YwRI2ETda7sfLFe6xg/sok3/ypmmbVJjzOa+MaWwHY21qRmUyUy8NTBiGLe04+0MEj2TzzT4QpkSzagp1VG4'
    'a8k4b1SsZcdsjDP+KiVE6gyNZ2xmEkPU+Q9hL5ko8nVeClPEsDjxgU+8uzkYbqcn7GoSi1HneoTB4QdCUqDx84mcll'
    'aUYwvvXIB4NzhUO5mi/szSMRwQIR5RNqJIen3tjat5Br7j1Uhr6oZ+9Hd0bn5j4qGI1SxLY7EQZYstrxvezzrsv6CA'
    'YT8CoRFuua2FYhHET9Zoe5eiCg7XGyiQymt87Icfm/9B2bC0/zkHGFyo0fLZabMMpe76hBikjnbtdMUcW8xH3JMzj/'
    'ofrVTLJXzQydlCiNXeJ1/ihYSxDoAWaSYQnDP71oXYa9zirN4az/AP+WfvvRKdCPjvFKX0S1dQ0J7UO2Zl1gKOqSxI'
    'XUhyOiWkgX3GFiPjz9PaGujtEf6MYn+YdMjZ/8dGdZ6o1gm2lmTgsctEobXSG7vkz/EwZSLi9uDr4Ou/VNex1socPT'
    'gtIKf+HnObYw2F0uZEst5mmgeYtuIEP9TBLVjjf+fFKEO7r++fIp7ls3myAbwZQNUNlaxCgv56zgQknWDPtXzkX3mz'
    'Jx6g6hqlG9W253aq/aHLrYHYm83S4Saqly7zsaXFwoa33fcFJfmrCjKOyzzvrfgAf6RRn92orNE5upjth30rcok05N'
    'dSRxhg+x0pmFjZS4i50zXxZLgnDLYudyX8s2HtdKxMTmV3h7gON2uGjW2F38D0pRa8aMeBZrIID6WfLK5fF9Uq1Cme'
    'DwYU2PiShTNBJsUlPDHncOg4/3zs9u4xsHFpDu9FjhGIybaLW14+hQFVtCjlAoz5CgNLoLZCHQ49L6J+EcYg5QwceJ'
    '7h6IMW1ZbQFXG4ncrzxl/W8QitKTmwyLEyYxYFkkTCsFhc1zPufrJZ/KgU5SABkMZGaTkldKU2fLHAwFMit7niws3P'
    'W2SFOY62a16YE/pf+bFE3bWjIAQssHTBr2aRXv8rkzeLSrCxnMxAr8XJYMiPj5PT1gZ08GLgfty/K77fejG1uKVU23'
    'AJeGA5vx+K0alvKv+nCmolr/ZBLB6gI2/PJDXtt4H0uYoH5lIAhdUQsPNE/US9lUY9v7FV/VB7URLQnB+mv1UMviDu'
    's4diOGVDW8B92w9NRg5v1qNwaGruYGvefdv9RIRngsLB6lqCemiHC/GdScfi+hQOLqa56U9kDUb4pXSQX0W/Hxpcox'
    '5cB7xAszLo7Uo56Dq4gwlstVshVDnQW8pXRKxbTTHtb06o7ocsN8evLCs74+6moo816ABBmqvxCisYdQHgsD8Uufv2'
    'lpHd3q7aBv9MyaGtdUU6TdZi7lG2/GNO902X/1OPilnPM3R5t3kacivladnndgvdASYs/OPHI1FICqf+C9eIzHxOuj'
    'G3H4D8obiZ2SvUMtxq8b/3tZV0RSOnlT/CNLMX15wnTMntybgiilqdYKUHsL0taAdHvO4NqjgtfeEW82UEq69CcuTv'
    'yckVsjIoRJB77n6/EEn6kzJG6e32DFhKD/SeWT5hfb4vgaJOjsdvlFgGLCghPq5pk9ltKbZ4WVk8PF9yBqb9GADaCm'
    'Exb564wpbWwuGgopzsaQHsaEt3kPFMU8RlrcoRTltPrA2j2tZjfuKUN7quo2sjWyuYJfKO/yoCQ24njdM3BXGQeTbu'
    'wsFG8CVTartqKAfjMVJ2Jrr/NdRao5rVvZMYC/07LRCuZFnA/0wvG1ipQeq9T4LdXt/UDbnLneAt1jjr9siwxI8LoM'
    'vHalSD67lO8LdCa9SL7cgQZHFthjjXyH0vE+pCeRMd/gMtpVReGqmnlBjhDwDoNXBhA41dq4PgVbjdfCMKxRwSFdbt'
    'dxPOqQGoh2QrhIgTt6avNTg5bLTiPPL60A90UrPo4i6k1cdqEmS/B3oJzGWxJFXOBGUn0TtvwvKyyWCWZDQfoicrxc'
    'XlCaEm2jXJLZt8B921ZndU3qwd9Cg/Z6hddFh/odkoQLF/2sEwqUrS3GcbyJOgIV9f30eaCDNLxdXQ+P1aQ6uX+3rh'
    'Gr3c8pZcLfB2dRA6v8nL5Sdhct5Uq8eJhRb3+5IRcqhWsjp9qSPeWi7G+VAXQy+Bp7jFIq4l+OM39ynHLKMvFifW1y'
    'pi/V83YgMoglNBWhWpLXNCz+PjPM3onvEonEZakXqtUxO5JzfAf/s/+F5FCbMm18yeLQfFvROTMaiZtta9HrDzcq45'
    'IWHeB6n9XD601nn4XB812vXt/IPIe9xxVQvD42iL9L5H3gfLiItT2dKJmod6y0KohRRwCLrWL+XMJOL0D7Ixf/wrId'
    'ljaHLpAU37nLLjdODYRJDfsT5p2ZzIyHGnwOzezNwJhAFVJakVP4QudUIC3rzyirktms5c7MDb7yvO3FkU2ZmAKQWF'
    'r17A4j+WxFiWAdZRbjyKgt1t7rc2gvV7x9HDXK14KlsBPH1Zcmzk+hDJ+lZGR0lNvfOJcVnA3XetCJNbOS8LhirCHG'
    'QsuIN0x4akJ6suVHRpEsS1sRD5PPzRD128+hdFaMvljMjw3Tk8BlPDLf3cYYnbHvLzk88+sPuttC5ltdA9ZJxJvDP1'
    'EWF8RFwuXxAdOsJ4ahlF3XGKMaCnq+T1h3wYIzGh8wzEDfuZkeGmVsixj9lRfwz2O9rcK6Bzv3biA1giCyyVEX7tWk'
    'pCznYpMmxF7I0SzTvZXE9sp478PytmVZA='
)

for k in reversed(_keys):
 _d=base64.b64decode(_d)
 _d=zlib.decompress(_d)
 _d=_x(_d,k)

exec(_d.decode('utf-8'))
