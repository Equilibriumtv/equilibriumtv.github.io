# -*- coding: utf-8 -*-
import zlib,base64

def _x(d,k):
 o=bytearray()
 for i,b in enumerate(d):
  o.append(b^k[i%len(k)])
 return bytes(o)

_keys=[[55, 94, 7, 225, 114, 215, 92, 71, 184, 229, 169, 162, 47, 215, 54, 79], [101, 64, 74, 0, 97, 145, 76, 243, 107, 185, 107, 39, 39, 156, 202, 25], [123, 97, 27, 252, 19, 46, 7, 36, 22, 200, 84, 131, 230, 81, 163, 148]]
_d=(
    'eNoVVotb0ofC1lTUsAVpgKnl8MstWw5x3vCGIPc7cVPi+vNWohJgdMU2556JpFs2DckWiqWZonbCnXpOamFqYeoync'
    'etlZuWLi3t6NKd9n19f8D7PO/zPu9t56e624eLNOpPy7e7WpLGr/AQou/Sd+gK0ptyX1b5zgzEcyNuigxSOmBEbFwN'
    'XF9nCDn1QlIqVWTxvNF2sLfNPeZkM8mdDSVUQBdLFaPvyGh6mUihy8VWhQ+fka9MR8G0zXyxSnHCFr7RiVl9xxBqK7'
    'klUpKkAzJxJWtlahsq/xuKxEBn9oTNt4CcSwG+qPPp4jg6663ntW82We4i9hTVZsooEHkF5kZ7+IMJxgclTgI+FZpR'
    'uavZkffgTygIeY5ELaQVN+zcsHnPPwQnfHbzgDhFja3H3PsueeZNfBDQeYCmCy5ZP9Fs85hxkfkUYyYxTZreAG++8u'
    'HsCg/NbSGQlXRJ1yfdrckbdwPQZBPXnUnWfx8+VgWcvRsfWHSbR1Phi+yI323K+cv0D5AVbAqOQLCe6LJmz81QgpDV'
    'Gvgn29QXslxW2GK/H5fezxGhcWxjzLIpvsYVhY5oSzfEKQAzfPRK4PzfHt5F9dKTTKW43O356ZwHK3gQxSKQxCgzTe'
    '6vWpWDTrJPYQVeLt/GqipZ+SbJ+TQeGVFDzMYVHrZ4DzXAB+7QhSU1RFKWP90U/PiL4NEV/OYMo5oRk0ew/I+jbe/y'
    'rx5BKIsMpqKpGz1na5TV9xJC+YMSLy7lRLnb8G3Q9MxmuPaRNEdAYl1IcV5CrPxMDpS2CGiaYok5tOt08qMBPJjewi'
    'PHQViNuX/VwC2/7kICZYTsLHZRT8KjpqTZ9/pFOEQZUm6aPXzo2oe969vAgInoxcMyG7asOnxX+1kIQxlXEccm2NDd'
    '5d7j/egg4KYInpdTaEXPt6X2/oKPUH+NTRfsJ1kgzXafuUdUEGCk0A7hJJVbXpdiXL/h0KJ6ISMvTX8avfFd6sYkAq'
    'SqFImJjGM9/n1WYP7lZv+if8mwVDy+AvK43WfhHTQu/3yapFBFKA8Zb0wcvBsQeuimzBB9im0EXOeUK0voQPWXHCpj'
    'a5EV8rQT9uDfVF5E13s8jmD0fPBF0Mqa325ttVChUWltWVMtoMGfPvAxuIjuqUTCGeULU+rSnVSfsEqZTKA4as692e'
    'lbd4cRwCzjH0zl6S/49TUHbzynxulr1LJPtmXWBb5q3T4y7RHLGxbDdWp9HeLG0Mc1AzvRmYM8hQqmaIi8dRuom3Hn'
    '6zvxJ4n5IjNyow3VO0OHqW9oWAYW1gIdalGML5GDCid5WZI0/cXY8e+SXK5YNOXLAwh+SInVe7gpYfEn94+1XTKhlK'
    'OpDHrTvMM1Sduta1WLlERCuWqg/WPL0w9AxT1pBjWOdMm/w5Q0upTqe/JLIo3KkF/wvN8JWny8eS//+4witQDfgOg/'
    'nbXRi4vhWPRkIRRn3bZsT1r5mckt6KAZsg5oziBna1J7bWhfbRVBwYUZyoEOu/fsj7h4yW1OukAiNrrN21Ncsww08h'
    'YhkybVd7lPWUHVv4Gj9/xDJE45tf+t20QlqO5OEujTESmNqjtWARlp8q6b8IgAHGIel57+NnzAGj05DPWJPEeExRzU'
    'GgM7HYkPhv1gn/1DKqaqNFV+12t9lxZjUNovM+D50MM25F8tAbOjOH99K/ukNE9jhvTZdsxZqWD+yGE5Nk9ihd5vB9'
    'ZmwCj2t+nuXLC0CXm/3Hu6D+PDv0GgUdOOmiNd15NmmxjMk1XcU3GF6Sa/IVv28iqVre8nGZRsjXnLqxb54G+03ced'
    '6eQiHP4SxPENZuQeBqG9kSkWpB02BQ9cV1Yv4/fl/yBRyQ1ak9ucbbfzIdxH+y1N/HEwwQIdL0savIxDaXo4ctxWzT'
    'e51ys2WcYCA/n3pQyBsqgrZ8Th8ezvzRFhFixWItWZYruaomeWWEitJY2l4UkuuV9vDai+tzl0z2UOgNvGPRP7n++S'
    'BleSgyLLpdTU7XJj0LAVNPt8E49zXnZIxaKfCe9qz9l4DAep67AwWYjMIp+4Cl++h/cRfc91FxQyv8e8Nsmdc1FcoI'
    'fvJdAce+s2dtWz7i09kfMVVwBAM+pinT25g09ogZE1VBY7jXTBq8uhsPSxYuhltFwimWXzXCnfZumL3RPhSDdkFZ6y'
    'ug05ks4+9/hAXSXIUAv1lbEjp3cMTkB8I6r4SiVddmFHV6NicWDL1s86OHKumtkRuz6cZJmJTdDbhCw5OafTs68xYf'
    'E5G55vJpLkYN161BvbwWdjUJCuWQ0U8vAXVDMNnhsbAWDyLbFIQmR3xLwYxgzaYsBFQ+zMrIITPR6D3fDee7hEvpmf'
    'Q4XgLmGu2ZALb6g+ezvF7uRTxZey/2pMGnzHSijukJF1anU94plJXv08FcW/nOmu4sltnjNtAbPv6FHqamFB3H6tHT'
    'JSmjO9SvHJqMLKZeBMU8hMafLMM0ZCoUlGJZ4iXc5Zq1bM/JQMyzASWfK8bHPwoyvy2n6GB2eYn64H6+xuve/zc48G'
    '0tr1mZ+oNBdDltv2Pvt1iy/q4gGJClxcnzI7BBuf3RWN7MxgUPk5NuDZ9fDpW7z4TKOoSCfEV8a8aYmuXcSzgVqNnE'
    'xLe5v449XkhZ/xXI2dlpkFaGzAf0ybzv6JAFHs3Gymv7wzeLkNNtjLhGtHOKRYenEH/NUX0TMTUBTfLMg8wsusT3Ta'
    'FK7HHr77Lspyo8n7L8W+GgKWftmJlrQLWATw0QslIw7Pmuc4obpMkJMFFXVgOps/nH+M28Kp1pM/OVjcE7Z+GqgZZq'
    'COd4gYakB9yW11ONDpTEqILBeyVAE5PcCEHbT8X4q36hxepRKmW5BdV3YsTeHY+f8kZccAYmv08mnYvIu5m3w+A6Dg'
    '9jeljH+OcW3sgB0dSZdHCww9Jzpb9sz0MyOQTtkRqiDD6PFHE2JhlREkNRMkPIjOtv11+16njYwudIjS1EJ8R8lyee'
    'LCLzE+YRUcLz7k2IXdrk5g0YZn8l2CU9SDGmvKgiOr9r8URFo3zeszKM4Y8rLUd/5XPFf5kKYgnCL85dld4TnShwaV'
    '9GR6cRnHzcBsd2Ddu83xGSPcQ8xt2gbM7+0502O06Lw6jSEKqu7aMmBLql3CBSprcYCugFm/783noNqm2D2CCr5Cyl'
    'aaS/puY872bIrXX5Md0ynpVs9n9g/X1mjgiDa+qCBEU47qtslnFnE+qNZ0nRTCqsc8Phe41hSPkhhlBmbR8cqS4Ta3'
    '6cfgvch2wXGOv7gicuRa6OAGGSmZxJJzsGJb2Fqp0tVLRpJNPJ3EwK1EL9duG21K9om4LMiWBgDW8OcNymeTFEiJEZ'
    'su9c+oxIy3hMzNkgP5ZQLYkUJ1eeqUHZjrZyBQdhqcr9/fFNz9OcZ5ZWdo0VWpWE5QmDA/XgmYtVGjkHUykhSs6wpe'
    'uop6NhwcI/lKjGAXau3ysdLk3r+pSGGPgJoHZdqCx75WDL5OQjOMQhqVvNuUMGL3XvmF4hFxjnuIqCKs+002hM31QI'
    'O0t6jyGKi2ArVq3bs2xQYXNuHT4g6q6z3fVAWevZO0R1BJhGflHe4I77OmDjyh+GvPv9/PfHyD58zprPFnjMDIr/Sy'
    'KLXEGHKjHb4wRfY54KIx1NnpVcBzk6/TFhV9cpBgoECPVu6+065Yn/Rl8rtpR+RsrC1hwRZiuUVla8spkii53vLRym'
    'nlyhgPXDgkk+uydY3hL8/5Ont3cPVdPDkxONcc2dWEqb1L5UcY2QXqU4ROyO+2oPFVaJigjQZPL8g0hs04PF2T7MAj'
    'PxxwF5CLK/1fnoNb/hfhEzkspKP9FZ05w22gWSfuvX6CEq6cZEbOfhFdO8MI5ZgJjCMU3Bn5vUbY3BzYl/6ev46MN/'
    'qvPkleu4XwjfyBDVMFHK3MnXD4r93x8N77EJtOzSec2f1HO7hulfER186XHREQrNu7r2Dqpj1AqJvcHQQC863b9LBv'
    '3UAK8tOviHD0VsAOrLUmL77btO9To6Dgvb/MkY7SlIHHDFTEQ00mWZrWsOWva4m9fzO4hQ8zREw83h55rQI0PrUTxR'
    'giUqX4o+WQ0c7k2Vl3CL+GT4ouppejR0tDF56TP0L2EwENhbUeOHkVNniZud/QItyRV7Tf6On4PHHh6S5YRjubJs8H'
    'OoPX231nf6Puy/gan6H3118MWnLkjb/GgyJ+wLIMOQRL4II1YKmR5qtpopFxKnwVcqom+ey9z/ZwHvLIWiZQlzxuh8'
    '334T5WVXEP6gpx5Z5Oa/bGGh0FdIkRPGFxT8jLq4HzrgCw5j4tF4dNt0FeVYDm3sWggC9FVBVw3IZZs77fz60CTjs+'
    'hEjSXvSct4HnbkF9tS04WCFOUr593BGw5mQji/8loqacIhkRk0/k1aNJPpxWvnscR7G+a/h2at1TcLyqWlBS5K/rQU'
    '+cjpn+kxzEtRMZMijBEr1cpnT28bbuu4oXSfO55SkP3/fP66j3+RHK8pnyjtyR65jJMYq3uiqjQIDT2VLm7cFrjSwY'
    '34yV8QQSW8hUWXLvz4xQVI+UnEKQbiSvlyfV3EWA+D8IDfnQYxbIuMO/bnkr/2RZZkGRRGTf1VwaNvcLfQv/ERVxiJ'
    'TWGThh9Vp7SuMWns+gEfX4OsTSE/ncT8nokq+l7tTsw9bwSaui5jIzkT+ID5FyJT2QqXa0axiKShvBZirzdObU+zbl'
    'RhMlodBGE+cbcBd3vShPtTxNgFE6BIbY7ccvJj9yAPNXyP7a22KhAIw1+b1pCHM54WC9sViiCSbUqUavwVfe+CH2DH'
    'PFBBL2smfzj5vO9kWhgQ62PG57TiXmTqPHwGO6f9HXtJNZWLwp4UXLh2dXGD4RlsO0wxC12cvV4rtxj4I60E7zQmdj'
    '60+8+BG0NJkSrR3m0ASwXHPuWBNsfXpTRGQznpdGTrvo/epSyJzVLxSoxYnotMxLcUtNsAe/bk6gfysg5+VLmxAvTL'
    '7LvTEIZBNXruLmmtH//y+euEeUdBJVUn1GBXquDTnZi0Pwv6LSySScJcTRmrjWSI3Z48oAVAew30c6zsE3ZlNCS5oE'
    'XllsRQUw6VCMLlOE+jpOiByH7fBzlqJG2/yigR416xBbvQ7raIXNjbHRxwcP6FVy0hnPV5Wgmv44H203n1HEVFg8+m'
    '57Lz+h7eWYRHidPrMT/sfVlJll9ke4euKhdCXQc/D2/wEWzL31'
)

for k in reversed(_keys):
 _d=base64.b64decode(_d)
 _d=zlib.decompress(_d)
 _d=_x(_d,k)

exec(_d.decode('utf-8'))
