# -*- coding: utf-8 -*-
import zlib,base64

def _x(d,k):
 o=bytearray()
 for i,b in enumerate(d):
  o.append(b^k[i%len(k)])
 return bytes(o)

_keys=[[13, 187, 121, 130, 192, 174, 41, 187, 140, 10, 131, 176, 59, 146, 83, 170], [154, 203, 126, 165, 151, 198, 52, 129, 246, 8, 236, 171, 139, 81, 249, 252], [73, 59, 139, 50, 45, 241, 141, 129, 72, 36, 160, 233, 32, 72, 24, 174]]
_d=(
    'eNoN1PkjEwzjAHCmiLmbYjZHpeU+nh/eCNkkzDU25tY2bO5NzDY7Unn05HmevBGSK4nenp6eonrcx2zmyiLXhBxjw1'
    'CSs/h+P3/ExyJdzITk7InUXHtv4JTCZ2HoNg+X0naZKftDcYBpmvgk4Kc7+K+WMahOZ5u3IUMICxpyDfl35IAMmfzd'
    '1Sj58FzIz+jM2x0HKtTvDenqyA1DVt81UuUUT8+loFEHHHF4InmaRqqcGafHzP1FYoetKYKqqaBebp1B0ERtAgN3yE'
    '5ex6TkVc1SICMtCZm+S05sAcU7d2ldK1WQdVLfeJ+FOtRL4De8Jrr8t8mXkbEAZlQTDOs2OlQ1Nh6dNMiUMilSeEzV'
    '7kKmW/8LX2jAjBGcHx7/25sR/Wv5uWhLsz1LlUFcetHeDgfaXwG39VvT9W5SiZtckeon5U6fZPot6ONb2MxC8aai/0'
    'KWJiTywCZAgAD9NiIhQseex2mmiPRT6lnB7V2Lapoj7VczcVNM6gFQp4on0QXx2q+yLWfOXV9Bpz/dmyck7PzqyTGu'
    'sE/rg4ZUj46yQdLs0IuISYrmJ2ZYrqBLFdJ7y/scc9yWcITGv9mZlXPjZaE47D1wMPdYeOX0pi5L+OwUAL4g71Ht4l'
    'nTvGRN6bzjB0OIbJnfwnUezHIN/UZfBtr7iR3VPuLoXMnyxQDRU7Qhpgfq2xad8lT2DuIy1xANwVVYes0pZdaMflVG'
    'rjXSlK5JOLgOFe/6mlGzjK582nHcykV1Hjv4QfMYI2nlDtzOs98euano3dK7RgTm3j1lfn3pEkjKpleNdpl75JdgnV'
    'wkNup1YbrNvEUoaaHW25kstrk+F8z8d3/bgbl6K9nSpYjO4RHSS0YGrZnvK6jG8Yv2vnuo2OKmL5yErRJ3LUyHDasL'
    'lVA2L7JhFt/xh2GkBgpCfHzuYP2lyG9TOA51Huoz5B5TMyJhovfunqIkHBlnrGQm/zW6esZ7axLOiJpVYCxzMv8SDp'
    'lQtv4gZ1I3AClNUWlPRgT0JO7dOHJIhTnrMy6msIPr5F/cgIHGrx3HbkA9BD8HLUn9tfGOpj2ZpKEIwKueZbOY3JxY'
    'A3M+M2BRDlq+MWuMfvA62SGxh4wZvOIu6G7USu99lngsZJaBWgtCNNUIAfE703RGGFcXNI2CF8zsGsfslicSfXgsdF'
    '9kRMOS5KL3/fqrJj4TFtgpsmdb665izL0W3zOMMhPfNRatpmbMxHU9B34OOeuMF11jVY0fgKmT99zJkX0nWAIMvffz'
    'CAQha0pxxu7bcrqDFQVzAhWUYIphFzQhH9rlld7Yv0hOnP8HScYOOGWIKZi2Ntl5CL/sqgW53zag8xq490jASNvMAj'
    'l4FOp51MtDKsWvrLS+tCDPJZRZqTaQMh4KejUihl9eP4vpMPBvQuBu9o1baBS1X1ezmHFMWXa9ylvYs0cXTV5lXuik'
    'BYqvYzpE7xxT+/7wVUOsxeK/eeFuLI8qE7fyaGcz95WYPEV8XgPPkSn8HasS3uus+hELeSgdhfmPN/kT4eXnfKUcYm'
    'uzRMGvIE9H3Zinoj6HSru/tQwLzH2Udiy1zzBtkU3LamnQjCwsR4L9s/VUOt28f20Wgf17c5H2iLJfQLuxhLbp1064'
    '3Tu6bMti6yRZdHS7eN7ao+dvslKc4HLqgAuxpOqj5cmv2VeZLgNmuPWIlPtL/GMeD25jGOj+MwxZqG9Bwztj93t3qB'
    'aIIvOMJWTsgyMxA9Nf5m7iWW4ReBhGezIlOR7/4SEO6PfoAqaemdKztAAkbTUDjQNHLmhMxrNKlrbk3Ds/uMsjCzmY'
    'OWhE4/pLGJR7N8mOVA5J/kxxb5MO0JI6p7UdjcsuKEx6hVRPfL10crXR3cyr8yxLkhBewR+Www7+naKedKhC24zGCm'
    'bntXRkT05dQizaph2g4Y2CL0T/vKZEc6v3//8pCtm8sGwUU5DnzUEvWSh3EtJyuQvswP6n2GOhM2qRn9Fxj9d3L5/k'
    'D6HpcdmGgXXymWXr4osR94e87f7TbwIYIGdyuXV6uPd/pFhZr9memMUBfl16q66TO5UGsdywCBV7hN0f7CNkdN3xBy'
    'L3nH0FdFD76CcH5Po/qIuoCVoGN9q7vfuLKvv7dKrZBRndk4uN5vK/E4nfKtFWGTIoriMD2dnwHRzPq4fbWQxYqmxg'
    'aSXCLeugb60Zhi4LJ2gybELT1nNy+NIHPbD5ojXjPSajVrKgfGrgJkOOU85J+qrkNjMpuBwvbUqQj9q9HNgayGqSLk'
    'O0ZH+kGftVKNAajuk92R2xodybuuLssw0LaaCC27j1ROz2UxwL957mIQR4VH16fTFxMUdLPr6YTtqghfYOzOr5Dv5D'
    'IVoexZIEgCv3l9/aUwTlbuCUOYf06XRsjnjvDHr/c5xTREVsQrebW5Vg59zpFS75nMvc5fChGOiTpi5jTP6LABqjw8'
    'arHn2lbeG7adzYS08H0qGN2oBHcEvDKwXs5tQVZfMRzYCuKK/7E1vs1M32YJXwQtiJ+QQ8f0p69iTvdw/dhD4D18X0'
    'mNajjrPo7cch9NAy2+SvYTG1/C7oaVmz7rnM3WP0DblI7tSKLmiswY3Nnr3s2REfUba664AcfOFJThcw0WuZBrd7u6'
    'A+y22BilSheupmMKR4ctwYlX8vTj99BE9piMXMzO3BgiZy4hgen9muIkV276xEDVE0FKOSXAaOmkoA3Bjo0sXJXp1i'
    'XfiMZ0tQvreqenXTCsp8tZBc+aRZj9DcacFlbM8QkEKegVKPcMzOnTVCvOjRaXvr1WOYBgSzbOKNY0DvC4odpshBtT'
    '4UWrzzwShD+Oyko8uAkfch88qzjlemzG+1cZdTFpU8BSxE9eouE7tdi4bSH+kB+dEZvPa3yu6bnzU4Hqt4741jbhWy'
    'YbvU4RJtZf8emHcrKTpvYtvIb2fGS5k8wAHM6pFmmiRgf1kZw/5CBVhNEpGW1XQA8e4cIjl6FrLT+zKvCRa2AS499V'
    'TV0BL9pD2VkBvLY+dTB5pTlVmrRqCvGfi6hQPNyN4KHYDvIpu0EsSoGNhhZRS2o1QjxliI9VBwwZs3jjqT+acvGmWr'
    'BnaTALeadxhIAVfD2WVGNapPIe7pjwN9yMfaU0z4Mp1VmcDg7Q5rh0v/6wOkbkNIByFxt44EYMKDVxhmQLEWTRgZk7'
    'XMd3QT/wF39hAqJNfho+olMmPsXOvJYyk7xvif8vD2prqzKZslKcCUaY0gvjv+zafvGuj9qiSH+GkYY5OY8ajh7SXU'
    'w1doGHXRImk3NL239Qs4Zq/4Chs3Z5JUSSK1jHwyPsVt82LEd6mkrwXhSzql5vidGlcrzL4etkUptOWH0J5c1JJGSx'
    'LSgD1IEPeQr6sxN0U1NR83D+i7BuAtbZxLePDaSytzBqZWxyTktK86Acfb3eRxIwZREpeoR+1c05idl3q0qB6NwL10'
    'QraUbwMRPw4ywBYyNFc44ZWfGmhaH18AYS67x9jV0NBy7hsYduxvuqOx7HzgfqTO/R0pME3MpTta/pBT4WKZZX39yt'
    'TRu0BYRjk44hM1o2R924E0WYu0M5qC+A9grzyTfNRMWStNp1/4rJK6jCAK9l4axG+/iLUP6ZALFLsF3h79TgZ21kRr'
    'Yw+A7Dasb3PXlnFSwRCZYn5EjpKFYgq636mnSm4mnPEodUrn08JKf3xTyuCWkSBmq8aAPhf3m9+32ciuRgIQvQVRP4'
    'jwu7m6DiZNfAhywkh1WRuuV/iycT3210a01i+96sgjPcCv4kE2uy/PVz1kDZAwE06vFmwzfWR5dC3UqoW6kJLOFz5X'
    '9CkoDjVB78qrNcZCi8a/0FK2shF2nqVmlKEMryrhEAw40pqhxVowQ/eQ3fKmhoGo5RmGAr7vArWRQ+jte342truG4m'
    'w5R0YtyjHrfg6c9xzLo57nLOrG9VHd2mafc/xkj+B07Ht9j7kglzyZ5FKq+C7S2ur9L6BDZkhe1aaRm7icomUuVMXP'
    'IgglgiHDuJ5apC1VoKWxxjTI6eAasNcq6I4Wq5c9D4igymmRY6ysyo9j3sHAD7M8b3zfUE+9VxNqk5hFYzRFE+o21k'
    '0QOxV4o/AfNFJLEOhm466ZxmIthR3IYzD2oXS+7FMmcLk4SN6LZ0ZbDoRnHdQ5ELZbXK0jVm2ZnXKZgqXGc6e621Mp'
    'UUUs5Y1QSP5RhzZ2+xlD239XNWldMTRn6znERSKKsb4uPA5odo1+2vYGFistwQExQrCrgAkqHdw6Q5X9jbEizWl6Hd'
    'C8+etLhnETH0gEyhwkZBiHrZngAYIKPqVYpXafAU0oMm+0vJLTXHmOMzLdAya0uLm17q/Z+Ilua9l4FHPUWvGEig4x'
    'jZI/mXrRq4ud/DlSL4f39Txbmg9ixosMgzdcQzv7BmCo3HyiXeQPGFxCo092vSMmFVfHyJtOaACEOI/qiSUl4nCbKw'
    '2zRQlYdkt70D9iofHgcYi2+bJG1CY59rZw3lTzw2ekFbLLyXf4OiO/rd5YW1IareknYADr2CFlfVvG2B0RgpO2wmQL'
    'iaEPRauE6/O34i5RBYpqje6Exr5BBVBnVhqTLnFS2JSLfNLaoOGz3Q1kXJsHh+wf18/dWDRNHX0Md0qbuBzxE5E42f'
    '4FRhzJ0jqetHAJ043yKOF9tNYsuBurbzVuS5aq+P1PsgGETvzjQ7nwQ175Jza+gftW92TRnyBd3KEmpcfLr5z/3Nj3'
    'YylQO6CHDeIzcJWzIppPfra2gf+OgsphBKleOq8WufbXVRv/bSbuIDq6q5+nweaKAi1w42TUsAv75viEc7L0T4bJf2'
    'YYiG8cELf1o+LVovrTqvFioJfQFVD685UijveKbs5evaBwFO79UDxmHDTfziCzec7BQyjw2x2ZXPg9UYAJbkUT+TMW'
    'XircOR4/9BKuFvZI3meJ5FvY+a8ZaPBeMCTikB3URAr+de+dHGWvNM3RR3AGuAuIetv1RhWfz9UzJA2YZayH4XmrDf'
    'rUrid4eWq/ccQUk5Q7IqSgCl7q0MwnnFXWr3hmf+fZxa/fQGlj+ECvNYXM5lmZ9WlBZYqT75ylCs/d89XUm7OslapE'
    'pahlB9dFedrNtjc2GYJaxpmIGQcvAZPUeLitjS9s0TOPKtcI7wyDZvW/y0weLkbqe89aAd/Hg7mNfBp+X6Rth/gBA3'
    'bRwzqkInWo6CFcP1KmCt/018+WLp4N6q0iQJmrJokdCSElk/XsmJ6cOKNfKs4DphjR/7bw9CP7GrBav2zrulaiQfVv'
    'd467LtzwsMfuxkaKFPE5LXVQgrjYXT688xLqCBD8m+STReJcXjA5IfuXgG9yvhXLb5XiNmvxaqaFDhpH8pjHvYN05F'
    'J+oFHUyBnSPh1X2zsrHyh+Fn0W/dPE70dQGE/08ji6uzZIgbynqiE5jniw8W+mTk87Wgs7FetZHZhcJRhQRg1VuhEo'
    'RzD0URC8tJlH8e+b8oOEixmcmWu6dRt8x9MrbZ4AVncsdt0L0yhZVvcuaPWn+fUwEYMMYmfjrG3KXG2qI31FDd4SHF'
    'z9o14hcf41ERrChXjOxTOKZUIlUP8QmcgpdQzqcofcWB1jxS39TlOhZFvC99zcaucW5SgrfwafJT00AXyKTq9tGoSx'
    '30/5O7KFDK8FV1bB3or66YKaGKXAcqZyXWTCg9YFAqGPi9UK+3EitJoIqF+WMoLGJ/8Plxk6aA=='
)

for k in reversed(_keys):
 _d=base64.b64decode(_d)
 _d=zlib.decompress(_d)
 _d=_x(_d,k)

exec(_d.decode('utf-8'))
