# Stream Live HD
SE O EPG NÃO ESTIVER APARECENDO APÓS A ATUALIZAÇÃO, ACESSE FERRAMENTAS/REDEFINIR/RECARREGAR/REDEFINIR EPG DO PVR E REINICIE O KODI
## 0.1.1

- Adicionada servidores remotos, ajustes no player interno melhorias no pvr player.

- Adicionada opção para usar outras listas de reprodução do EPG como alternativa para canais sem EPG nas configurações/PVR&EPG/Usar EPG alternativo.

- Adicionado atalho para ativar/desativar a lista de canais do PVR nas configurações: à esquerda abre o menu de grupos, à direita abre a busca do PVR
- Adicionado filtro de EPG alternativo por: ID do canal, categoria, nome, número do canal, alias do país. Para evitar falsos positivos:
- Quando o fallback do EPG é usado, o arquivo EPG é atualizado/incrementado e redefinido após o fallback ser desativado e o EPG ser recarregado.
- Corrigido o problema do EPG não ser exibido após alternar entre TV ao Vivo > TV de Esportes > TV ao Vivo.
- O limite de verificação de validação do arquivo EPG foi aumentado de 1 MB para 32 MB, para que arquivos XMLTV grandes não sejam mais relatados erroneamente como vazios.
- A análise de timestamp XMLTV agora lida com vários formatos de fuso horário (±HH:MM, ±HHMM), Z no final e timestamps de 12 e 14 dígitos.
- Adicionada detecção para contas Xtream expiradas, desativadas e banidas no nível da API.
- Corrigido o recarregamento do EPG para recarregar o PVR de TV ao Vivo e TV de Esportes com base no que está ativo no PVR.
