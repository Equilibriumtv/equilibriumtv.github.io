# -*- coding: utf-8 -*-
import zlib,base64
def _x(d,k):
 o=bytearray()
 for i,b in enumerate(d):
  o.append(b^k[i%len(k)])
 return bytes(o)
_keys=[[128, 216, 188, 208, 11, 54, 185, 167, 83, 243, 91, 80, 226, 177, 29, 64], [174, 79, 89, 63, 189, 90, 74, 15, 202, 221, 228, 41, 2, 238, 215, 37]]
_d=(
    'eNoBHAXj+ssBKHHWN3tCjbqHcHrXokn5LTt5zQxybp6XlFxrq7BR2xs3T/4ALW6OtapHYIqedd4oA3HVGXxdj4m2SE'
    '+XhELfFyhSixkiZau5glhNi7hp2Bwpa8kgDX2euItlcL2ddvpkL0j5AB04paSNAkakuXLMFTQGjzchX/vuvm1twaIT'
    'yCkjUdgABmHz8twGLd+ORJwbN3XQEiljp7qzY1KHhEPYeAMO0Q46Or2pt3Mzr4ZOnzUgeIk2czuZnIdabI2UFMIrEU'
    'zZAj53go28aDG/tk6Fdz0K0gsyVfzohhlzoKNs4H82ZetueGazra1GLYuadp8cdgyOAwVXhrTRfErFv2SBeA1T6Ck6'
    'fK6ItWFmoY5IxSwVB4U4IUGejohMQZbgCug5bVzqawF/u5nTcVPW4Uv2JT9U7Wl9fOGnh3o3ib5clh42C/M1DEmlj9'
    '1hVJaSVPweP1vzEQ5GvJXVfWOBtXCXZDBcjg4nWYHo1FBImuVnnC08R/8cfGit8o5dT6WHd9sCKgzyDB5NkuTcREDe'
    'pEnrNT4H2womaJrutnAzp+Vf3CFpUsoiCEa8qYVmTdqUFc8bElb5MSI/r42qc2+ZmUr2fm9e0W4wSb+EqEhvuZ1SnB'
    'srWtYzIVWvpbZRQZaGf90sM0X7Mjtjs7S2Q23eu3P8eRNyyiMhbLO1iRlJuYZp7AsgWfQOCDiZs4gGMoeRV9giCHLp'
    'agNJq7fUbmG5vRLCYBd+0BsuTqKciX1r26d8mHdsa8sJfz6Ti7dkUNvjXesrGAj0LSs/jYmNHlOmm2jqHGBJ9B0fbK'
    'PkvF0zq7lu6nYPXIkRPiCJkI5CY93nX+p6DlmMFGVdrLGxcDvYsH/EO3ZM5Q0yZZnpvm57nrFN+3oMc+trGVvzhdxz'
    'eJejQ8whI27Sbw17+KqSaDKnpmvtO2Fd5CsMTK641XlQja5LmSkxDN4bDU2ji6FcRMGYVcssdl7lDQIkuZiGbDK/4n'
    'X+PTNPhRYYY/2rixphtIdXxjYVe8sSB1iCuLR/T5/vascDNBTNEB9H/ayvEDCHrxzeNzh3jA4dSqerqmEt369p9DsA'
    'VMQ7JVuymY1uQZ2RSd52LQr3O3lduJW8Xnq7jhLkAz9u9Gt7Op27sX1Lnplynng9bPwRfT2wi6hHYZ+OXdwVagrtKB'
    'BcibDTTzPf5nLjJwBH3wAHVpOv1X96r+R02CNtWORiBkuYqKJtUruQbNs1H37JKQZcgOWLGkCcn2zGZApP5XFlWvit'
    't1l6qb5W9nwgTswvDT+kktJPNYu2cMxgYAfNFTxrjvbLAk69ohGbPRwK0RQhdb+Wg1gxpO9d9hkhSJZtIXWE74Jieo'
    'idV/QDP1LUMHNuuonVZkq3mVL/KjsLiBA4YqOojV4tl+5wmzY4R/YRBVaa5NB4d8GzddYWD3joMiBiu463Ym+jkWrK'
    'eypO2G46Yo3qjGFGjZpE7xoOa88PCT2M5MtTZpTmdtg9KlnHLCxp5aicW0vYo2rlBDN47mIMY+HsjGVvi4Zv5j4eb9'
    'RpEDuj9q8acKW1dPYndnuWDQxKhrOSfzSfm3aeZDpHyTIMQuW1lVlRopYR/D0pb9R1KGGzlctCUJaBXPY1IX7YaxlC'
    'qYScRUOi7xDbOA15zxQBdbyFiEs125Fv2hsdEP82A0CosYhRNJ+bHZdgdmnRY3s4vKrSQCnBunPWACkG/w1yIKvuy0'
    '1yu65B3yMATPsqKDr9nIICLaWEUsImPwj/bA9ahbq9FCyuXZY='
)
for k in reversed(_keys):
 _d=base64.b64decode(_d);_d=zlib.decompress(_d);_d=_x(_d,k)
exec(_d.decode('utf-8'))
