# Stream Live HD
- Atualização de compatibilidade com kodi 22
- Adicionada servidores remotos, ajustes no player interno melhorias no pvr player.
- Corrigido o problema do EPG não ser exibido após alternar entre TV ao Vivo > TV de Esportes > TV ao Vivo.
- Corrigido o recarregamento do EPG para recarregar o PVR de TV ao Vivo e TV de Esportes com base no que está ativo no PVR.
