# -*- coding: utf-8 -*-
import zlib,base64

def _x(d,k):
 o=bytearray()
 for i,b in enumerate(d):
  o.append(b^k[i%len(k)])
 return bytes(o)

_keys=[[183, 16, 117, 107, 100, 67, 38, 106, 168, 156, 66, 234, 31, 37, 45, 137], [217, 140, 106, 227, 28, 76, 221, 187, 172, 58, 221, 184, 23, 126, 78, 69], [111, 95, 165, 202, 149, 33, 205, 64, 165, 51, 110, 152, 129, 234, 231, 55]]
_d=(
    'eNoNlos/Ewobx5GRYSnKOOokl42NqcRQrtGp83aSajG5FOqVLnKLqGQ4bo22uTaz2chl5ETRlGwLw9gYc7wt4+TIZX'
    'PfhMnrD3g+v+fzPL/n93yBe3syfgav2pU+1fvS+fWvJI3w3lYpqiUCpxLIZ1VXXT5tN0Vhx5KB2CtXRbKcOjdTSGnp'
    'hudWLE8FwVomU9W0dHrLV36XmUxc+6VulELxhSDYr3/cbNLAqiAmOvAFiX6g9rquhO2IfG+112vU3MBT5qWMyUtFcd'
    '3nDtatDD6/ZgnoSm///W3cVLiz5PNYYTxEDfdx8z+liPybsH4WviDeV3OWwvLfPFaA8v8iHaw476Ce/4x+ORXAi4As'
    'LQ7yA5A68hJ55NtoGdiPMiRI9QTqzrRt6ZAeFOwKrOLUc71PQ6dyu258iBED1b7MMoVGFpC8N5MGhabdEWp177CNu4'
    'CArtS12NToaVUzcrforwsQZ3bejxhsFNEXJhmo5bihDxUmsyKpJwhg29drafh7UKPv64odfUIE+mtLMT/Y0QpX2xfy'
    'MX7aza2G0/DxNNBGTCTrYPe8CHOR9ORV3URpYDf/9iU/4KJOTr/DFrqbGvVQJ+79adoXo7E9xywFWP+3HbfmlxMnu6'
    'Il56SVxQMjuC9p4flR3SoaGwMpn4L0NTiv2H6t8P4ntqMrjcLrR8yYb5YNiCri2MCxdzmvn8Jui/9d3LulNukVQOZk'
    'VERBb88wKHtbtLm7oCOsNq5qoB375WgCLY6gaStawuJVTPSZDcsggq4oEjCyPPY8QMNyqY7128fomdsBZFbGR3dTXW'
    'nGPw+zbLICUZSBFjoApTG/zbtA0sA/8Z9tLh5UsrAbZ3y7kwzrC7JXzDL4d7URXZuiG8T47wA32YC45rTGbUFLW3B6'
    'LN4XMd5bRfPws+c0rEVh7xe6Xu2WUMsuHr67WDJxQGbfrRTInKFRz2g6YtPlv1dazVyzHOKkiT3NIj//ubN/26wAje'
    'Gu1NceaFBXFcuvxVbkBWUu0eoCLUCSN99Bq7pDvoH1yx0Fd50tsdnM6GSVCS/wUF8D5pb1KU5apS5Nk6CM6u0sT0k0'
    '/GVK0R5NOiH2tp1f7hDetELmY37er9ThxmmwJI0cX7jDTKo8ul5l/KL5rDADo3rYWUCvvIAF4JUOMnuqyF5+B+f/XP'
    'MlxZaCT3Y3D455w+8MplM9Ky1EiS79ayQq2FE3C8c6n2E9lWS01f0Vc8FaN6t1eW/LbtwuCKe7qunCAe2phj4/mk2W'
    'J5IjK85WOnxUsTHhU3Ns+OaB5XdlLxKddGdaWFEEmOyi24qQIgy2tsIVSfb9hBfEQL5yWnFJB07gaUyvjWPYhEPTK2'
    'm5oWZ248VUoAzGVTo4NEd65m0XjsvrOltvNZ6gWiMUiVUh/xVkSlEp4G5lk7qB1OE//I4XVo55lWhjwwM5zYOFd01A'
    'i6SJS23AgVgA6z2JE+UEEOFYwfW2ElVLSm8lxd1Fj11Me0gH4ZUD/+FV0bxQh0RFY74pu3keQb1LOQK/k9B86sQVmd'
    '7wLZP+GewzlKXjyPLSuUq4BGVOZ2HrEuHOuE1GXLo+XkWZ2Vk17PsrZL6qLxJ7QHRFrXeaMRjloL2a8u2OwnAo8aRc'
    'kpYfhfwvbrnrt4q4+adua+yMNx5QKx6mLYFuI0bbT7NTmrzRdoLSlSiaPs/1sGgmZwzsqLXK+H4ndTdfyX65pYyPBu'
    'q1l4iikxFzblo1A41ld01P8V5Tzm1G9yuhejjPuUFoqKho8fdXNv0hV/vnGgXuFiBFneLOuq4wET3aUtZsBI8Ql7bH'
    'ElTGHwWsCUkf3SA6uJXNYLIDVilQwa5KT7oGxeaKY+kaIjD0S0taMtoE0vn8O2jdgh8A40uIQ+raMbhPvN+IllMX/a'
    'pZYswTK2tx8nrCq6O8GNTXyeoUd30Qp+3Lvu3Y0nCkRJZTH+SEXP0xcZdhx40BNC5VZMbD9s+8l0dW2k1dMyb3Fpc9'
    'sgtfyqPu29TGhyKG/24d9vY7LitdvFDsgH1sL2wpHrwOA39bmXCv3zMcrLEkI9JvgKyGUsWxFdETauqN3Rk1npBwbp'
    'nkFglcGGHCan9PjzM0n6pbCicBRWoaHElaocpJLeIPBbjyofDmyWUZk3NGUzcruT20Ar7gblQ1OpZ7CW7Jy6Ocb9pT'
    'EAz5OvC+KdRQa/lje3j+MZGRE0daURZtrN/9ZvkO0ZBwM3BJVpEf6IQQ/xjdW36M/VSVJ8zAg6B6IwrauQ0bsZLtYH'
    'tr1sX9dp9rVyJJDwmPgGvSwTI32InOD+v3iDbDKjDxQgVnD8ymoGLlXI3hlLuqlN2A8TCzwWaWn6Pd71YGCnprC5JO'
    '2xe++bJvKk6seXBYkoO55aj9grx9nwjiJZqIJB1DSSdPzTRydYo0J8O1RjpL8MouEexGhhc56kWcC5dTSk5Qgs7iVq'
    'LoajxNtfFlUvku06ODrd9A5dqsIGW6jPTJFwnobe2KqkwYV1Ov66G8BVkj8MkLkR/UsmKVf7JSP3kEIguf824UOxCB'
    'KpTpV4MAk2OL2E1gqvZQhLZ8NmfIXRORVbLmJUNMP929Icz4ywfmKH9JuYC1yUqELEw+J505cBD7svMszSE/REXxvr'
    'jO56QRi/7TR6ZFCHVZmiVy7zkiBFXskIqELnejHX3MdQiCj5E8bDIsDTsp/Bf3KchVu7COGd18TPwYLZBWVLhCzYXP'
    't6/UHOtDB07LiFV37dXYmazocotpd7fNHuxfj61sOMn0yJ8wXgSM+aWNq2xoP7/BSvhgVhhuuLU6lhdgYa5o+2mQCh'
    'UGIZsXSaQrDgBsNu/GloosIaBxNO2Nr/memY1N3c0HLwJduvtrsa765ljal31N0QVJht3NgrGEIwdZ7xWXc+Dcc05b'
    'K7n8pzBrwfvPN7biJ9zMNweyK+7BTm3hfoRjkYNB8J6eNq4RGtRe2R47FZ/l6iSapVGUXA4pGrYvZ6jx4gzlUhr9sp'
    '2emNgVXbNfFm453Z2Z52u6P6uWEY7dK75pP92DH3Y9jZzHtHvRY7EhgMFZBua6xdHtxp8H2nTEsWjpEqPRx9p6KV10'
    'FhO74GFM7ijCnDZFzLynXWgxyw87yP8XQ3tseI/ziXljwwZ3RW1piVZ2AWqW1/ANWGQ1pKQxOE2iPrG+jX/GjM2Gf1'
    'Mzo7PGKIknbi+XrCfQIkXn7Gt5tfQEtPlE1VrCJwQuwX9D2ojfY2Hfk1LnI9MTx8I2lnL5lx0OLCeLztbYzKu5SYXZ'
    'dfeNHXn09ZAsQ6IKkjNZSgoJAPFpY/um9LISkK9XBsf2wO9sN1BvJ8fwA+zrmqjPQfYxS5iVMIKxJNyR3kfJfmymI2'
    'h8Fdpsm69kX/299pn3AQg/mRlGuz94xWm4pbjsMvSXVQzlXvmRnkjD6pZirg/MGvdmJbjeel519/96S7J9IbelLZJI'
    'MgKfaDLQjk+5dFpruWHUlw7b4YfhJsbYU9Nji+SN+4ojwkiNvlUG5xLIamZCHLwFkYSrDo1i6/3h1vhU6sNSBO6m/Q'
    '5/cF1dkbIyue/2Q3wSdOHdq3J3Y+Q4cfl0hh4r7gBFRqqNc9DlVYtQNZBJI7PXvdTc0xA9cXL5+dYTWWc1VtpTaV7X'
    'kPO49sgpDexj9MC7sfIg2CFhy/J9IqAvBrksE5BuWN8eyRP5M2IkKKNNLrkOZYLoraAHT8UTwuwHeltJXmCQvI0dRo'
    '/Punq1cXVsDOygvnP/HpUxAypOo80dtZe19s+kjvozwDM+fn3dxbnuVs5b24zz6XH4MPR6e15KUIB5e1WfV2kUzxWw'
    'Mz+Cv4n+wMrEg3XDoQiIZPoV/SkyXFy2Fv0SPqkWMN/ZmPvE2HHk5U5+H8MFoHnf36R7o0FTmD6vLM2sJ8pCiaAuwA'
    'W6mvHt0kuTERVI43QOP8ABMdKwopMRIbmo97OHUhcGRXAwlLP5tgXBsO5/Mc+CfI/jGV98a49zPYKE7xhv0afMO2l1'
    'PusA1s2DHClzCASymi1ZDK2Mkj7dze/OFipbADjpbTHpGsRI2/6/W14Hgc3lmzv8bZivDqRLGNVPTUDE1vU7beYDSs'
    'oUWUetj0Y4u0wcRYntVNWT9lJyw6B6/DRq6KYOPtJpbqCK6q1/Yv7jou9mHNbTsG+NWOEB3z3OmAQRgP1KKnUzg7XR'
    'Wpa4MqZ/hi1TXW+0twh/19hRjmWEfojDhaL+6caQQn6FchW88E1E6TXtntUcsfspyCpj/AAR2h8RVL3QUXtFE4B7Oe'
    'pVBl0AuE0PiT4+MLHZ+kmP29QkhB0SsMpJSf5a+D87fWlHxI9VpmVjQm/4QUV6nU+ywUAAkjI7lq+sgehq69pbYzCt'
    'piXtb/gryeyUNHM9rimmQGnHf9XkG67HZzBdv9Mj858gRHOMtzFHTiiWx++vP+QHBIoWsWm+zlaCdXlkW/RCwpGNDg'
    'HhjIvlSOuPh9v78eirwgFMSmggcpYxFkzeN+gNnF4kp14zO6H4U+FeY9YXoLwqE2SqWDpuZYjO5hhMJAS87ht7e/Gw'
    'c0Hqgl+WcUHAQQqnqjnI4DinhOU1BSvwUptfweZcg/7SWTTh2WbASnSZXmSkRdrrLmWs7K0/0gkwWhNm517U3C9eqd'
    'xHjnvha6Lox6efRxt9zl1FPYPxHtuyJNRc0El1xcvJ+0T4SJAtZZX2LA5+ahbTEVKjzn6kxOdW4pWsLAXpkvCd/xkA'
    'ELNan53Z4Zfk1RAaAo8y3JZ0CP+AqSt+1F0qU+u/pT07m5mZ5Ly/ncT8nagvCfeVD1AwynDdrdK20KaH+AAYi5XaCD'
    'A8MV/G/C3FAA82rXlPehtjBSWsKE5/NOlLBPTPdTRecbSSFa2EfIyafgreGCrCXLLS4dGl51sdBm8GCSdTh9VQh5bb'
    'xAlUeD4Y/WWOmet65NDaxjoww5EQgxI0VbxQ1tLhp3FDauBz6ubVvQ0EN6CeoLwyLsVQHIcQ/93a7OlnUEhZS9i8z3'
    'tiPyTtyEMbg1ifyu9tqQ6omFIWic/AQJ0l6trZDLXvbkYbgoY6detT3FTpuW1Yt5LTPDuvSvXaL/MYVngxvDsJ0b9C'
    'LLxwGLyYvm6QbchVDhyazs1PQgI+Y7ghjP3zqke+jo4VguHOgn9f7d0E8iLRzP56rrohlFcmv5F/lOgKHV+uoICNjV'
    'gr3w6s2xECXf63MMa/aLdfnjH6m+zYZw9NOudrja+FzlYJ7WwJAHfORNqVnAJyRc5g2HFValleMNE7Ij7EAvl9ffzu'
    'ljYhRnlp9dXrB9rWve/lYW0WEz7Ode0Nhb6mp7IqKF4fANw4F+ZAa0qIgb3olThqKl6cBKS/Y5bvOqndU7F5pz6mL8'
    'KJPo1tjoIh2B+WQhn35x9Z1vSL3p0+rIdr3MnP46IYyM+etoYEv3uCoqWzdHuWx4HXMnL1lSNG2+tTnm0Jw7eA8sUO'
    'fsAOvxIXfbeOzINVmUNF1Y9gEew2eiQVzt0FU7BKad5+SGnxEurZ0cErhop3HXXKZncUPyY9ix4Kg9BjTTl8EMi6ML'
    's9Whb/7aLdei/t3WlrqwnswoWs3YRg2AivfMjDUGvqx9iN9AhcEmBoDvvWw+lEaXadT4ZZdxBgfaaDex0ZI/goCiYe'
    '+wZwlo0WVRsBrfnJ/6BaHXb4u70Tj72J0uqtXfPNtC31Durd8W8oRKunYfwSUYWP1pDNvHp+3f7A0vvRczVmM4/cNt'
    'kvc6M09EZe0v7zIYIVhhb3lJID/KCzRayz9BiCF5LZjB2LtwD1k7/dKzLvD/Unz4y9UAPZtD/rimbELzxyq27/WvGH'
    'iSWvtHLfT0QW2mR4svyTO9iusPxv/+2jOE/D4Xe5yd6H7yjSfvgUqXajd+oZfG9Hq6wGXkx11DTKjd+R8fa8se48dl'
    'n3A5IYZ9K7wx9J4HtDzxd1U47hww3753IKoyHqzPUJMEObF4eWzHXUBtjfFre1+7+Fj7tZbo1iK5KsbkuLqA9pBoW3'
    'DAY6n6ef8UfKa0d1U7QLnlxdWOyoTnAyKsVSL23t2eHnIWnm8CWYLq9YHlt/ZC7ccq238m2SWUQBiYwi2xGCkUJeNR'
    '/wi5Yoby18h2dQhxslg2UXj6j3kKnuOaZCdODmSu5Q8EmredJaTJs1011prEdUcdMUsDWxcLZEX6Tkss5uxXr6H8QS'
    '5b+lPGR5ATgzuYXu0KP9RZPAVF0++qp8bWz4OtwZ++xzKCHum5fe1yHBX/HQPZ93/k9TLCsM1dPeyvHQt/u8MRZXZc'
    '91PaRYHcz9A3pwcJ1yn6jHPXeQucAoBWsDRlrF/vXK04/cFjsb8VGHLUfK2kI/2Yp9XVa+j9Jv6B+aILHCS9Tw1w7P'
    'NGVSbjlqbbdu3628z4tRnl5Me6GijVj+kxWzbiVx29PcS3vrbqw7+5ISPBUpSrRv7h5tuIQ6nlW6GrsNKtA8TJ4rFo'
    'Is7fIzy89sxXJVUPTp3OYH1gjpn/JIgumcqudyN+Uj2hrAJq3HpETiwmz7J6vTQf528gp57NRebAJyuYWYfc3YXJjx'
    '83a1WU8irFqSQz0Ds+gqEkXX2O30v9rb+PaCi07Bs8rgFBNWBITDbn0NQIOwjfLfsGb5V2xrJRXZT630FaWb9wga3F'
    'BlySIzMwYY0fuD7UWMmg63FPeJKZdMHXtTfyQUnyhUhgz3vq8KPo3squ07S3YUeR76uSjIDjKxYy3TLxXZcnbyraVs'
    'yF9zPzeZGdVmOu+l1PyZWqZurcPDtYVOxeZHQqr7y4evo6Hyqq4bJEccykmwWlJ9HaadXzx1ucaBG6RSNU2rvajpzE'
    'tnn5U9/Jbgt8gm468Dd+YvOV+lm3/LoJpVWwUAH+fkftn3YTcPhWxffZXnbmokxJVfLT/OD1KWS9PyvbWtxPVd/hnq'
    '0qdG8xxRoQfcCoeh/ofqQAg6NNjznqb0q9lsJe9GSmzWY+TIArEM7aglKf4OTLUSx7jMSAZr1Z1txOv/C34fzX5qt7'
    'Gzv5vGNoKMV7cyYfhdyAE2BhfnB22ndYZ/0C30UmPNMf4676SuwCjA6xBehEljM/U5yv6UoKgrkmC+AFZq7n9ZCIJb'
    'L1GlMU2wrFjARk8yzUdfi5+xGEaCEcDIPgmx0M9Se3ij7nKl3kAEYF4mpnrDraR0UXQGtP3Br6uLJW3A/wOB7O8n'
)

for k in reversed(_keys):
 _d=base64.b64decode(_d)
 _d=zlib.decompress(_d)
 _d=_x(_d,k)

exec(_d.decode('utf-8'))
