# Tema Nimbus para Kodi Omega

Caso encontre algum problema ao usar o Nimbus, siga estas orientações antes de abrir uma solicitação:

- Leia o **REGISTRO DE ALTERAÇÕES**. À medida que novas atualizações são lançadas, recursos são adicionados, alterados, modificados ou removidos. *Antes de abrir uma solicitação* relacionada a isso, certifique-se de ler o registro de alterações (localizado na parte inferior das configurações do tema em Extras), pois ele contém informações sobre todas as alterações feitas em cada atualização. Também é uma boa maneira de se manter atualizado sobre as novidades do tema.

- Solicitações relacionadas a erros **DEVEM** incluir um arquivo de log. Sua solicitação será fechada imediatamente se você não incluir um arquivo de log.

- Verifique todas as solicitações abertas para ver se o seu problema já está sendo tratado. - Apenas **um** problema/solicitação de recurso por usuário por vez. Se eu vir vários problemas abertos pelo mesmo usuário, todos, exceto o primeiro, serão fechados.
- **NÃO** utilize um problema aberto para questões não relacionadas. Abra um novo problema.
- Faça o possível para **monitorar** o problema que você abriu. Se eu precisar de informações adicionais e elas não forem fornecidas em até 7 dias, fecharei o problema.
