# -*- coding: utf-8 -*-
import uuid
import requests
from datetime import datetime, timedelta
from urllib.parse import quote_plus

try:
    from lib.helper import *
except ImportError:
    from helper import *

try:
    from lib.ClientScraper import cfscraper, USER_AGENT
except ImportError:
    from ClientScraper import cfscraper, USER_AGENT


def get_current_time():
    """Obtém o horário atual da API worldtimeapi para o fuso horário de São Paulo."""
    response = requests.get('http://worldtimeapi.org/api/timezone/America/Sao_Paulo')
    if response.status_code == 200:
        data = response.json()
        datetime_str = data['datetime']
        # Corrigir formatos de fuso horário truncados
        if datetime_str.endswith(('-03:0', '+00:0')):
            datetime_str = datetime_str[:-1] + '0'
        current_time = datetime.strptime(datetime_str, '%Y-%m-%dT%H:%M:%S.%f%z')
        return current_time
    else:
        raise Exception("Falha ao obter o horário da API")


def playlist_pluto():
    channels_kodi = []
    channels_info = []

    try:
        deviceid = str(uuid.uuid4())
        time_brazil = get_current_time()
        from_date = time_brazil
        to_date = from_date + timedelta(days=1)
        from_str = from_date.strftime('%Y-%m-%dT%H:%M:%SZ')
        to_str = to_date.strftime('%Y-%m-%dT%H:%M:%SZ')

        url = f"http://api.pluto.tv/v2/channels?start={from_str}&stop={to_str}"
        response = cfscraper.get(url)
        response.raise_for_status()
        channels = response.json()

        for channel in channels:
            if channel.get('number', 0) > 0:
                channel_info = {
                    'name': channel.get('name'),
                    'thumbnail': channel.get('logo', {}).get('path'),
                    'current_program': None,
                    'next_program': None,
                    'url': None
                }

                url_data = channel.get('stitched', {}).get('urls', [{}])[0].get('url')
                if url_data:
                    url_data = url_data.replace('&deviceMake=', '&deviceMake=Firefox')
                    url_data = url_data.replace('&deviceType=', '&deviceType=web')
                    url_data = url_data.replace('&deviceId=unknown', f'&deviceId={deviceid}')
                    url_data = url_data.replace('&deviceModel=', '&deviceModel=web')
                    url_data = url_data.replace('&deviceVersion=unknown', '&deviceVersion=82.0')
                    url_data = url_data.replace('&appName=&', '&appName=web&')
                    url_data = url_data.replace('&appVersion=&', '&appVersion=5.9.1')
                    url_data = url_data.replace('&sid=', f'&sid={deviceid}&sessionID={deviceid}')
                    url_data = url_data.replace('&deviceDNT=0', '&deviceDNT=false')
                    url_data += f"&serverSideAds=false&terminate=false&clientDeviceType=0&clientModelNumber=na&clientID={deviceid}"
                    url_data += '|User-Agent=' + quote_plus(USER_AGENT)

                    channel_info['url'] = url_data

                now = None
                for timeline in channel.get('timelines', []):
                    start = datetime.fromisoformat(timeline['start'].replace('Z', '+00:00'))
                    end = datetime.fromisoformat(timeline['stop'].replace('Z', '+00:00'))

                    if start <= time_brazil <= end:
                        now = end
                        channel_info['current_program'] = {
                            'title': timeline['episode']['name'],
                            'description': timeline['episode'].get('description', ''),
                            'start_time': start.isoformat(),
                            'end_time': end.isoformat()
                        }
                    elif now and start <= now < end:
                        channel_info['next_program'] = {
                            'title': timeline['episode']['name'],
                            'description': timeline['episode'].get('description', ''),
                            'start_time': start.isoformat(),
                            'end_time': end.isoformat()
                        }

                channels_info.append(channel_info)

    except Exception as e:
        print(f"Erro ao processar canais Pluto TV: {e}")
        return []

    # Formatar canais para o Kodi
    time_format = "%Y-%m-%dT%H:%M:%S%z"
    for idx, channel in enumerate(channels_info):
        desc = ''
        number = str(idx + 1)
        channel_name = channel.get('name', number)
        thumbnail = channel.get('thumbnail', '')
        stream = channel.get('url', '')

        current = channel.get('current_program', {})
        next_prog = channel.get('next_program', {})

        if current:
            try:
                start_time = datetime.strptime(current['start_time'], time_format) - timedelta(hours=3)
                desc += f"[COLOR yellow][{start_time.strftime('%H:%M')}] {current['title']}[/COLOR]\n({current['description']})\n"
                channel_name += f" - [COLOR yellow]{current['title']}[/COLOR]"
            except Exception as e:
                print(f"Erro ao formatar programa atual: {e}")

        if next_prog:
            try:
                next_time = datetime.strptime(next_prog['start_time'], time_format) - timedelta(hours=3)
                desc += f"[COLOR yellow][{next_time.strftime('%H:%M')}] {next_prog['title']}[/COLOR]\n({next_prog['description']})\n"
            except Exception as e:
                print(f"Erro ao formatar próximo programa: {e}")

        channels_kodi.append((channel_name, desc, thumbnail, stream))

    return channels_kodi