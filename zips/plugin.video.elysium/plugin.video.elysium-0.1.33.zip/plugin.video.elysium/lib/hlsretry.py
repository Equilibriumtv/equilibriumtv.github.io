import xbmc
import xbmcgui
import xbmcaddon

def play(url, name='Stream', icon=''):
    # Cabeçalho padrão para evitar bloqueios simples
    user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36'
    final_url = url + '|User-Agent=' + user_agent

    # Cria o item de vídeo
    list_item = xbmcgui.ListItem(name)
    list_item.setArt({'icon': str(icon), 'thumb': str(icon)})

    # Detecta versão do Kodi
    try:
        kodi_version = int(xbmcaddon.Addon().getAddonInfo('version').split('.')[0])
    except:
        kodi_version = 19  # fallback seguro

    # Define metadados
    if kodi_version > 19:
        info = list_item.getVideoInfoTag()
        info.setTitle(name)
    else:
        list_item.setInfo(type='Video', infoLabels={'Title': name})

    # Marca como reproduzível
    list_item.setProperty('IsPlayable', 'true')
    list_item.setPath(final_url)

    # Executa o player
    xbmc.Player().play(item=final_url, listitem=list_item)

