import xbmc
import xbmcgui

def play(url, name='Stream', icon=''):
    user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36'
    final_url = url + '|User-Agent=' + user_agent

    liz = xbmcgui.ListItem(name)
    liz.setArt({'icon': str(icon), 'thumb': str(icon)})
    
    try:
        from xbmcaddon import Addon
        addon = Addon()
        kodi_version = int(addon.getAddonInfo('version').split('.')[0])
    except:
        kodi_version = 19

    if kodi_version > 19:
        info = liz.getVideoInfoTag()
        info.setTitle(name)
    else:
        liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': ''})

    liz.setProperty('IsPlayable', 'true')
    liz.setPath(final_url)
    xbmc.Player().play(item=final_url, listitem=liz)
