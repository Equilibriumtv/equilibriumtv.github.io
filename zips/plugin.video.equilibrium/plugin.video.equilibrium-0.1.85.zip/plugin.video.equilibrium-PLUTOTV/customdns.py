# -*- coding: utf-8 -*-
import socket
import random
import struct
import sys
import logging
from resources.modules import control

# Configura logging para depuração
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')

class DNSOverride:
    """
    Substitui a função padrão de resolução DNS do socket por uma consulta direta
    a um servidor DNS customizado (ex: 1.1.1.1), com cache interno.
    """
    def __init__(self, dns_server="8.8.8.8"):
        self.dns_server = control.setting('dns_resolver') or dns_server
        self.py2 = sys.version_info[0] == 2
        self.original_getaddrinfo = socket.getaddrinfo
        self.cache = {}

        # Substitui o método original
        socket.getaddrinfo = self._resolver

    def _bchr(self, val):
        return chr(val) if self.py2 else bytes([val])

    def _bjoin(self, parts):
        return b"".join(parts)

    def _to_bytes(self, val):
        if self.py2:
            return val if isinstance(val, str) else val.encode("utf-8")
        return val if isinstance(val, bytes) else val.encode("utf-8")

    def _is_valid_ipv4(self, ip):
        try:
            socket.inet_aton(ip)
            return True
        except socket.error:
            return False

    def _build_query(self, domain):
        tid = random.randint(0, 65535)
        header = struct.pack(">HHHHHH", tid, 0x0100, 1, 0, 0, 0)
        qname_parts = []

        for part in domain.split('.'):
            if part:
                qname_parts.append(self._bchr(len(part)))
                qname_parts.append(self._to_bytes(part))
        qname_parts.append(self._bchr(0))

        qname = self._bjoin(qname_parts)
        question = qname + struct.pack(">HH", 1, 1)  # A record, IN class
        return header + question, tid

    def _parse_response(self, data, tid, domain):
        if len(data) < 12:
            logging.error("Resposta DNS muito curta")
            return None

        recv_tid = struct.unpack(">H", data[:2])[0]
        if recv_tid != tid:
            logging.error("ID da transação DNS não corresponde")
            return None

        answer_count = struct.unpack(">H", data[6:8])[0]
        i = 12
        while i < len(data) and (ord(data[i]) if self.py2 else data[i]) != 0:
            i += 1
        i += 5  # Pula null byte e QTYPE/QCLASS

        for _ in range(answer_count):
            if i + 10 > len(data):
                logging.error("Resposta DNS truncada")
                return None

            i += 2  # Name (pode ser ponteiro)
            type_, class_, ttl, rdlen = struct.unpack(">HHIH", data[i:i+10])
            i += 10

            if type_ == 1 and class_ == 1 and rdlen == 4:  # A, IN
                ip_bytes = data[i:i+4]
                ip = ".".join(str(ord(b)) if self.py2 else str(b) for b in ip_bytes)
                self.cache[domain] = ip
                logging.debug("Resolved {} to {}".format(domain, ip))
                return ip

            i += rdlen

        logging.warning("Nenhum registro A encontrado para {}".format(domain))
        return None

    def resolve(self, domain):
        """Resolve um domínio utilizando o servidor DNS configurado"""
        if domain in self.cache:
            logging.debug("Cache hit for {}: {}".format(domain, self.cache[domain]))
            return self.cache[domain]

        try:
            query, tid = self._build_query(domain)
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                s.settimeout(5)
                s.sendto(query, (self.dns_server, 53))
                data, _ = s.recvfrom(512)
                return self._parse_response(data, tid, domain)
        except socket.timeout:
            logging.error("Timeout ao consultar DNS para {}".format(domain))
        except Exception as e:
            logging.error("Erro ao resolver {}: {}".format(domain, e))
        return None

    def _resolver(self, host, port, *args, **kwargs):
        """Função substituta de socket.getaddrinfo"""
        try:
            if self._is_valid_ipv4(host):
                logging.debug("Bypass DNS: {} já é um IP".format(host))
                return [(socket.AF_INET, socket.SOCK_STREAM, 6, '', (host, port))]

            ip = self.resolve(host)
            if ip:
                return [(socket.AF_INET, socket.SOCK_STREAM, 6, '', (ip, port))]

            logging.warning("Falha ao resolver {}, usando getaddrinfo original".format(host))
        except Exception as e:
            logging.error("Erro no resolver para {}: {}".format(host, e))

        return self.original_getaddrinfo(host, port, *args, **kwargs)