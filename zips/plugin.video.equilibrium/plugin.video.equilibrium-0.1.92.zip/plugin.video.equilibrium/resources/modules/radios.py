# -*- coding: utf-8 -*-
import xbmc # type: ignore
import urllib.request
import base64
part1 = "aHR0cHM6Ly9kbC5kcm9wYm94dXNlcmNvbnRlbnQuY29tL3MvcjF1d2M4MGR0amF1bHBoa2drbGlqL3JhZGlvcy5tM3U/"
base = "aHR0cHvdGwwajU2M6Ly9kbvdGwwajU294dXNlcmNvvdGwwajU2uY29vdGwwajU2tL3Mv"
part2 = "cmxrZXk9NTRvdGwwajU2bmprZGQzcjZibDhwOTZsZA=="
def get_m3u_url():
    url_codificada = part1 + part2
    return base64.b64decode(url_codificada).decode('utf-8')
def carregar_radios():
    radios = []
    try:
        url = get_m3u_url()
        with urllib.request.urlopen(url) as response:
            conteudo = response.read().decode("utf-8", errors="ignore").splitlines()
        nome = None
        for linha in conteudo:
            linha = linha.strip()
            if linha.startswith("#EXTINF"):
                partes = linha.split(",", 1)
                nome = partes[1].strip() if len(partes) > 1 else "Rádio sem nome"
            elif linha.startswith("http") and nome:
                icon = "radios.png"
                radios.append((nome, linha, icon))
                nome = None
    except Exception as e:
        xbmc.log(f"[RÁDIOS] Erro ao carregar lista: {e}", xbmc.LOGERROR)
    return radios