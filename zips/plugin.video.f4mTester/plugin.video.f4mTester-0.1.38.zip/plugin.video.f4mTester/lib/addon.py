# -*- coding: utf-8 -*-
from lib.helper import *
from lib import hlsretry, tsdownloader
import inputstreamhelper
from urllib.parse import urlparse, unquote_plus, quote


def m3u8_to_ts(url):
    if '.m3u8' in url and '/live/' in url and url.count("/") > 5:
        url = url.replace('/live', '').replace('.m3u8', '')
    return url


def basename(p):
    return p[p.rfind('/') + 1:]


def convert_to_m3u8(url):
    if '|' in url:
        url = url.split('|')[0]
    elif '%7C' in url:
        url = url.split('%7C')[0]
    if not urlparse(url).path.endswith('.m3u8') and '/hl' not in url and url.count("/") > 4 and not any(x in url for x in ['.mp4', '.avi']):
        try:
            parsed_url = urlparse(url)
            host_part1 = f"{parsed_url.scheme}://{parsed_url.netloc}"
            host_part2 = url.split(host_part1)[1]
            url = host_part1 + '/live' + host_part2
            file = basename(url)
            if '.ts' in file:
                url = url.replace('.ts', '.m3u8')
            elif not url.endswith('.m3u8'):
                url += '.m3u8'
        except Exception as e:
            log(f"Erro ao converter para M3U8: {e}")
    return url


def build_name(prefix, name):
    return f"{prefix} - {name}" if name else prefix


def player_hlsretry(name, url, iconimage, description):
    name = build_name('F4MTESTER - HLSRETRY', name)
    url = unquote_plus(url)
    url = f"http://{hlsretry.HOST_NAME}:{hlsretry.PORT_NUMBER}/?url={quote(url)}"
    hlsretry.XtreamProxy().start()
    li = xbmcgui.ListItem(name)
    li.setArt({"icon": "DefaultVideo.png", "thumb": iconimage or ''})
    if kversion > 19:
        info = li.getVideoInfoTag()
        info.setTitle(name)
        info.setPlot(description)
    else:
        li.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
    xbmc.Player().play(item=url, listitem=li)


def player_tsdownloader(name, url, iconimage, description):
    name = build_name('F4MTESTER - TSDOWNLOADER', name)
    url = unquote_plus(url)
    url = url.replace('live/', '').replace('.m3u8', '')
    url = f"http://{tsdownloader.HOST_NAME}:{tsdownloader.PORT_NUMBER}/?url={quote(url)}"
    tsdownloader.XtreamProxy().start()
    li = xbmcgui.ListItem(name)
    li.setArt({"icon": "DefaultVideo.png", "thumb": iconimage or ''})
    if kversion > 19:
        info = li.getVideoInfoTag()
        info.setTitle(name)
        info.setPlot(description)
    else:
        li.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
    xbmc.Player().play(item=url, listitem=li)


def player_input(name, url, iconimage, description):
    name = build_name('F4MTESTER - INPUTSTREAM ADAPTIVE', name)
    url = convert_to_m3u8(url)
    if urlparse(url).path.endswith('.m3u8'):
        is_helper = inputstreamhelper.Helper("hls")
        if is_helper.check_inputstream():
            url = unquote_plus(url)
            header = ''
            if '|' in url:
                parts = url.split('|', 1)
                url = parts[0]
                header = parts[1]
            play_item = xbmcgui.ListItem(path=url)
            play_item.setArt({"icon": "DefaultVideo.png", "thumb": iconimage or ''})
            if kversion > 19:
                info = play_item.getVideoInfoTag()
                info.setTitle(name)
                info.setPlot(description)
            else:
                play_item.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
            play_item.setContentLookup(False)
            play_item.setMimeType("application/vnd.apple.mpegurl")
            prop = 'inputstream' if kversion >= 19 else 'inputstreamaddon'
            play_item.setProperty(prop, is_helper.inputstream_addon)
            play_item.setProperty("inputstream.adaptive.manifest_type", "hls")
            if header:
                play_item.setProperty("inputstream.adaptive.manifest_headers", header)
            xbmc.Player().play(item=url, listitem=play_item)
        else:
            notify('Inputstream Adaptive não está disponível')
    else:
        notify('O link não é M3U8')


def detect_and_play(name, url, iconimage, description):
    url = unquote_plus(url)
    if not url or not url.startswith(('http://', 'https://')):
        notify("Link inválido")
        return

    original_url = url.split('|')[0]

    # 1. HLSRETRY
    if urlparse(original_url).path.endswith('.m3u8'):
        try:
            hlsretry.XtreamProxy().start()
            player_hlsretry(name, url, iconimage, description)
            return
        except Exception as e:
            log(f'HLSRETRY falhou para {original_url}: {str(e)}')
            notify('HLSRETRY falhou, tentando TSDOWNLOADER...')

    # 2. TSDOWNLOADER
    if '.ts' in original_url or '/live/' in original_url:
        try:
            tsdownloader.XtreamProxy().start()
            player_tsdownloader(name, url, iconimage, description)
            return
        except Exception as e:
            log(f'TSDOWNLOADER falhou para {original_url}: {str(e)}')
            notify('TSDOWNLOADER falhou, tentando INPUTSTREAM...')

    # 3. INPUTSTREAM
    try:
        is_helper = inputstreamhelper.Helper("hls")
        if is_helper.check_inputstream():
            player_input(name, url, iconimage, description)
            return
    except Exception as e:
        log(f'INPUTSTREAM falhou para {original_url}: {str(e)}')

    notify("Erro: Nenhum player conseguiu reproduzir o link.")


# Entrada principal

def run(params):
    stream_type = params.get('streamtype', None)
    iconimage = params.get('iconImage', params.get('thumbnailImage', addonIcon))
    name = params.get('name', 'F4mTester')
    url = params.get('url', '')
    description = params.get('description', '')

    if not stream_type:
        dialog('F4MTESTER PLAYER')
    elif stream_type and url:
        detect_and_play(name, url, iconimage, description)
