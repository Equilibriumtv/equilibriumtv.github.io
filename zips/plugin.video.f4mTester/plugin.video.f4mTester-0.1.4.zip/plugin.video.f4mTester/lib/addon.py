# -*- coding: utf-8 -*-
from lib.helper import *
from lib import hlsretry, tsdownloader
from urllib.parse import unquote, urlparse

def m3u8_to_ts(url):
    """Converte uma URL m3u8 com '/live/' para um caminho base de TS"""
    if url.endswith('.m3u8') and '/live/' in url and url.count('/') > 5:
        return url.replace('/live', '').replace('.m3u8', '')
    return url

def basename(p):
    """Retorna o nome do arquivo no final da URL ou caminho"""
    return p.rsplit('/', 1)[-1]

def convert_to_m3u8(url):
    """Converte URLs complexas para formato m3u8 se possível"""
    # Decodifica URL (ex: %2F, +, etc)
    try:
        url = unquote(url)
    except Exception:
        pass

    # Remove headers embutidos na URL (ex: |User-Agent=...)
    url = url.split('|')[0].split('%7C')[0]

    # Se já for m3u8 ou for arquivo comum (.mp4, .avi), retorna como está
    if any(ext in url for ext in ['.m3u8', '.mp4', '.avi']) or '/hl' in url:
        return url

    # Se for uma URL longa e não m3u8, tenta adaptar
    if url.count('/') > 4:
        try:
            parsed = urlparse(url)
            base = f"{parsed.scheme}://{parsed.netloc}"
            path = url.replace(base, '')

            # Adiciona '/live' ao caminho
            path = '/live' + path
            file = basename(path)

            if file.endswith('.ts'):
                path = path.replace(file, file.replace('.ts', '.m3u8'))
            elif not file.endswith('.m3u8'):
                path += '.m3u8'

            return base + path
        except Exception:
            pass

    return url


def player_hlsretry(name,url,iconimage,description):
    if name:
        name = 'PLAYER HLSRETRY - ' + name
    else:
        name = 'PLAYER HLSRETRY'
    url = unquote_plus(url)
    url = 'http://%s:%s/?url=%s'%(str(hlsretry.HOST_NAME),str(hlsretry.PORT_NUMBER),quote(url))
    hlsretry.XtreamProxy().start()
    li=xbmcgui.ListItem(name)
    iconimage = iconimage if iconimage else ''
    li.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})
    if kversion > 19:
        info = li.getVideoInfoTag()
        info.setTitle(name)
        info.setPlot(description)
    else:
        li.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
    xbmc.Player().play(item=url, listitem=li)

def player_tsdownloader(name,url,iconimage,description):
    if name:
        name = 'PLAYER TSDOWNLOADER - ' + name
    else:
        name = 'PLAYER TSDOWNLOADER'
    url = unquote_plus(url)
    url = url.replace('live/', '').replace('.m3u8', '')
    url = 'http://%s:%s/?url=%s'%(str(tsdownloader.HOST_NAME),str(tsdownloader.PORT_NUMBER),quote(url))
    tsdownloader.XtreamProxy().start() 
    li=xbmcgui.ListItem(name)
    iconimage = iconimage if iconimage else ''
    li.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})
    if kversion > 19:
        info = li.getVideoInfoTag()
        info.setTitle(name)
        info.setPlot(description)
    else:
        li.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
    xbmc.Player().play(item=url, listitem=li)           

def player_ffmpegdirect(name, url, iconimage, description):
    if name:
        name = 'PLAYER FFMPEGDIRECT - ' + name
    else:
        name = 'PLAYER FFMPEGDIRECT'

    url = unquote_plus(url)
    if any(ext in url for ext in ['.mp4', '.mp3', '.mkv', '.avi', '.ts', '.m3u8']):
        if xbmc.Player().isPlaying():
            xbmc.Player().stop()

        headers = ("User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:129.0) Gecko/20100101 Firefox/129.0\r\n""Cache-Control=no-cache\r\n""Accept=*/*\r\n""Connection=close")

        li = xbmcgui.ListItem(name)
        li.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})
        if kversion > 19:
            info = li.getVideoInfoTag()
            info.setTitle(name)
            info.setPlot(description)
        else:
            li.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})

        li.setPath(url)
        li.setContentLookup(False)
        li.setMimeType("application/vnd.apple.mpegurl")
        li.setProperty("inputstream", "inputstream.ffmpegdirect")
        li.setProperty("inputstream.ffmpegdirect.is_live", "true")
        li.setProperty("inputstream.ffmpegdirect.stream_mode", "simple")
        li.setProperty("inputstream.ffmpegdirect.manifest_type", "hls")
        li.setProperty("inputstream.ffmpegdirect.pts_offset", "latest")
        li.setProperty("inputstream.ffmpegdirect.headers", headers)

        xbmc.Player().play(item=url, listitem=li)
    else:
        notify('Formato não suportado pelo FFMPEGDIRECT')


def player_input(name, url, iconimage, description):
    if name:
        name = 'PLAYER INPUTSTREAM ADAPTIVE - ' + name
    else:
        name = 'PLAYER INPUTSTREAM ADAPTIVE'

    if not any(ext in url for ext in ['.mp4', '.mp3', '.mkv', '.avi', '.rmvb']):
        url = convert_to_m3u8(url)
        if '.m3u8' in url:
            import inputstreamhelper
            is_helper = inputstreamhelper.Helper("hls")
            if is_helper.check_inputstream():
                if xbmc.Player().isPlaying():
                    xbmc.Player().stop()

                url = unquote_plus(url)
                if '|' in url:
                    header = url.split('|')[1]
                else:
                    header = ("User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:129.0) Gecko/20100101 Firefox/129.0\r\n""Cache-Control=no-cache\r\n""Accept=*/*\r\n""Connection=close")

                play_item = xbmcgui.ListItem(path=url)
                play_item.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})
                if kversion > 19:
                    info = play_item.getVideoInfoTag()
                    info.setTitle(name)
                    info.setPlot(description)
                else:
                    play_item.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})

                play_item.setContentLookup(False)
                play_item.setMimeType("application/vnd.apple.mpegurl")
                if kversion >= 19:
                    play_item.setProperty('inputstream', is_helper.inputstream_addon)
                else:
                    play_item.setProperty('inputstreamaddon', is_helper.inputstream_addon)

                play_item.setProperty("inputstream.adaptive.manifest_type", "hls")
                play_item.setProperty("inputstream.adaptive.is_realtime_stream", "true")
                play_item.setProperty("inputstream.adaptive.manifest_update_parameter", "full")
                play_item.setProperty("inputstream.adaptive.manifest_headers", header)

                xbmc.Player().play(item=url, listitem=play_item)
        else:
            notify('O link não é M3U8')
    else:
        notify('Formato inválido!')


    


#### run addon ####
def run(params):
    stream_type = params.get('streamtype', None)
    iconimage = params.get('iconImage', params.get('thumbnailImage', addonIcon))
    name = params.get('name', 'F4mTester')
    url = params.get('url', '')
    description = params.get('description', '')
    if not stream_type:
        dialog('F4MTESTER PLAYER')
    elif stream_type !=None:
        if url:
            op = select('SELECT PLAYER', ['PLAYER HLSRETRY', 'PLAYER TSDOWNLOADER', 'PLAYER INPUTSTREAM FFMPEGDIRECT', 'PLAYER INPUTSTREAM ADAPTATIVE'])
            if op == 0:
                player_hlsretry(name,url,iconimage,description)
            elif op == 1:
                player_tsdownloader(name,url,iconimage,description)
            elif op == 2:
                player_ffmpegdirect(name, url, iconimage, description)
            elif op == 3:
                player_input(name,url,iconimage,description)

