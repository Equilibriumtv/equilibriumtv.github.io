# -*- coding: utf-8 -*-
import xbmc
import xbmcaddon

# Pega informações do addon
addon       = xbmcaddon.Addon()
addon_name  = addon.getAddonInfo('name')
addon_id    = addon.getAddonInfo('id')
addon_ver   = addon.getAddonInfo('version')

xbmc.log(f"[{addon_name}] Serviço iniciado (ID: {addon_id}, Versão: {addon_ver})", xbmc.LOGINFO)

# Mantém o serviço ativo
monitor = xbmc.Monitor()
while not monitor.abortRequested():
    if monitor.waitForAbort(1):  # checa a cada 1 segundo se o Kodi está fechando
        break

xbmc.log(f"[{addon_name}] Serviço finalizado.", xbmc.LOGINFO)