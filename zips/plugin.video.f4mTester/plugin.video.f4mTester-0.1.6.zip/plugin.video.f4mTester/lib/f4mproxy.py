import socket
import threading
import urllib.parse
import requests
import binascii
import os
import re
import six
if six.PY3:
    from urllib.parse import urlparse, parse_qs, quote, unquote, unquote_plus, quote_plus, urljoin
else:
    from urlparse import urlparse, parse_qs, urljoin
    from urllib import quote, unquote, unquote_plus, quote_plus, quote
import time
import logging
from requests.exceptions import ConnectionError, RequestException
from urllib3.exceptions import IncompleteRead
import json
import logging
try:
    from kodi_six import xbmc
except ImportError:
    import xbmc
from doh import DNSOverrideDoH

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
import socket
from urllib.parse import quote_plus, urljoin

# 🔍 Detecta IP local real para acesso em rede (evita 127.0.0.1)
def get_local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # Conecta a um servidor DNS público só para descobrir o IP local
        s.connect(('8.8.8.8', 1))
        ip = s.getsockname()[0]
    except Exception:
        ip = '127.0.0.1'
    finally:
        s.close()
    return ip

# 🛠️ Configurações do proxy
HOST_NAME = get_local_ip()
PORT_NUMBER = 58500
url_proxy = f'http://{HOST_NAME}:{PORT_NUMBER}/proxy?url='

# 📺 Reescreve uma playlist M3U8 para apontar para o proxy local
def rewrite_m3u8_urls(playlist: str, base_url: str, scheme: str, host: str, port: int) -> str:
    lines = playlist.splitlines()
    rewritten = []

    for line in lines:
        if line.startswith('#') or not line.strip():
            rewritten.append(line)
        else:
            full_url = urljoin(base_url + '/', line)
            encoded = quote_plus(full_url)
            proxy_line = f"http://{host}:{port}/proxy?url={encoded}"
            rewritten.append(proxy_line)

    return '\n'.join(rewritten)


# Configure logging to use Kodi's logging system
def log(message):
    logging.debug(f"[F4MTESTER PROXY] {message}")

stop_event = threading.Event()

# Constants
DEFAULT_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"
IP_CACHE_TS = {}
IP_CACHE_MP4 = {}
#AGENT_OF_CHAOS = {}
AGENT_OF_CHAOS = False
CACHE_HOST = {}
COUNT_CLEAR = {}

def get_cache_key(client_ip: str, url: str) -> str:
    """Generate a unique cache key combining client_ip and url."""
    return f"{client_ip}:{url}"

def rewrite_m3u8_urls(playlist_content: str, base_url: str, scheme: str, host: str, port: int) -> str:
    """Rewrite URLs in an M3U8 playlist to proxy through the server."""
    def replace_url(match):
        segment_url = match.group(0).strip()
        if segment_url.startswith('#') or not segment_url or segment_url == '/':
            return segment_url
        try:
            absolute_url = urljoin(base_url + '/', segment_url)
            if not (absolute_url.endswith('.ts') or '/hl' in absolute_url.lower() or absolute_url.endswith('.m3u8')):
                log(f"Ignoring invalid URL in M3U8: {absolute_url}")
                return segment_url
            proxied_url = f"{scheme}://{host}:{port}/proxy?url={urllib.parse.quote(absolute_url)}"
            return proxied_url
        except ValueError as e:
            log(f"Error resolving URL {segment_url}: {e}")
            return segment_url
    return re.sub(r'^(?!#)\S+', replace_url, playlist_content, flags=re.MULTILINE)

def get_host_by_url(parsed):
    port  = str(parsed.port) if parsed.port else None
    if port:
        base = parsed.scheme + '://' + parsed.hostname + ':' + port
    else:
        base = parsed.scheme + '://' + parsed.hostname
    return base

def parse_headers(url):
    url = unquote_plus(url)
    headers = {
                "User-Agent": DEFAULT_USER_AGENT,
                'Accept-Encoding': 'identity',
                'Accept': '*/*',
                'Connection': 'keep-alive'
            }
    if '|' in url:
        url = url.split('|')
        url = url[0]
        header_ = url[1]
    elif '%7C' in url:
        url = url.split('%7C')
        url = url[0]
        header_ = url[1]
    else:
        header_ = ''        
    if header_:
        if 'User-Agent' in header_:
            try:
                user_agent = header_.split('User-Agent=')[1]
                try:
                    user_agent = user_agent.split('&')[0]
                except:
                    pass
                try:
                    user_agent = unquote_plus(user_agent)
                except:
                    pass
                try:
                    user_agent = unquote(user_agent)
                except:
                    pass
                if 'Mozilla' in user_agent:
                    headers['User-Agent'] = user_agent
            except:
                pass
        if 'Referer' in header_:
            try:
                referer = header_.split('Referer=')[1]
                try:
                    referer = referer.split('&')[0]
                except:
                    pass
                try:
                    referer = unquote_plus(referer)
                except:
                    pass
                try:
                    referer = unquote(referer)
                except:
                    pass                
                headers['Referer'] = referer
            except:
                pass
        if 'Origin' in header_:
            try:
                origin = header_.split('Origin=')[1]
                try:
                    origin = origin.split('&')[0]
                except:
                    pass
                try:
                    origin = unquote_plus(origin)
                except:
                    pass
                try:
                    origin = unquote(origin)
                except:
                    pass                
                headers['Origin'] = origin
            except:
                pass
    return url, headers   

def stream_response(response, client_ip: str, url: str, headers: dict, sess):
    """Stream response chunks with caching and error handling."""
    if '.m3u8' in url or '.mp4' in url:
        cache_key = get_cache_key(client_ip, url)
    else:
        cache_key = client_ip
            
    def generate_chunks(response):
        mode_ts = False
        bytes_read = 0
        try:
            for chunk in response.iter_content(chunk_size=4096):
                if chunk:
                    bytes_read += len(chunk)
                    if '.mp4' in url.lower():
                        mode_ts = False
                        if cache_key not in IP_CACHE_MP4:
                            IP_CACHE_MP4[cache_key] = []
                        IP_CACHE_MP4[cache_key].append(chunk)
                        if len(IP_CACHE_MP4[cache_key]) > 20:
                            IP_CACHE_MP4[cache_key].pop(0)
                    elif '.ts' in url.lower() or '/hl' in url.lower():
                        mode_ts = True
                        if cache_key not in IP_CACHE_TS:
                            IP_CACHE_TS[cache_key] = []
                        IP_CACHE_TS[cache_key].append(chunk)
                        if len(IP_CACHE_TS[cache_key]) > 20:
                            IP_CACHE_TS[cache_key].pop(0)
                    yield chunk
        except (IncompleteRead, ConnectionError) as e:
            log(f"Error processing chunks (bytes read: {bytes_read}): {e}")
            if mode_ts and cache_key in IP_CACHE_TS and IP_CACHE_TS[cache_key]:
                for chunk in IP_CACHE_TS[cache_key][-5:]:
                    yield chunk
            elif not mode_ts and cache_key in IP_CACHE_MP4 and IP_CACHE_MP4[cache_key]:
                for chunk in IP_CACHE_MP4[cache_key][-5:]:
                    yield chunk
        except Exception as e:
            log(f"Unexpected error processing chunks: {e}")
        finally:
            sess.close()
    return generate_chunks(response)

def loop_ts(headers, self_server, url):
    global stop_user
    DNSOverrideDoH()
    try:
        for i in range(10):
            if stop_user or stop_event.is_set():
                log('Parando streaming TS')
                break
            count = i + 1
            headers['User-Agent'] = binascii.b2a_hex(os.urandom(20))[:32]
            r = requests.get(url, headers=headers, allow_redirects=True, stream=True, verify=False)
            code = r.status_code
            log('Status Code: %s' % str(code))
            if code == 200:
                try:
                    for chunk in r.iter_content(chunk_size=8192):
                        if stop_user or stop_event.is_set():
                            log('Parando streaming TS')
                            break
                        if chunk:
                            # try:
                            #     self_server.sendall(chunk)
                            # except (BrokenPipeError, ConnectionResetError):
                            #     stop_user = True
                            #     break
                            try:
                                self_server.sendall(chunk)
                            except:
                                break                            
                except Exception as e:
                    log(f'Erro: {e}')
                    stop_user = True
                    break
            else:
                if count == 7:
                    break
    except Exception as e:
        log(f'Erro: {e}')

def send_ts(headers, self_server, url):
    global stop_user
    while not stop_event.is_set() or not stop_user:
        loop_ts(headers, self_server, url)
    log('loop ts parado')

def parse_http_request(data: bytes) -> tuple:
    """Parse raw HTTP request to extract method, path, headers, and query params."""
    try:
        request_str = data.decode('utf-8', errors='ignore')
        lines = request_str.split('\r\n')
        if not lines:
            return None, None, None, None
        method, path, _ = lines[0].split(' ', 2)
        headers = {}
        for line in lines[1:]:
            if ': ' in line:
                key, value = line.split(': ', 1)
                headers[key.lower()] = value
        parsed_url = urllib.parse.urlparse(path)
        query_params = urllib.parse.parse_qs(parsed_url.query)
        return method, parsed_url, query_params, headers
    except Exception as e:
        log(f"Error parsing HTTP request: {e}")
        return None, None, None, None
    


def handle_client(client_socket: socket.socket, address: tuple, scheme: str, host: str, port: int):
    global AGENT_OF_CHAOS
    global stop_user
    DNSOverrideDoH()
    """Handle a single client connection."""
    try:
        client_socket.settimeout(10)
        data = client_socket.recv(4096)
        if not data:
            return

        method, parsed_url, query_params, headers = parse_http_request(data)
        if method != 'GET':
            response = "HTTP/1.1 405 Method Not Allowed\r\nContent-Type: text/plain\r\n\r\nMethod Not Allowed"
            client_socket.sendall(response.encode('utf-8'))
            return

        client_ip = address[0]
        path = parsed_url.path

        if path == '/':
            response_body = json.dumps({"message": "F4MTESTER PROXY v4.2.5"}).encode('utf-8')
            response = (
                f"HTTP/1.1 200 OK\r\n"
                f"Content-Type: application/json\r\n"
                f"Content-Length: {len(response_body)}\r\n"
                f"\r\n"
            ).encode('utf-8') + response_body
            client_socket.sendall(response)
            return

        if path == '/stop':
            response_body = json.dumps({"message": "Shutting down server"}).encode('utf-8')
            response = (
                f"HTTP/1.1 200 OK\r\n"
                f"Content-Type: application/json\r\n"
                f"Content-Length: {len(response_body)}\r\n"
                f"\r\n"
            ).encode('utf-8') + response_body
            client_socket.sendall(response)
            global server_running
            server_running = False
            stop_event.set()
            return

        # if path == '/check':
        #     url = query_params.get('url', [''])[0]
        #     if not url or not ('.m3u8' in url or 'get.php' in url):
        #         response = (
        #             f"HTTP/1.1 400 Bad Request\r\n"
        #             f"Content-Type: application/json\r\n"
        #             f"Content-Length: {len(json.dumps({'message': 'only m3u8 links'}))}\r\n"
        #             f"\r\n"
        #             f"{json.dumps({'message': 'only m3u8 links'})}"
        #         ).encode('utf-8')
        #         client_socket.sendall(response)
        #         return

        #     session = requests.Session()
        #     default_headers = {
        #         "User-Agent": DEFAULT_USER_AGENT,
        #         'Accept-Encoding': 'identity',
        #         'Accept': '*/*',
        #         'Connection': 'keep-alive'
        #     }
        #     try:
        #         response = session.get(url, headers=default_headers, allow_redirects=True, stream=True, timeout=15)
        #         if response.status_code != 200:
        #             default_headers.update({'User-Agent': binascii.b2a_hex(os.urandom(20))[:32].decode('ascii')})
        #             response = session.get(url, headers=default_headers, allow_redirects=True, stream=True, timeout=15)
        #         response_body = json.dumps({'code': response.status_code}).encode('utf-8')
        #         response = (
        #             f"HTTP/1.1 200 OK\r\n"
        #             f"Content-Type: application/json\r\n"
        #             f"Content-Length: {len(response_body)}\r\n"
        #             f"\r\n"
        #         ).encode('utf-8') + response_body
        #         client_socket.sendall(response)
        #     except Exception as e:
        #         log(f"Check error: {e}")
        #         response_body = json.dumps({'code': 'error'}).encode('utf-8')
        #         response = (
        #             f"HTTP/1.1 200 OK\r\n"
        #             f"Content-Type: application/json\r\n"
        #             f"Content-Length: {len(response_body)}\r\n"
        #             f"\r\n"
        #         ).encode('utf-8') + response_body
        #         client_socket.sendall(response)
        #     finally:
        #         session.close()
        #     return

        if path == '/proxy':
            url = query_params.get('url', [''])[0]
            if stop_event.is_set():
                return
            # cache_key = get_cache_key(client_ip, url)           
            if not url:
                response = (
                    f"HTTP/1.1 400 Bad Request\r\n"
                    f"Content-Type: application/json\r\n"
                    f"Content-Length: {len(json.dumps({'detail': 'No URL provided'}))}\r\n"
                    f"\r\n"
                    f"{json.dumps({'detail': 'No URL provided'})}"
                ).encode('utf-8')
                client_socket.sendall(response)
                return
            url, master_headers = parse_headers(url)            
            if '.m3u8' in url or '.mp4' in url:
                cache_key = get_cache_key(client_ip, url)
            else:
                cache_key = client_ip             
            try:
                if not ('.m3u8' in url.lower() or '.mp4' in url.lower() or '.ts' in url.lower() or '/hl' in url.lower() or int(url.count('/')) == 5):
                    log(f"Invalid URL: {url}")
                    response = (
                        f"HTTP/1.1 400 Bad Request\r\n"
                        f"Content-Type: application/json\r\n"
                        f"Content-Length: {len(json.dumps({'detail': 'URL not compatible with proxy'}))}\r\n"
                        f"\r\n"
                        f"{json.dumps({'detail': 'URL not compatible with proxy'})}"
                    ).encode('utf-8')
                    client_socket.sendall(response)
                    return
            except:
                response = (
                    f"HTTP/1.1 400 Bad Request\r\n"
                    f"Content-Type: application/json\r\n"
                    f"Content-Length: {len(json.dumps({'detail': 'URL not compatible with proxy'}))}\r\n"
                    f"\r\n"
                    f"{json.dumps({'detail': 'URL not compatible with proxy'})}"
                ).encode('utf-8')
                client_socket.sendall(response)
                return                

            session = requests.Session()
            # default_headers = {
            #     "User-Agent": DEFAULT_USER_AGENT,
            #     'Accept-Encoding': 'identity',
            #     'Accept': '*/*',
            #     'Connection': 'keep-alive'
            # }
            default_headers = master_headers
            session.headers.update(default_headers)
            max_retries = 5
            attempts = 0
            tried_without_range = False

            # PING M3U8
            # if '.m3u8' in url.lower():
            #     PING_M3U8 = url

            # get direct url
            if '/hl' in url or '.mp4' in url:
                parsed_url_base = urlparse(url)
                host_base_ = get_host_by_url(parsed_url_base)
                if not host_base_ in CACHE_HOST:
                    parsed2 = urlparse(session.get(url).url)
                    host_base2 = get_host_by_url(parsed2)
                    CACHE_HOST[host_base_] = host_base2
                    if host_base_ in CACHE_HOST:        
                        host_base = CACHE_HOST[host_base_]
                        url = url.replace(host_base_, host_base)
                else:
                    if host_base_ in CACHE_HOST:        
                        host_base = CACHE_HOST[host_base_]
                        url = url.replace(host_base_, host_base)
            # video mp2t continuo
            if not '.ts' in url.lower() and not '.mp4' in url.lower() and not '.m3u8' in url.lower() and not '/hl' in url.lower():
                media_type = 'video/mp2t'
                status_code = 200
                header_lines = [f"HTTP/1.1 {status_code} {'Partial Content' if status_code == 206 else 'OK'}"]
                header_lines.append(f"Content-Type: {media_type}")
                header_lines.append("\r\n") 
                client_socket.sendall("\r\n".join(header_lines).encode('utf-8'))
                stop_user = False
                send_ts(default_headers, client_socket, url)
                return
            elif '.ts' in url.lower() and int(url.count('/')) == 5 and not '/hl' in url.lower():
                media_type = 'video/mp2t'
                status_code = 200
                header_lines = [f"HTTP/1.1 {status_code} {'Partial Content' if status_code == 206 else 'OK'}"]
                header_lines.append(f"Content-Type: {media_type}")
                header_lines.append("\r\n") 
                client_socket.sendall("\r\n".join(header_lines).encode('utf-8'))
                stop_user = False
                send_ts(default_headers, client_socket, url)
                return                    

            while attempts < max_retries:
                if stop_event.is_set():
                    return                
                try:
                    range_header = headers.get('range')
                    if '.mp4' in url.lower() and range_header and not tried_without_range:
                        default_headers['Range'] = range_header
                    else:
                        default_headers.pop('Range', None)

                    req_headers = default_headers.copy()
                    if AGENT_OF_CHAOS:
                        req_headers.update({'User-Agent': binascii.b2a_hex(os.urandom(20))[:32] })

                    log(f"Tentativa {attempts}")
                    log(f"Acessando: {url} with headers: {req_headers}")

                    response = session.get(url, headers=req_headers, allow_redirects=True, stream=True, timeout=60)

                    if response.status_code in (200, 206):
                        AGENT_OF_CHAOS = False
                        if client_ip in COUNT_CLEAR:
                            if COUNT_CLEAR.get(client_ip, 0) > 4:
                                log('LIMPANDO CACHES')
                                try:
                                    # if cache_key in AGENT_OF_CHAOS:
                                    #     del AGENT_OF_CHAOS[cache_key]
                                    # Limpar caches quando a requisição for bem-sucedida
                                    if cache_key in IP_CACHE_MP4:
                                        del IP_CACHE_MP4[cache_key]
                                    if cache_key in IP_CACHE_TS:
                                        del IP_CACHE_TS[cache_key]
                                except:
                                    pass
                        if not client_ip in COUNT_CLEAR:
                            COUNT_CLEAR[client_ip] = 0
                        elif int(COUNT_CLEAR.get(client_ip, 0) > 4):
                            log('ZERANDO COUNT CLEAR')
                            COUNT_CLEAR[client_ip] = 0
                        else:
                            if client_ip in COUNT_CLEAR:
                                COUNT_CLEAR[client_ip] = COUNT_CLEAR.get(client_ip, 0) + 1 
                                                    
                        log(f"Access OK, code: {response.status_code}")
                        content_type = response.headers.get('content-type', '').lower()

                        if 'application/vnd.apple.mpegurl' in content_type or '.m3u8' in url.lower():
                            base_url = url.rsplit('/', 1)[0]
                            playlist_content = response.content.decode('utf-8', errors='ignore')
                            rewritten_playlist = rewrite_m3u8_urls(playlist_content, base_url, scheme, host, port)
                            response_body = rewritten_playlist.encode('utf-8')
                            response = (
                                f"HTTP/1.1 200 OK\r\n"
                                f"Content-Type: application/vnd.apple.mpegurl\r\n"
                                f"Content-Length: {len(response_body)}\r\n"
                                f"\r\n"
                            ).encode('utf-8') + response_body
                            client_socket.sendall(response)
                            return

                        response_headers = {
                            key: value for key, value in response.headers.items()
                            if key.lower() in ('content-type', 'accept-ranges', 'content-range')
                        }
                        if '.mp4' in url.lower() or '/hl' in url.lower():
                            media_type = (
                                'video/mp4' if '.mp4' in url.lower()
                                else 'video/mp2t' if '.ts' in url.lower() or '/hl' in url
                                else response_headers.get('content-type', 'application/octet-stream')
                            )
                        else:
                            media_type = 'video/mp2t'
                        status_code = 206 if response.status_code == 206 else 200
                        if response.status_code == 206 and 'Content-Range' in response.headers:
                            response_headers['Content-Range'] = response.headers.get('Content-Range', '')

                        header_lines = [f"HTTP/1.1 {status_code} {'Partial Content' if status_code == 206 else 'OK'}"]
                        header_lines.append(f"Content-Type: {media_type}")
                        for key, value in response_headers.items():
                            header_lines.append(f"{key}: {value}")
                        header_lines.append("\r\n")
                        client_socket.sendall("\r\n".join(header_lines).encode('utf-8'))
                        if '.mp4' in url.lower() or '/hl' in url.lower() or '.ts' and not int(url.count('/')) == 5 and not int(url.count('/')) == 6:
                            for chunk in stream_response(response, client_ip, url, req_headers, session):
                                client_socket.sendall(chunk)
                            return
                    elif response.status_code == 416:
                        if range_header and not tried_without_range:
                            tried_without_range = True
                            continue
                        else:
                            response = (
                                f"HTTP/1.1 416 Range Not Satisfiable\r\n"
                                f"Content-Type: application/json\r\n"
                                f"Content-Length: {len(json.dumps({'detail': 'Range Not Satisfiable'}))}\r\n"
                                f"\r\n"
                                f"{json.dumps({'detail': 'Range Not Satisfiable'})}"
                            ).encode('utf-8')
                            client_socket.sendall(response)
                            return

                    elif response.status_code == 404 and ('.ts' in url.lower() and not '/hl' in url.lower() or '/hl' in url.lower()):
                        log(f"404 for {url}")
                        attempts += 1
                        #AGENT_OF_CHAOS[cache_key] = binascii.b2a_hex(os.urandom(20))[:32] 
                        AGENT_OF_CHAOS = True               
                        if client_ip in IP_CACHE_TS and IP_CACHE_TS[client_ip]:
                            log('USANDO CACHE')
                            response = (
                                f"HTTP/1.1 200 OK\r\n"
                                f"Content-Type: video/mp2t\r\n"
                                f"\r\n"
                            ).encode('utf-8')
                            client_socket.sendall(response)
                            for chunk in IP_CACHE_TS[client_ip][-5:]:
                                client_socket.sendall(chunk)
                            return
                        else:
                            time.sleep(1) 
                    else:
                        log(f"Status code: {response.status_code}")
                        #AGENT_OF_CHAOS[cache_key] = binascii.b2a_hex(os.urandom(20))[:32]
                        AGENT_OF_CHAOS = True 
                        if not '.m3u8' in url.lower():
                            if '.mp4' in url.lower() and cache_key in IP_CACHE_MP4 and IP_CACHE_MP4[cache_key]:
                                response = (
                                    f"HTTP/1.1 200 OK\r\n"
                                    f"Content-Type: video/mp4\r\n"
                                    f"\r\n"
                                ).encode('utf-8')
                                client_socket.sendall(response)
                                for chunk in IP_CACHE_MP4[cache_key][-5:]:
                                    client_socket.sendall(chunk)
                                return
                            if ('.ts' in url.lower() and not '/hl' in url.lower() or '/hl' in url.lower()) and client_ip in IP_CACHE_TS and IP_CACHE_TS[client_ip]:
                                log('USANDO CACHE')
                                response = (
                                    f"HTTP/1.1 200 OK\r\n"
                                    f"Content-Type: video/mp2t\r\n"
                                    f"\r\n"
                                ).encode('utf-8')
                                client_socket.sendall(response)
                                for chunk in IP_CACHE_TS[client_ip][-5:]:
                                    client_socket.sendall(chunk)
                                return
                        attempts += 1
                        time.sleep(2)

                except RequestException as e:
                    log(f"Request error: {e}")
                    #AGENT_OF_CHAOS[cache_key] = binascii.b2a_hex(os.urandom(20))[:32]
                    AGENT_OF_CHAOS = True
                    if not '.m3u8' in url.lower():
                        if '.mp4' in url.lower() and cache_key in IP_CACHE_MP4 and IP_CACHE_MP4[cache_key]:
                            response = (
                                f"HTTP/1.1 200 OK\r\n"
                                f"Content-Type: video/mp4\r\n"
                                f"\r\n"
                            ).encode('utf-8')
                            client_socket.sendall(response)
                            for chunk in IP_CACHE_MP4[cache_key][-5:]:
                                client_socket.sendall(chunk)
                            return
                        if ('.ts' in url.lower() and not '/hl' in url.lower() or '/hl' in url.lower()) and client_ip in IP_CACHE_TS and IP_CACHE_TS[client_ip]:
                            log('USANDO CACHE')
                            response = (
                                f"HTTP/1.1 200 OK\r\n"
                                f"Content-Type: video/mp2t\r\n"
                                f"\r\n"
                            ).encode('utf-8')
                            client_socket.sendall(response)
                            for chunk in IP_CACHE_TS[client_ip][-5:]:
                                client_socket.sendall(chunk)
                            return
                    attempts += 1
                    time.sleep(2)

            response = (
                f"HTTP/1.1 502 Bad Gateway\r\n"
                f"Content-Type: application/json\r\n"
                f"Content-Length: {len(json.dumps({'detail': 'Failed to connect after multiple attempts'}))}\r\n"
                f"\r\n"
                f"{json.dumps({'detail': 'Failed to connect after multiple attempts'})}"
            ).encode('utf-8')
            client_socket.sendall(response)
            return

    except Exception as e:
        log(f"Client handling error: {e}")
    finally:
        client_socket.close()

# def start_proxy_server(host=HOST_NAME, port=PORT_NUMBER):
#     """Start the proxy server in a separate thread."""
#     global server_running
#     server_running = True
#     server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
#     server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
#     server_socket.bind((host, port))
#     server_socket.listen(5)
#     server_socket.settimeout(1)  # Timeout to allow checking server_running

#     log(f"Proxy server started on {host}:{port}")

#     def server_loop():
#         while server_running:
#             try:
#                 client_socket, address = server_socket.accept()
#                 client_thread = threading.Thread(
#                     target=handle_client,
#                     args=(client_socket, address, 'http', host, port),
#                     daemon=True
#                 )
#                 client_thread.start()
#             except socket.timeout:
#                 continue
#             except Exception as e:
#                 log(f"Server error: {e}", logging.ERROR)
#                 break
#         server_socket.close()
#         log("Proxy server stopped")

#     server_thread = threading.Thread(target=server_loop, daemon=True)
#     server_thread.start()
#     return server_socket

# # def stop_proxy_server(server_socket):
# #     """Stop the proxy server."""
# #     global server_running
# #     server_running = False
# #     try:
# #         with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
# #             s.connect(('127.0.0.1', server_socket.getsockname()[1]))
# #             s.sendall(b"GET /stop HTTP/1.1\r\nHost: localhost\r\n\r\n")
# #             s.recv(4096)
# #     except:
# #         pass
# #     server_socket.close()
# #     log("Proxy server stopped")


# def thread_server():
#     def is_port_in_use():
#         """Verifica se a porta está em uso."""
#         with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
#             try:
#                 s.bind((HOST_NAME, PORT_NUMBER))
#                 return False
#             except socket.error:
#                 return True 
#     if not is_port_in_use():   
#         # server = start_proxy_server()
#         # try:
#         #     while True:
#         #         time.sleep(1)
#         # except KeyboardInterrupt:
#         #     stop_proxy_server(server)  
#         # Monitora a reprodução para parar o servidor
#         monitor = xbmc.Monitor()
#         while not monitor.abortRequested():
#             if monitor.waitForAbort(1):
#                 break
#             if xbmc.Player().isPlaying():
#                 continue
#             else:
#                 #self.stop()          


# if __name__ == "__main__":
#     threading.Thread(target=thread_server).start()
#     log('SERVIDOR INICIADO')

class ProxyServer:
    def __init__(self):
        self.monitor = xbmc.Monitor()
        self.server_running = False
        self.server = None

    def is_port_in_use(self, host, port):
        """Verifica se a porta está em uso."""
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind((host, port))
                return False
            except socket.error:
                return True

    def stop_server(self):
        """Para o servidor de forma segura."""
        global server_running
        if self.server_running and self.server:
            log("Tentando parar o servidor...")
            server_running = False
            stop_event.set()
            try:
                # Envia uma requisição para /stop para garantir que o servidor processe a parada
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.settimeout(1)
                    s.connect((HOST_NAME, PORT_NUMBER))
                    s.sendall(b"GET /stop HTTP/1.1\r\nHost: localhost\r\n\r\n")
                    s.recv(4096)
            except:
                pass
            try:
                self.server.close()
                log("Socket do servidor fechado.")
            except Exception as e:
                log(f"Erro ao fechar o socket do servidor: {e}")
            self.server = None

    def start_thread(self):
        if self.is_port_in_use(HOST_NAME, PORT_NUMBER):
            log(f"[HLS Proxy] Porta {PORT_NUMBER} já está em uso, pulando inicialização do servidor")
            return False
        global server_running
        server_running = True
        self.server_running = True
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            server_socket.bind((HOST_NAME, PORT_NUMBER))
            server_socket.listen(5)
            server_socket.settimeout(1)  # Timeout para permitir verificar server_running
            self.server = server_socket
        except Exception as e:
            log(f"Erro ao iniciar o servidor: {e}")
            server_running = False
            self.server_running = False
            return False

        log(f"Servidor proxy iniciado em {HOST_NAME}:{PORT_NUMBER}")

        def server_loop():
            while self.server_running and not stop_event.is_set():
                try:
                    client_socket, address = self.server.accept()
                    client_thread = threading.Thread(
                        target=handle_client,
                        args=(client_socket, address, 'http', HOST_NAME, PORT_NUMBER),
                        daemon=True
                    )
                    client_thread.start()
                except socket.timeout:
                    continue
                except Exception as e:
                    log(f"Erro no servidor: {e}")
                    break
            try:
                self.stop_server()
            except:
                pass
            log("Loop do servidor parado")

        server_thread = threading.Thread(target=server_loop, daemon=True)
        server_thread.start()
        return True

    def thread_server(self):
        global server_running
        if self.start_thread():
            while not self.monitor.abortRequested():
                if self.monitor.waitForAbort(1):
                    try:
                        self.stop_server()
                    except:
                        pass
                    stop_event.set()
                    break
                time.sleep(7)
                if not xbmc.Player().isPlaying():
                    log("Player não está mais reproduzindo, parando servidor.")
                    try:
                        self.stop_server()
                    except:
                        pass
                    stop_event.set()
                    break
            log("SERVIDOR PARADO")

    def start(self):
        thread_server = threading.Thread(target=self.thread_server, daemon=True)
        thread_server.start()