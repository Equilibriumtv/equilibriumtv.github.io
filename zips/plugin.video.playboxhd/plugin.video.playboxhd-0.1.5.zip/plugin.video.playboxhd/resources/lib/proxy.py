# proxy.py - Proxy leve e otimizado para inputstream.ffmpegdirect/adaptive no Kodi
import threading
import socketserver
import urllib.request
import shutil
from http.server import BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, unquote, quote_plus, urljoin
import re

PORT = 8888  # Porta local do proxy

# Gera cabeçalhos baseados na origem da URL
def gerar_headers_com_base(url):
    try:
        parsed = urlparse(url)
        origem = f"{parsed.scheme}://{parsed.hostname}"
    except:
        origem = "https://iptv.local"

    return {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:105.0) Gecko/20100101 Firefox/105.0',
        'Connection': 'keep-alive',
        'Referer': origem,
        'Origin': origem,
        'Accept': '*/*',
        'Accept-Encoding': 'identity'
    }

# Manipulador de requisições do proxy
class ProxyHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path != '/stream':
            self.send_error(404, 'Caminho inválido')
            return

        query = parse_qs(parsed.query)
        url = query.get('url', [None])[0]
        if not url:
            self.send_error(400, 'Parâmetro "url" ausente')
            return

        url = unquote(url)
        headers = gerar_headers_com_base(url)
        print(f"[proxy] → Solicitado: {url}")
        print(f"[proxy] → Headers: {headers}")

        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=30) as response:
                status = response.status
                content_type = response.headers.get('Content-Type', '')
                self.send_response(status)

                for key, value in response.getheaders():
                    if key.lower() not in ['transfer-encoding', 'content-encoding']:
                        self.send_header(key, value)

                # Se for uma playlist .m3u8, reescreve os caminhos para passarem pelo proxy
                if '.m3u8' in url or 'application/vnd.apple.mpegurl' in content_type:
                    conteudo = response.read().decode('utf-8', errors='ignore')

                    def reescreve_linha(linha):
                        linha = linha.strip()
                        if not linha or linha.startswith('#'):
                            return linha
                        if '://' in linha:
                            return f'http://127.0.0.1:{PORT}/stream?url={quote_plus(linha)}'
                        abs_url = urljoin(url, linha)
                        return f'http://127.0.0.1:{PORT}/stream?url={quote_plus(abs_url)}'

                    playlist_reescrita = '\n'.join([reescreve_linha(l) for l in conteudo.splitlines()])
                    self.send_header("Content-Type", "application/vnd.apple.mpegurl")
                    self.end_headers()
                    self.wfile.write(playlist_reescrita.encode('utf-8'))
                    return

                self.end_headers()
                shutil.copyfileobj(response, self.wfile, length=16 * 1024)

        except Exception as e:
            self.send_error(502, f'Erro ao acessar URL remota: {e}')
            print(f'[proxy] ✖ ERRO ao acessar: {url}\n→ {e}')

# Inicia o servidor proxy local
def start_proxy():
    def run_server():
        try:
            with socketserver.ThreadingTCPServer(('127.0.0.1', PORT), ProxyHandler) as httpd:
                print(f"[proxy] Servidor iniciado em http://127.0.0.1:{PORT}/stream?url=...")
                httpd.serve_forever()
        except Exception as e:
            print(f'[proxy] Falha ao iniciar o proxy: {e}')

    thread = threading.Thread(target=run_server, daemon=True)
    thread.start()
