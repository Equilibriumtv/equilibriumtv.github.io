# -*- coding: utf-8 -*-
import socket
import random
import struct
import sys
import logging
from resources.modules import control

logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')

class DNSOverride:
    """
    Substitui socket.getaddrinfo para resolver DNS via servidor customizado,
    com cache interno, suporte a IPv4 e IPv6, e timeout configurável.
    """
    def __init__(self, dns_server="8.8.8.8"):
        self.dns_server = control.setting('dns_resolver') or dns_server
        self.timeout = float(control.setting('dns_timeout') or 5)
        self.py2 = sys.version_info[0] == 2
        self.original_getaddrinfo = socket.getaddrinfo
        self.cache = {}
        socket.getaddrinfo = self._resolver

    def _bchr(self, val):
        return chr(val) if self.py2 else bytes([val])

    def _bjoin(self, parts):
        return b"".join(parts)

    def _to_bytes(self, val):
        if self.py2:
            return val if isinstance(val, str) else val.encode("utf-8")
        return val if isinstance(val, bytes) else val.encode("utf-8")

    def _is_valid_ipv4(self, ip):
        try:
            socket.inet_aton(ip)
            return True
        except socket.error:
            return False

    def _is_valid_ipv6(self, ip):
        try:
            socket.inet_pton(socket.AF_INET6, ip)
            return True
        except (AttributeError, socket.error):
            return False

    def _build_query(self, domain):
        tid = random.randint(0, 65535)
        header = struct.pack(">HHHHHH", tid, 0x0100, 1, 0, 0, 0)
        qname_parts = []
        for part in domain.split('.'):
            if part:
                qname_parts.append(self._bchr(len(part)))
                qname_parts.append(self._to_bytes(part))
        qname_parts.append(self._bchr(0))
        qname = self._bjoin(qname_parts)
        question = qname + struct.pack(">HH", 1, 1)  # tipo A, classe IN
        return header + question, tid

    def _parse_response(self, data, tid, domain):
        if len(data) < 12:
            logging.error("Resposta DNS muito curta")
            return []

        recv_tid = struct.unpack(">H", data[:2])[0]
        if recv_tid != tid:
            logging.error("ID da transação DNS não corresponde")
            return []

        answer_count = struct.unpack(">H", data[6:8])[0]
        i = 12
        while i < len(data) and (ord(data[i]) if self.py2 else data[i]) != 0:
            i += 1
        i += 5  # null byte + QTYPE/QCLASS

        ips = []
        for _ in range(answer_count):
            if i + 10 > len(data):
                break
            i += 2  # Name (pointer)
            type_, class_, ttl, rdlen = struct.unpack(">HHIH", data[i:i+10])
            i += 10
            if type_ == 1 and class_ == 1 and rdlen == 4:  # IPv4 A
                ip_bytes = data[i:i+4]
                ip = ".".join(str(ord(b)) if self.py2 else str(b) for b in ip_bytes)
                ips.append(ip)
            i += rdlen
        if ips:
            self.cache[domain] = ips
            logging.debug("Resolved {} to {}".format(domain, ips))
        else:
            logging.warning("Nenhum registro A encontrado para {}".format(domain))
        return ips

    def resolve(self, domain):
        if domain in self.cache:
            logging.debug("Cache hit for {}: {}".format(domain, self.cache[domain]))
            return self.cache[domain]

        try:
            query, tid = self._build_query(domain)
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                s.settimeout(self.timeout)
                s.sendto(query, (self.dns_server, 53))
                data, _ = s.recvfrom(512)
                return self._parse_response(data, tid, domain)
        except socket.timeout:
            logging.error("Timeout ao consultar DNS para {}".format(domain))
        except Exception as e:
            logging.error("Erro ao resolver {}: {}".format(domain, e))
        return []

    def _resolver(self, host, port, *args, **kwargs):
        """Função substituta de socket.getaddrinfo"""
        try:
            if self._is_valid_ipv4(host):
                logging.debug("Bypass DNS IPv4: {}".format(host))
                return [(socket.AF_INET, socket.SOCK_STREAM, 6, '', (host, port))]
            if self._is_valid_ipv6(host):
                logging.debug("Bypass DNS IPv6: {}".format(host))
                return [(socket.AF_INET6, socket.SOCK_STREAM, 6, '', (host, port))]

            ips = self.resolve(host)
            results = [(socket.AF_INET, socket.SOCK_STREAM, 6, '', (ip, port)) for ip in ips]
            if results:
                return results

            logging.warning("Falha ao resolver {}, usando getaddrinfo original".format(host))
        except Exception as e:
            logging.error("Erro no resolver para {}: {}".format(host, e))

        return self.original_getaddrinfo(host, port, *args, **kwargs)
